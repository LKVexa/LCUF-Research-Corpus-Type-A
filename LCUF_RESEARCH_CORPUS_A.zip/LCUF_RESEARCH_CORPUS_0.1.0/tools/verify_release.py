"""Verify a research release manifest and parse published text/data formats."""
import argparse, ast, gzip, hashlib, json, pathlib, sys

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''): h.update(block)
    return h.hexdigest()

def verify(root,deep=False):
    root=root.resolve(); manifest=json.loads((root/'RELEASE_MANIFEST.json').read_text(encoding='utf-8')); errors=[]; records=0
    entries=manifest['files']; names=set()
    for entry in entries:
        rel=entry['path']; path=(root/rel).resolve()
        if rel in names or not path.is_relative_to(root): errors.append({'path':rel,'error':'duplicate or unsafe manifest entry'}); continue
        names.add(rel)
        if not path.is_file() or path.stat().st_size!=entry['bytes'] or sha(path)!=entry['sha256']: errors.append({'path':rel,'error':'missing file, byte size or SHA-256 mismatch'}); continue
        if deep:
            try:
                if path.suffix=='.json': json.loads(path.read_text(encoding='utf-8-sig'))
                elif path.suffix=='.py': ast.parse(path.read_text(encoding='utf-8-sig'),filename=rel)
                elif path.name.endswith(('.jsonl','.jsonl.gz')):
                    opener=gzip.open if path.suffix=='.gz' else open
                    with opener(path,'rt',encoding='utf-8-sig') as stream:
                        for line,raw in enumerate(stream,1):
                            if not raw.strip(): raise ValueError('blank JSONL record at '+str(line))
                            json.loads(raw); records+=1
            except (ValueError,SyntaxError,UnicodeError,OSError) as e: errors.append({'path':rel,'error':str(e)})
    if len(entries)!=manifest['file_count'] or sum(e['bytes'] for e in entries)!=manifest['bytes']: errors.append({'error':'manifest totals disagree'})
    exclusions=set(manifest.get('excluded_paths',[])); exclusions.add('RELEASE_MANIFEST.json')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if actual-exclusions!=names: errors.append({'error':'delivered file population differs from manifest','unlisted':sorted(actual-exclusions-names),'missing':sorted(names-actual)})
    return {'status':'PASS' if not errors else 'FAIL','files_checked':len(entries),'jsonl_copies_parsed':records,'manifest_sha256':sha(root/'RELEASE_MANIFEST.json'),'deep_syntax_checked':deep,'scope':'Manifest-relative integrity and data/Python syntax; semantic evidence is in named validation receipts. No signature or external certification.','errors':errors}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]); parser.add_argument('--deep',action='store_true'); parser.add_argument('--report',type=pathlib.Path); args=parser.parse_args()
    result=verify(args.root,args.deep); text=json.dumps(result,indent=2)+'\n'
    if args.report: args.report.write_text(text,encoding='utf-8')
    print(text,end=''); sys.exit(0 if result['status']=='PASS' else 1)
