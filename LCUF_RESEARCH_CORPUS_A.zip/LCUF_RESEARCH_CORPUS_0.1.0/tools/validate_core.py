"""Validate schema, provenance, constructed oracles and actual local reference outcomes."""
from __future__ import annotations
import argparse, base64, collections, gzip, hashlib, json, pathlib, platform, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
if sys.platform=='win32' and sys.version_info[:2]==(3,12) and platform.machine().lower() in ('amd64','x86_64') and sys.implementation.name=='cpython':
    sys.path.insert(0,str(ROOT/'tools/vendor'))
from jsonschema import Draft202012Validator
import build_core

def strict_json(text):
    def nonfinite(value): raise ValueError('nonstandard nonfinite JSON value '+value)
    def unique(pairs):
        result={}
        for key,value in pairs:
            if key in result: raise ValueError('duplicate JSON object key '+key)
            result[key]=value
        return result
    return json.loads(text,parse_constant=nonfinite,object_pairs_hook=unique)

def refuse_remote(value):
    if isinstance(value,dict):
        for key,child in value.items():
            if key in ('$ref','$dynamicRef') and not child.startswith('#'): raise ValueError('remote schema reference refused')
            refuse_remote(child)
    elif isinstance(value,list):
        for child in value: refuse_remote(child)

def decode_source(source):
    raw=base64.b64decode(source['bytes_base64'],validate=True)
    if len(raw)>786432: raise ValueError('record source exceeds corpus decoding bound')
    if hashlib.sha256(raw).hexdigest()!=source['sha256']: raise ValueError('source hash mismatch')
    try: text=raw.decode('utf-8')
    except UnicodeError: text=None
    if text!=source['utf8_text']: raise ValueError('source text projection differs from exact bytes')
    return raw

def check_record(record,validator,runtime,replay=True):
    errors=[e.message for e in validator.iter_errors(record)]
    if errors: return errors
    try:
        first=decode_source(record['source']); kind=record['expected']['admission']; expected=record['expected']
        actual=build_core.evaluate(runtime,first) if replay else record['observed']
        if kind=='accept':
            if actual['admission']!='accept' or not build_core.equal_json(actual['values'],expected['values']): errors.append('analytic value oracle mismatch')
            if actual.get('source_sha256')!=record['source']['sha256']: errors.append('observed source identity mismatch')
            if 'row_order' in expected and actual.get('row_order')!=expected['row_order']: errors.append('independent scheduling oracle mismatch')
        elif kind=='reject':
            if actual['admission']!='reject' or expected['diagnostic_contains'] not in actual.get('diagnostic',''): errors.append('rejection oracle mismatch')
        else:
            second=decode_source(record['paired_source']); second_actual=build_core.evaluate(runtime,second) if replay else record['observed']['second']
            if not replay: actual=record['observed']['first']
            if actual.get('source_sha256')!=record['source']['sha256'] or second_actual.get('source_sha256')!=record['paired_source']['sha256']: errors.append('metamorphic observation source identity mismatch')
            if actual['admission']!='accept' or second_actual['admission']!='accept': errors.append('metamorphic pair must be admitted')
            elif (actual['semantic_sha256']==second_actual['semantic_sha256'])!=expected['same_semantic_identity']: errors.append('semantic identity relation mismatch')
            if record['source']['sha256']==record['paired_source']['sha256']: errors.append('metamorphic pair source hashes must differ')
            actual={'admission':'metamorphic','first':actual,'second':second_actual,'native_execution':False}
        if not build_core.equal_json(actual,record['observed']): errors.append('stored observation differs from fresh scoped execution')
        if record['partition']!=build_core.partition(record['family']): errors.append('family partition policy mismatch')
    except (ValueError,TypeError,KeyError,UnicodeError) as e: errors.append(str(e))
    return errors

def population_errors(records,registry,build_receipt,master_sha256):
    errors=[]
    configured={**{f:build_core.POSITIVE_VARIANTS for f in build_core.POSITIVE_FAMILIES},**{f:build_core.NEGATIVE_VARIANTS for f in list(build_core.NEGATIVES)+build_core.CUSTOM_NEGATIVES},**{f:build_core.METAMORPHIC_VARIANTS for f in build_core.METAMORPHIC_FAMILIES}}
    declared={r['family']:r['variants'] for r in registry}
    if len(declared)!=len(registry) or declared!=configured: errors.append('published family registry differs from versioned construction population')
    variants=collections.defaultdict(list)
    for record in records.values(): variants[record['family']].append(record['variant'])
    if set(variants)!=set(configured): errors.append('master family population differs from publication')
    for family,count in configured.items():
        if sorted(variants.get(family,[]))!=list(range(count)): errors.append('missing, duplicate or out-of-range variants for '+family)
    expected_count=sum(configured.values())
    if len(records)!=expected_count or set(records)!={f'LCUF-{n:06d}' for n in range(1,expected_count+1)}: errors.append('master count or record identity population differs from publication')
    if build_receipt.get('status')!='PASS' or build_receipt.get('records')!=expected_count or build_receipt.get('family_count')!=len(configured): errors.append('build receipt population differs from publication')
    if build_receipt.get('master_sha256')!=master_sha256: errors.append('compressed master hash differs from build receipt')
    return errors

def validate(root=ROOT,replay=True):
    schema=strict_json((root/'schemas/core_record.schema.json').read_text(encoding='utf-8')); refuse_remote(schema)
    Draft202012Validator.check_schema(schema); validator=Draft202012Validator(schema)
    provenance=strict_json((root/'provenance/UPSTREAM_SOURCES.json').read_text(encoding='utf-8'))
    pinned=next(x['sha256'] for x in provenance['sources'] if x['upstream_relative_path']=='fabric_language/lcuf.py')
    if hashlib.sha256((root/'runtime/lcuf.py').read_bytes()).hexdigest()!=pinned: raise ValueError('frozen runtime differs from pinned upstream source')
    runtime=build_core.load_runtime(root)
    records={}; failures=[]; counts=collections.Counter(); family_parts=collections.defaultdict(set); rule_counts=collections.Counter()
    registry=strict_json((root/'specification/RULES.json').read_text(encoding='utf-8'))
    # Accommodate either a flat rule list or a documented rule registry object.
    rules=registry if isinstance(registry,list) else registry.get('rules',registry.get('requirements',[]))
    known={r.get('id') or r.get('requirement_id') for r in rules}
    with gzip.open(root/'datasets/core_conformance.jsonl.gz','rt',encoding='utf-8') as stream:
        for line,raw in enumerate(stream,1):
            try: record=strict_json(raw)
            except (ValueError,UnicodeError,RecursionError) as e:
                failures.append({'line':line,'errors':['strict JSON rejection: '+str(e)]}); continue
            if not isinstance(record,dict): failures.append({'line':line,'errors':['record must be a JSON object']}); continue
            rid=record.get('record_id'); errors=check_record(record,validator,runtime,replay)
            if rid in records: errors.append('duplicate record identity')
            if not set(record.get('requirement_ids',[])).issubset(known): errors.append('unknown formal requirement identity')
            if errors:
                failures.append({'line':line,'record_id':rid,'errors':errors}); continue
            if any(k not in record for k in ('expected','family','partition','requirement_ids','variant')) or not isinstance(record.get('expected'),dict) or 'admission' not in record['expected']: continue
            records[rid]=record; counts[record['expected']['admission']]+=1; family_parts[record['family']].add(record['partition']); rule_counts.update(record['requirement_ids'])
    seen=set()
    family_registry=strict_json((root/'datasets/CORE_FAMILY_REGISTRY.json').read_text(encoding='utf-8'))
    build_receipt=strict_json((root/'validation/CORE_BUILD.json').read_text(encoding='utf-8'))
    population=population_errors(records,family_registry,build_receipt,hashlib.sha256((root/'datasets/core_conformance.jsonl.gz').read_bytes()).hexdigest())
    failures.extend({'errors':[e]} for e in population)
    for part in ('reference','development','challenge'):
        with gzip.open(root/f'datasets/core_{part}.jsonl.gz','rt',encoding='utf-8') as stream:
            for line,raw in enumerate(stream,1):
                try: record=strict_json(raw)
                except (ValueError,UnicodeError,RecursionError) as e:
                    failures.append({'partition':part,'line':line,'errors':['strict JSON rejection: '+str(e)]}); continue
                if not isinstance(record,dict) or 'record_id' not in record or 'partition' not in record: failures.append({'partition':part,'line':line,'errors':['invalid partition record shape']}); continue
                rid=record['record_id']
                if rid not in records or not build_core.equal_json(records[rid],record) or record['partition']!=part or rid in seen: failures.append({'partition':part,'line':line,'record_id':rid,'errors':['master/partition identity or content mismatch']})
                seen.add(rid)
    if seen!=set(records): failures.append({'errors':['partition coverage differs from master']})
    if any(len(parts)!=1 for parts in family_parts.values()): failures.append({'errors':['family crosses partitions']})
    result={'status':'PASS' if not failures else 'FAIL','master_records':len(records),'master_and_partition_record_copies':2*len(records),'counts':dict(counts),'family_count':len(family_parts),'formal_requirements_with_primary_cases':len(rule_counts),'primary_requirement_case_counts':dict(sorted(rule_counts.items())),'universal_acceptance_checks':['LCUF-ID-002','LCUF-RES-002','LCUF-RES-003','LCUF-SEM-005','LCUF-SEM-006'],'schema_draft':'2020-12','fresh_reference_execution':replay,'source_hashes_and_text_projection':True,'master_partition_equality':True,'family_disjoint_partitions':True,'failure_count':len(failures),'failures':failures[:100],'scope':'Synthetic source conformance and host-reference outputs; no native execution, network delivery, physical arithmetic theorem or machine-checked proof.'}
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--metadata-only',action='store_true'); args=parser.parse_args()
    result=validate(replay=not args.metadata_only); rendered=json.dumps(result,indent=2)+'\n'
    (ROOT/'validation/CORE_VALIDATION.json').write_text(rendered,encoding='utf-8'); print(rendered,end=''); sys.exit(0 if result['status']=='PASS' else 1)
