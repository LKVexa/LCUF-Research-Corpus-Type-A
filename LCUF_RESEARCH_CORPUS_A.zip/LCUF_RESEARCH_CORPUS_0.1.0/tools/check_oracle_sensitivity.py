"""Inject bounded reference faults and test whether constructed corpus oracles detect them."""
import json, types
import build_core

ROOT=build_core.ROOT
MUTATIONS=[
 ('addition_replaced_by_subtraction',"value=args[0]+args[1]","value=args[0]-args[1]"),
 ('receiving_capability_check_disabled',"if not required_caps.issubset(grants.get(site,[])):","if False:"),
 ('sending_capability_check_disabled',"if 'fabric.send' not in grants.get(a['site'],[]):","if False:"),
 ('step_limit_check_disabled',"if total>sites[site]['steps']:","if False:"),
 ('retained_payload_limit_check_disabled',"if total>sites[site]['memory']:","if False:"),
 ('lexicographic_ready_choice_reversed',"chosen=ready[0]","chosen=ready[-1]"),
 ('exact_effect_capability_contract_disabled',"if set(r['effects'])!=required_effects or set(r['caps'])!=required_caps:","if False:"),
 ('local_assertion_admission_disabled',"if args[0]!=args[1]: fail('constant assertion fails',r['line'])","if False: fail('constant assertion fails',r['line'])"),
 ('receipt_result_hash_replaced',"'result_sha256':hash_value(value)","'result_sha256':'0'*64"),
 ('receipt_emission_suppressed',"if r['evidence']=='receipt':","if False:"),
]

def fixtures():
    cases=[]
    for family in build_core.POSITIVE_FAMILIES:
        src,oracle,_=build_core.positive(family,0); cases.append((family,src,'accept',oracle))
    for family,(needle,rule,fn) in build_core.NEGATIVES.items(): cases.append((family,fn(build_core.base(),0),'reject',needle))
    for family in build_core.CUSTOM_NEGATIVES:
        src,needle,rule=build_core.custom_negative(family,0); cases.append((family,src,'reject',needle))
    return cases

def run():
    text=(ROOT/'runtime/lcuf.py').read_text(encoding='utf-8'); reports=[]; cases=fixtures()
    for name,old,new in MUTATIONS:
        if old not in text: raise AssertionError('mutation target absent: '+name)
        changed=text.replace(old,new); model=types.ModuleType('lcuf_fault_'+name)
        exec(compile(changed,'<trusted reference fault injection>','exec'),model.__dict__)
        caught=[]; crashes=[]
        for family,src,expected,oracle in cases:
            try:
                observed=build_core.evaluate(model,src)
                correct=(observed['admission']=='accept' and build_core.equal_json(observed['values'],oracle['values']) and ('row_order' not in oracle or observed['row_order']==oracle['row_order'])) if expected=='accept' else observed['admission']=='reject' and oracle in observed['diagnostic']
                if not correct: caught.append(family)
            except (model.Diagnostic,AssertionError): caught.append(family)
            except Exception as error: crashes.append({'family':family,'type':type(error).__name__,'message':str(error)})
        reports.append({'fault':name,'mutant_source_sha256':build_core.digest(changed.encode('utf-8')),'reference_text_sites_changed':text.count(old),'fixtures_run':len(cases),'oracle_detections':len(caught),'detecting_families':caught,'unexpected_tool_failures':crashes,'status':'DETECTED' if caught and not crashes else 'UNRESOLVED'})
    result={'status':'PASS' if all(r['status']=='DETECTED' for r in reports) else 'FAIL','injected_faults':len(reports),'fixtures_per_fault':len(cases),'mutant_fixture_runs':sum(r['fixtures_run'] for r in reports),'mutations':reports,'scope':'Sensitivity to ten specified synthetic reference faults. This is neither exhaustive mutation adequacy nor independent runtime certification.'}
    build_core.dump(ROOT/'validation/ORACLE_SENSITIVITY.json',result); print(json.dumps(result,indent=2)); return result

if __name__=='__main__':
    result=run(); raise SystemExit(0 if result['status']=='PASS' else 1)
