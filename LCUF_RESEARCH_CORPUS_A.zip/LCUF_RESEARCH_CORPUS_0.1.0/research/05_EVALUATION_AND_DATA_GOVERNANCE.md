# Evaluation protocol and corpus governance

Document ID: LCUF-R-05. Revision: 0.1.0. Status: proposed evaluation and data policy. Historical audit observations are provenance; no future native benchmark, model-training result or independent research review is asserted.

## Research units and independent oracles

EVAL-01 defines the evaluation unit as a semantic case cluster, not a raw record line. A cluster contains source, declared supported profile, independent expected relation, positive/negative pair, relevant boundary variants, template family and provenance. Parameter changes, renamed identifiers or different example IDs do not automatically create independent cases. All observations identify compiler/runtime/image/policy versions, input digests, test environment, exact outcome and evidence category.

For the base profile the oracle uses independent integer/Boolean/text calculations, range rejection and exact graph/authority expectations. It does not import the compiler's implementation functions to compute its expected result. A paired mutant deliberately changes an operator, cap, route, expected literal, boundary check or commit order. An oracle must reject the mutant to count as independently discriminating. The repaired JA test fixtures retain literal fixture expectations and separately assert the actual quantified monotonic invariant; comparing `result` to the same expression that computed it would supply a weak oracle. Integer sanity checks are scoped to their fixture interpretation, not a proof of JA coupled arithmetic.

Non-scalar oracles use a declared relation: tensor shape/dtype correctness and numerical tolerance; scene coordinate transforms with independent reference cases; motion joint/clock bounds; proof-checker validation of exact proposition; security denied-flow observations; federation backend activation count and durable recovery state. Tolerance is selected before seeing candidate output. A threshold changed after observing results creates a new protocol revision with rationale, and old results remain visible.

## Preregistered experiment record

The proposed record contains experiment ID; hypothesis and falsifier; artifact/version manifest; scenario population and sampling; grouping/splits; oracle specification/version; seeds and environmental nondeterminism; hardware/hypervisor/driver identities; repetition and stopping rule; measured outcomes; exclusion criteria; uncertainty method; resource budgets; analysis plan; actual reviewer/conflict fields; and expected evidence category. There are no filled fictional reviewers or measured values in this proposal.

EVAL-02 freezes cases and oracles before execution. EVAL-03 records every scheduled run, including crash, rejection, timeout, infrastructure failure and incomplete observation. Infrastructure exclusions are independently justified and counts retained. EVAL-04 separates implementation tuning cases from final held-out cases. EVAL-05 reports expected-class correctness, false acceptance, false rejection and crash separately; an expected rejection correctly observed is a passing negative test, while a positive silently admitted with wrong result is a defect.

## Measurement layers

### Current synthetic core dataset: bounded delivered scope

The research package's [core build record](../validation/CORE_BUILD.json) records a successful host build/check of 10,144 master records: 4,096 accepted constructions, 4,704 rejected mutations and 1,344 metamorphic pairs, comprising 11,488 primary/paired source evaluation slots. The [family registry](../datasets/CORE_FAMILY_REGISTRY.json) assigns 144 labels: 32 positive families with 128 variants each, 98 negative families with 48 variants each, and 14 metamorphic families with 96 pairs each. The partitions are reference 5,872, development 1,728 and challenge 2,544 records, with family-label isolation. The build record binds a runtime digest and master digest; final validation and oracle-sensitivity reports are separate evidence objects.

These are synthetic parameter/identifier variants, not 10,144 independently authored designs. All primary byte strings are unique, but shared graph patterns and construction logic remain. Family-label separation does not establish graph-template isolation, blind research evaluation, model-training generalization or independence of variants. Both original and paired programs contribute evaluation slots; slots are not new independent records. The independent analytic expected values and actual host outcomes support the base local-model scope only. Future native, transport and mathematical datasets must report their own observations and assumptions.

| Layer | Main outcomes | Necessary controls | Disallowed conclusion |
|---|---|---|---|
| Parser/profile | Complete-consumption rate, diagnostics, feature/effect coverage | Grammar identities, unseen templates, negative pairs | All corpus features implemented from record count |
| Admission | Incorrect accepts/rejects, overflow/resource checks | Changed caps/site/budget/unknown profile | Native safety from static acceptance alone |
| Local simulation | Exact values, DAG order, receipt reproducibility | Independent scalar oracle, source vs semantic digest variants | Physical remote transfer or boot execution |
| Native scalar image | Value/error equivalence, boot success, full resource peaks | Target identity, same cases, overflow/extrema/Unicode | Heterogeneous global determinism |
| Drivers | Invalid-buffer denial, reset cleanup, queue pressure | Adversarial device/descriptor inputs | DeepML race freedom from driver health |
| Federation | Duplicate activation, uncertainty, recovery, stale authority window | Crash cuts, lost replies, partitions, epoch changes | Exactly-once general external effects |
| Nested federation | Non-amplification, route denial, cycle/depth checks | Independent policies at each hop | Parent membership implies child authorization |
| Coupling8s | Dimensional validity, boundary behavior, numerical sensitivity | Authoritative law, precision/solver/Score definitions | Physical predictive validity from algebraic evaluation |
| UI/experience | Rendered interaction, keyboard/focus/reduced motion results | Actual browser/device/assistive workflows | Accessibility conformance from a generated field |

For UI bridges, WCAG 2.2 supplies reference success criteria and conformance conditions; a projection containing accessibility attributes is insufficient to establish them. Evaluation names tested pages/interactions and actual methods. [WCAG 2.2](https://www.w3.org/TR/WCAG22/).

Performance experiments report cold/warm boot separately; compiler time separately from runtime; payload throughput separately from total wire bytes; median and tail latency with workload/queue level; peak RAM including metadata/driver/ledger; CPU/fuel; storage amplification; retry rate; and sustained error behavior. Compare equivalent workloads, hardware and policy. Include the ordinary isolated-service baseline and a minimal specialized image. No favorable aggregate may omit a resource class or security check enabled only in one configuration.

## Statistical and repetition policy

Deterministic conformance is enumerated wherever finite boundaries permit; repeated identical local runs check reproducibility and are not new semantic samples. Fault tests enumerate crash points and event schedules with reproducible seeds. Randomized campaigns record all seeds and uncovered state space. Each report states observed failures and tested population rather than interpreting zero observed failures as zero failure probability.

If sampling claims are made, group-level independence assumptions and the estimator must be specified. Resampling must operate on independent case clusters, not duplicate parameterized records. Report per-family results and worst-case safety outcomes along with aggregate metrics. Native timing confidence intervals require a declared method, run ordering, warmup, instrumentation overhead and environment drift checks; a particular statistical method is not prescribed here as universally valid. Safety-critical acceptance uses explicit fail conditions, not average accuracy alone. A single confirmed authority amplification, unchecked overflow or duplicate irreversible effect blocks that scoped release gate pending review.

## Corpus lineage and qualification

DATA-01 keeps immutable originals and separately identified corrected copies. Every record links original archive/member/source hashes, update recipe/version, changed fields, rationale, current source hash, historical expectation and observed result. Qualified records can preserve historical `pass` labels while stating `modeled_not_executed`, `observed_result=null`, `native_execution_eligible=false`. Removing the qualifier during a derived export is a data-governance error. Derived AST/capability/proof metadata is regenerated by an actual named frontend or labeled historical/requiring revalidation.

DATA-02 separates document records, source examples, metadata preambles, generated projections, observed execution results and external references. The Programming suite's two large rewritten-text wrappers are documents; its many repeated blocks cannot be presented as independently executed programs. The Service corpus's coupling preamble is not another program. MSSL sealed records retain original authority and seals; a derived fact is a new provenance-bearing object, not an unnoticed reseal.

DATA-03 maintains a record schema with stable case ID, corpus/version/source authority, raw and semantic hashes, template family, generator identity if known, feature coverage evidence, declared expected class, independent oracle status, source/derived maturity, arithmetic profile, rights/notice status, contamination group, split and observation links. Unknown generator, rights or grammar facts remain unknown rather than inferred from names.

## Template diversity and contamination controls

The JA audit observed very low numeral-normalized template counts in several 10,000-record masters: Operations and Training each 2; Service 3; Agent/Data/Proof each 4. This does not invalidate the author-provided law or all cases. It means raw record count is a poor measure of semantic diversity and random line splits can leak almost identical structures.

DATA-04 proposes three similarity layers: exact source hashes; declared normalized syntax fingerprints after a trustworthy parser; and provenance/generator-family grouping. Until a parser exists, lexical normalization is a documented heuristic and can overmerge numeric semantics or undermatch renamed structure. Group all replicas, repaired forms, source/shard/script duplicates, and variants from one generator lineage into one split group. Keep negative variants with their positive family when preventing evaluation leakage, while retaining expected outcomes separately. Cross-corpus copied templates are grouped across archive boundaries.

DATA-05 creates development, validation and blind evaluation partitions by family/authoring lineage, plus an out-of-family adversarial set independently authored after baseline freeze. No source-derived semantic label is accepted solely because a template's majority says pass. Evaluate feature coverage by actual syntax/semantic constructs exercised, including operator/effect combinations, nested structure, resource boundaries and failure transitions. Examples naming `join` without join syntax do not cover joins.

Training on these corpora, if later authorized, requires explicit training-use decisions and rights review. Split membership, model checkpoint identity, training revision and exposed test assets are recorded. A model or human developer who saw a held-out case moves that case into an exposed category; it does not remain blind because its file is renamed. Public release of a benchmark makes future reuse a public/known benchmark, so fresh hidden cases are needed for subsequent independent claims. No model training occurs as part of this research document.

## Coupling8s scientific protocol

The mathematical profile is evaluated in two separable stages. Stage M checks representation and algebraic/domain behavior against the preserved law: five-coordinate lattice bounds, independence expression domain, positive metric/width conditions, support-factor range assumptions, S³ fibre embedding, finite outputs and admission conjunction. Stage S would test empirical predictive usefulness only after `Score`, data provenance, measurement uncertainty, baseline M7/M8 comparison and threshold meaning are defined. These stages must not collapse into a single pass label.

Proposed numerical campaigns include singular/near-singular C4, zero e, scale changes, vanishing widths, support near zero/one, boundary product behavior, phase periodicity, triadic symmetry choices, and sensitivity to metric/solver/precision. Expected mathematical properties must be validated under explicit premises; for example, multiplying support factors gives a [0,1] bound only if every factor is itself constrained to [0,1]. Held-out score evaluation and ablation are proposals that require domain definitions and real observations. The image's `Score(M8)-Score(M7)` expression alone does not prescribe a dataset or confer experimental validation.

## Dataset publication and withdrawal

DATA-06 requires a release manifest of hashes, schema versions, counts by record kind/evidence class, duplicate/template statistics, split recipe, known defects and source notices. Counts include documents and examples separately. All transformations are reproducible and preserve provenance. A source correction creates a supersession relation; consumers can trace stale derived artifacts. DATA-07 tracks contamination, incorrect expectations and rights disputes with affected IDs, impact and withdrawal/replacement decisions by an actual authorized party. Missing authority is recorded as pending, not invented. Dataset checks close integrity/organization obligations; they do not close compiler, native or physical truth claims.
