# LCUF research corpus: charter and reading contract

Document ID: LCUF-R-00. Revision: 0.1.0. Prepared: 2026-10-09. Status: proposed research programme; the frozen LCUF/0.1 prototype is an implemented local model. Institutional means reviewable engineering records, explicit responsibility, and reproducible evidence here. It does not imply an institutional affiliation, independent review, accreditation, certification, or endorsement.

## Purpose and research object

LCUF studies how column-authored programs can carry sufficient typed, resource, effect, placement, and evidence information to specialize a small execution image and compose independent execution domains. Its name expands to LKVexa Columned Unikernel Fabric. Hyperfederation is a proposed composition of federations with bounded delegation and explicit nested routes; it does not presently designate an implemented network.

The research object has five distinguishable layers: authoring language, compiler and profile adapters, native image, authenticated federation, and evidence governance. A result about one layer does not establish a result about the other four. A source is not an execution; a modeled AST is not a parser output; a content hash is not an authentication credential; an authenticated image is not a verified program. This corpus makes each promotion an explicit obligation with a falsifying experiment.

The frozen baseline is the prior updated release's [LCUF specification](../provenance/upstream_snapshot/fabric_language/LCUF_SPEC.md), [architecture](../provenance/upstream_snapshot/fabric_language/ARCHITECTURE.md), [prototype](../provenance/upstream_snapshot/fabric_language/lcuf.py), and [25-input contribution matrix](../provenance/upstream_snapshot/fabric_language/CORPUS_CONTRIBUTIONS.csv). Their precise digests and portable references are recorded in `BASELINE_PROVENANCE.json`. The bundled `provenance/upstream_snapshot` is a **selected evidence snapshot** retaining referenced audits/specifications and baseline artifacts with their original relative structure and bytes; it is not the complete prior collection or all corpus payloads. This volume documents that frozen baseline, not any subsequent extension elsewhere in the research package. The runtime maintainer's current tests and release manifest remain authoritative for newer implementation results.

## Baseline boundary

The prototype parses the exact `LCUF/0.1` header and twelve columns: `id`, `site`, `profile`, `op`, `inputs`, `output`, `type`, `effects`, `caps`, `after`, `budget`, `evidence`. Its closed operation set is `const`, `add`, `mul`, `copy`, `assert_eq`, `emit`; profiles are `lcuf.scalar`, `lcuf.fabric`, and `lcuf.test`/`lcuf.evidence` as appropriate. Scalar types are signed 64-bit integer, Boolean, Unicode text, and unit. It checks a dependency DAG, one writer, local ownership, explicit directed transfer links and sender/receiver grants, exact effects/capabilities, arithmetic overflow, declared step reservations, and retained payload sizes. It lowers and simulates in a single Python process. Its target plan has no bootable image.

The baseline has no sockets, native driver, JA or DeepML compiler, tensor runtime, dynamic federation membership, remote signing/attestation, durable retry service, or native resource enforcement. Its receipt chain detects alterations relative to a trusted chain head; its producer identity is the local simulation marker. Every native ABI and federation contract in the research volumes is proposed. Existing columned LCTL has its own eighteen-cell source authority and is not identical to the twelve-column LCUF dialect.

## Foundational arithmetic

The author-provided **8S Penteract–S³ Master Coupled Mechanics Law** is retained as a foundational JA reference. The reference uses five lattice coordinates indexed 4 through 8, a three-sphere fibre in four ambient coordinates, pairwise and triadic coupling, support factors, independent fifth-coordinate evidence, and an admission conjunction based on independence and a score difference. LCUF integer multiplication does not redefine that coupled arithmetic. A bounded `Count` sanity check in a repaired JA fixture does not complete JA semantics or authorize replacing coupled operators with ordinary integers.

The older records' `d4`/`g4`/`TRUE_4D` coupling vocabulary and the supplied five-coordinate law require a versioned semantic migration, identified by the previous audit as FOUNDATION-01. Research must preserve the historical records, source image, equations, interpretation decisions, domain restrictions, and numerical assumptions separately. Native admission, predictive validity, physical realization, and federation correctness require their own evidence. A future held-out scoring protocol is a research choice; it is not text supplied by the image.

## Document map

| Volume | Research decision and review product |
|---|---|
| `01_ARCHITECTURE_AND_ADAPTERS.md` | Formal system boundaries, refinement obligations, all 25 input mappings, adapter version negotiation and rejection rules |
| `02_NATIVE_UNIKERNEL_CONTRACTS.md` | Proposed ABI, image identity, reproducible build, drivers, bounded resources, boot and update gates |
| `03_FEDERATION_PROTOCOL.md` | Proposed authenticated transfer, nested membership, admission, durable idempotency, crash and revocation states |
| `04_THREAT_MODEL_AND_SECURITY.md` | Assets, adversaries, trust assumptions, requirements and attack experiments |
| `05_EVALUATION_AND_DATA_GOVERNANCE.md` | Preregistered evaluation, contamination controls, template diversity, source qualification and dataset release |
| `06_ASSURANCE_RELEASE_AND_ROADMAP.md` | Claim ledger, responsibility, assurance argument, release review and dependency-gated research stages |
| `07_SCENARIO_CATALOG.md` | Operational and adversarial acceptance cases with observers and disqualifying outcomes |
| `08_PRIMARY_SOURCE_BIBLIOGRAPHY.md` | Official standards and original technical sources, dates, scope of use and status |

Machine-readable companions are `PROFILE_ADAPTER_REGISTRY.json`, `SCENARIOS.json`, `CLAIM_REGISTRY.json`, `BIBLIOGRAPHY.json`, and `BASELINE_PROVENANCE.json`. They are research registries, not implementation configuration or executed certification reports.

## Normative interpretation within the proposal

Requirement identifiers `ARC`, `ADP`, `NAT`, `FED`, `SEC`, `EVAL`, `DATA`, and `GOV` denote obligations proposed for future implementations. The words MUST and SHALL inside a proposed contract mean a candidate must meet that contract to claim that candidate profile. They do not assert that current code already meets it. Every experiment records `specified`, `modeled`, `statically_checked`, `locally_simulated`, `natively_executed`, `remotely_attested`, or `independently_verified` alongside a bounded scope; these are evidence categories rather than a universal ordinal ranking. Different categories can coexist for one artifact.

Unfilled ownership, budget, target platform, trusted authority, and external review slots stay unassigned. Review signatures may be collected only from actual named reviewers, with their conflict declarations and scope. Prior source licensing and authorship notices remain preserved; this work does not establish new legal ownership or grant rights to the source corpora.

## Research questions and falsifiability

1. Can an adapter preserve observable source semantics while refusing unknown effects and unsupported arithmetic? Counterexample: a source accepted with an effect absent from its lowered policy contract.
2. Can a small native image enforce the same admitted arithmetic and resource envelope? Counterexample: native overflow differs, a denied driver is accessible, or payload bounds hide unbounded runtime allocation.
3. Can nested federation prevent authority amplification and distinguish durable success from uncertainty? Counterexample: an ancestor grants an action denied by a child, or a retry duplicates an external effect.
4. Can evidence remain useful across compiler/profile/policy changes without overstating it? Counterexample: a historical modeled pass is promoted to a native pass without a matching run and independent oracle.
5. Can the 8S profile be represented with explicit dimensional and numerical assumptions while preserving its author-provided foundation? Counterexample: an unreviewed adapter collapses the fifth coordinate or silently substitutes scalar `Count` semantics.

The programme is successful only when concrete artifacts and adversarial observations close these obligations. Document volume, dataset count, borrowed standards terminology, and generated diagrams are not substitutes for that evidence.
