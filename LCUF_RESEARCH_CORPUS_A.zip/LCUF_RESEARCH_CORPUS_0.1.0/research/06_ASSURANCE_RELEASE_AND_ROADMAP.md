# Assurance case, release governance and research roadmap

Document ID: LCUF-R-06. Revision: 0.1.0. Status: proposed governance and assurance argument. Companion: `CLAIM_REGISTRY.json`. No external review, accreditation, standard certification, institutional affiliation or legal ownership is asserted.

## Evidence-bearing claim contract

A claim is the tuple `(claim_id, proposition, scope, artifact_set, assumptions, method, evidence_set, defeaters, reviewer_state, decision)`. Proposition and scope must be understandable without a marketing label. Artifact set includes exact source/IR/profile/adapter/image/policy/target/dataset digests as applicable. Method identifies implementation, checker, oracle and environment. Evidence is an immutable observation or proof object with producer and provenance. Decision is `unassessed`, `supported_within_scope`, `refuted`, `incomplete`, `superseded` or `withdrawn`; it is not a floating confidence score.

GOV-01 forbids promoting a modeled expectation into an observation. GOV-02 forbids extending a claim across changed artifact identities without explicit compatibility/refinement evidence. GOV-03 requires defeaters and assumptions alongside support. GOV-04 requires a real reviewer identity, scope and conflict declaration before calling a result independently reviewed. Null reviewer fields mean no reviewer assigned. GOV-05 requires a release to expose unsupported areas and gate failures together with successes.

| Evidence category | Minimum record | What it can support | What it cannot establish alone |
|---|---|---|---|
| Specified | Authoritative versioned text, provenance, exact requirement | Intended contract | Correct implementation |
| Modeled | Model/assumptions/version/input/output | Consequences inside the model | Native/device observation |
| Statically checked | Checker version, proposition/subset, diagnostics | Stated static property under premises | External effects or physical safety |
| Locally simulated | Runtime/source/IR/environment, exact outputs and trace | Local operational behavior | Network authentication or native boot |
| Natively executed | Image/target/driver/supervisor, actual observations | That target/run's behavior | General correctness or other targets |
| Remotely attested | Verified evidence and freshness, verifier appraisal/policy | Particular platform claims under trust model | Application semantics or truthful outputs by itself |
| Independently verified | Actual independent party/method/proposition/evidence | The reviewed bounded conclusion | Unreviewed properties or institutional endorsement |

These categories are orthogonal. A native program can still have only a modeled proof claim. A proof may establish a theorem without measuring performance. A valid signature may authenticate a false assertion. A content hash may identify bytes without identifying their author.

## Structured assurance argument

For portable artifact-bound reports, a future packaging profile may use the in-toto Statement model, which binds subject digests to a named predicate type. This is a reference design for claim packaging, not a claim that current receipts implement that specification or that a signed statement is true. [in-toto Statement v1](https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md).

Top goal G0 is proposed: **a released LCUF deployment performs only its admitted actions, with defined bounded outcomes and traceable evidence, within a named target and fault model**. G0 is deliberately not marked satisfied for the future system. Strategy S0 decomposes semantic preservation, authority confinement, resource enforcement, recovery behavior and evidence integrity. The frozen local-model evidence can support only the local subset.

```mermaid
flowchart TD
  G0[Proposed G0: bounded admitted deployment behavior] --> G1[Source to IR semantics]
  G0 --> G2[Authority and isolation]
  G0 --> G3[Resource and native execution]
  G0 --> G4[Recovery and federation safety]
  G0 --> G5[Evidence and governance integrity]
  G1 --> E1[Independent oracle and translation cases]
  G2 --> E2[Source effect inference and denial tests]
  G3 --> E3[Measured boot and resource envelope]
  G4 --> E4[Crash cuts, partitions, durable effect counts]
  G5 --> E5[Provenance, contamination, actual review]
  A[Assumptions: crypto, storage, platform, domain semantics] -.-> G0
  D[Defeaters: wrong oracle, compromised key, unknown effect] -.-> G0
```

| Subgoal | Proposed argument | Required evidence | Defeater that reopens it |
|---|---|---|---|
| G1 | Supported parser/adapter preserves types and observable trace | Complete parse, source maps, independent fixtures, refinement checks, rejected unknown syntax | Undeclared effect, altered dimensionality, oracle mirrors compiler |
| G2 | Grants/route intersections and isolation contain actions | Denial observations, exact driver closure, compromised-image isolation experiment | Child deny bypass, compromised same-domain driver escapes site |
| G3 | Native image realizes admitted scalar/error behavior within limits | Actual boot identity, differential results, full accounting, exhaustion failures | Overflow mismatch, unmeasured heap, noncooperative code defeats limit |
| G4 | Retries cannot duplicate a committed effect under declared durability assumptions | Durable inbox/outbox, backend activation counts, exhaustive crash cuts, uncertain-state tests | Ledger rollback, split authority, external effect outside transaction |
| G5 | Results remain scoped to exact artifacts and authentic observations | Claim/evidence manifests, hash verification, real review records, split lineage | False modeled-pass promotion, poisoned holdout, truncated unauthenticated chain |
| G6 | Arithmetic foundation is preserved and domain assumptions explicit | Law provenance, FOUNDATION-01 review, five-coordinate schema, numerical boundary cases | Silent d4 migration, undefined Score invented, scalar Count treated as full JA |

Assumptions have IDs and owners when assigned: A-CRYPTO standard algorithm/implementation assumptions; A-STORAGE atomic durable boundary; A-PLATFORM supervisor/hypervisor/DMA protections; A-AUTH trustworthy provisioning/current policy; A-SEMANTICS source authority and numerical premises; A-ORACLE independent expected relation. An experiment outside those assumptions does not silently validate G0. A claim ledger is review infrastructure, not an automatic theorem prover.

## Responsibility and decision separation

The proposed roles are source steward, profile owner, compiler maintainer, target/runtime maintainer, federation operator, security reviewer, dataset curator, independent evaluator and release decision-maker. They are role slots, currently unassigned in this research volume. One person may hold several development roles, but independence claims must declare overlap. Source stewards resolve interpretation/version issues; they cannot create observed native outcomes by approval. Operators define actual trust anchors and revocation policy; compiler maintainers cannot broaden them. Dataset curators track splits/rights/provenance; they cannot certify kernel execution from labels.

GOV-06 records decisions with actual author, timestamp, rationale, alternatives, artifact scope, dissent and follow-up obligations. A pending decision is not filled with an invented committee. Source licensing notices remain intact; actual rights review is needed before new distribution/training uses when not established by source terms. Standards citations guide engineering and do not grant project ownership or external endorsement.

## Release gates and stop conditions

| Gate | Candidate release class | Entry evidence | Exit evidence and blockers |
|---|---|---|---|
| R0 | Local-model research baseline | Frozen artifacts and independent base fixtures | Six-operation scope documented, checks pass; no native/network claim |
| R1 | One versioned source adapter | Resolved authority and declared subset | Complete grammar/inference/lowering, boundary negatives, independent oracle; unknown effects block |
| R2 | Native scalar image | R0/R1-relevant lowering plus chosen ABI/target | Reproducible image, actual boot, overflow/Unicode/resource/driver denial; unbounded runtime blocks |
| R3 | Two-site authenticated transfer | R2 images, identities, exact wire contract | Authentication/route/copy policy, durable inbox/outbox and fault tests; uncertain effects handled |
| R4 | Nested federation | R3 plus membership/revocation contract | No amplification, cycle/depth/partition/key-rotation tests; stale-policy scope declared |
| R5 | Domain profile/service | R1–R4 as needed, actual tensor/scene/proof/service authority | Source semantics/precision/driver/service oracles; modeled device/proof labels insufficient |
| R6 | External assurance claim | Exact target population and complete evidence | Actual independent review with scope and conflict disclosure; external certification only from real authorized process |

Failure to meet R3 does not invalidate an honest R0 local-model release, but it prevents R3 terminology. Release candidates include manifest, tests/case IDs, observed failures, known gaps, unsupported operation/profile list, reproducibility recipe and withdrawal contact/authority if actually appointed. The candidate is sealed only after final hashes are computed. Changes after sealing create a new revision and supersession link. The original updated release is read as a frozen dependency and is not modified by this research corpus.

GOV-07 distinguishes integrity seal, developer release decision, independent review and externally issued certification. An integrity seal is a content manifest; it does not become an MSSL author seal or a regulatory certificate. GOV-08 makes security-critical confirmed violations stop the affected gate: authority amplification, incorrect arithmetic acceptance, duplicate irreversible external effect, false observation promotion or loss of protected data. Incident scope and evidence are preserved; mitigation is verified before reopening that gate.

## Dependency-gated research roadmap

| Work package | Concrete artifact | Main uncertainty | Falsifying experiment / exit criterion |
|---|---|---|---|
| WP1 Authority and grammar | Exact per-family authority graph; one complete parser | Conflicting historical/reconstructed semantics | Parse entire supported subset; reject unknown productions; independent steward interpretation |
| WP2 Adapter refinement | Typed AST, effect inference, bridge schemas and source maps | Source labels diverge from actual operations/caps | Capability and dimensional mutants rejected; trace refinement on independent cases |
| WP3 Foundation migration | Versioned 8S profile and reviewed d4→five-coordinate mapping | Operator/domain/Score definitions and numerical stability | Singular/boundary/triad/admission tests with declared premises; no silent substitution |
| WP4 Native base | LCABI target supplement, compiler backend, pinned image | Overflow equivalence, full resource accounting, isolation | Boot and execute independent scalar suite; exhaustion and driver denial verified |
| WP5 Durable local effect service | Inbox/outbox schema, transactional backend, recovery implementation | Atomicity gaps around external actions | Every crash cut produces confirmed or explicit uncertain state; no duplicate activation |
| WP6 Authenticated two-site protocol | Wire schema, key provisioning, receiver admission | Replay, downgrade, audience binding and freshness | Lost replies/replayed/conflicting payloads/rotated keys produce defined outcomes |
| WP7 Nested policies | Membership chain, route validator, revocation leases | Parent-child conflict and partition availability | Deny remains deny; cycle/depth invalid; stale window measured |
| WP8 Domain services | Tensor/scene/motion/proof adapters with target supplements | Numeric/layout/time/proof-system compatibility | Actual service traces and independent oracles; no inferred device execution |
| WP9 Evaluation and review | Blind case families, reproducible native campaigns, claim ledger | Template contamination and biased acceptance | Mutants detected, family holdout respected, full failed-run ledger reviewed |

The roadmap has no invented completion dates or assigned institutions. Dependencies determine readiness; documentation and generated source examples can advance independently, but implementation claims require the exit evidence. Candidate selection for native platform, cryptography, encoding, durable backend and governance authority remains an explicit decision record.

## Open technical questions

OQ-01: Which authoritative JA operator semantics and complete grammar resolve the historical coupling vocabulary against the supplied 8S law? OQ-02: What does `Score` measure, and which empirical data/domain would make admission scientifically falsifiable? OQ-03: Which subset of resource bounds can be statically proven, and which need supervisor enforcement? OQ-04: Can ownership/capability inference be made sound across service adapters with foreign effects? OQ-05: Which external backends support transactional effect identity, and how is uncertainty reconciled for the rest?

OQ-06: What maximum stale-authority interval is acceptable during partition, and who is authorized to choose it? OQ-07: How does membership/key continuity survive disaster recovery without revocation rollback? OQ-08: Which heterogeneous numerical profiles admit useful replay equivalence without claiming bit identity? OQ-09: Can driver/image attestation be bound to meaningful workload observations under compromised insiders? OQ-10: How are template families identified before trustworthy parsers exist? OQ-11: What source/training/distribution rights are actually established for each input? OQ-12: Which actual independent parties will review which precise claims?

Each question has a candidate artifact and experiment above. Leaving it visible is more informative than asserting comprehensive execution, proof, federation or certification from a source corpus.
