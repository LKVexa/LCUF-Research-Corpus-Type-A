# Threat model and security requirements

Document ID: LCUF-R-04. Revision: 0.1.0. Status: proposed security model, not security certification. Scope: compiler inputs, admitted IR, images, policy, nested transport, receipts and research datasets. Threats to the six-operation local model are distinguished from threats to the future distributed system.

## Assets and trust boundaries

Protected assets are source authority and semantic identities; site grants and private keys; data confidentiality/integrity; image and driver identity; durable effect/deduplication state; policy and revocation epochs; resource availability; causal evidence; independent test oracles; the author-provided arithmetic foundation; and provenance/rights records. Safety concerns include unintended driver or external service actions. Availability and latency goals must be bounded by deployment assumptions.

Boundary B1 separates untrusted source/archive/document content from compiler/tool authority. B2 separates admitted IR from the native image generator. B3 separates the image from supervisor/hypervisor/device. B4 separates sites and administrative federations. B5 separates historical modeled corpus metadata from observed runtime evidence. B6 separates developer-visible data from blind evaluation and review authority. An input document can describe a capability without being allowed to invoke it. Example strings, comments, instructions and URLs are inert until parsed under the proper declared grammar and authorized workflow.

The frozen prototype checks source syntax and closed operation contracts. Its site labels, local receipt chain and single-process execution do not defend B4. A malicious source may consume compiler parsing resources within host limits, so deployment wrapping needs input limits. A modified external IR supplied directly to library functions requires its own trust/interface contract; the frozen CLI compiles source rather than executing arbitrary external IR. Native sandbox, image-signature, key management and network security claims remain future work.

## Adversary classes and assumptions

| Adversary | Capabilities considered | Security objective |
|---|---|---|
| Malformed-source author | Invalid encoding, huge/deep literals, spoofed declarations, grammar/version ambiguity | Reject boundedly, never infer rights from text |
| Compromised corpus producer | False expected labels, forged modeled AST/caps, copied examples and stale hashes | Preserve provenance; derive checks from source; prevent evidence promotion |
| Active network attacker | Observe, drop, delay, reorder, replay and modify traffic | Peer authentication, integrity, bounded retry, explicit uncertainty |
| Malicious federation member | Valid identity but unauthorized requests, broad grants, forged causal assertions | Independent receiving policy and non-amplifying delegation |
| Compromised image/driver | Arbitrary code inside that protection domain | Isolate other sites; qualify own receipts as compromised; no internal-isolation claim |
| Compromised build/update service | Replace dependencies, toolchain, image or old policy | Pinned closure, independent build/admission, anti-rollback policy |
| Storage-fault/rollback adversary | Loss, torn writes, replay of old ledger/checkpoint | Recover/quarantine; never blindly retry uncertain effects |
| Evaluation manipulator | Train on holdout, duplicate templates, cherry-pick runs, change oracle | Split governance, complete logs, blinded cases, paired failures |

Initial transport safety assumes standard cryptographic primitives remain sound, selected implementations are correctly used, identity keys and trust anchors are provisioned securely, and receiving sites enforce their policies. Initial crash recovery assumes durable storage meets its documented atomicity and ordering contract. Byzantine agreement, compromised hardware, microarchitectural side channels, traffic-analysis resistance and physical actuator safety are not solved by these assumptions. They are tracked as explicit gaps; a target may add separate controls and tests.

## Core invariants

SEC-01 authority non-amplification: every admitted action satisfies `requested ⊆ source_inferred ∩ local_grant ∩ route_grants ∩ current_policy`. SEC-02 semantic binding: changing profile, effect, caps, precision, budget, destination or policy changes the relevant admitted/deployment identity. SEC-03 immutable effect identity: one durable effect key binds one immutable payload; attempts cannot bypass it. SEC-04 fail-closed uncertainty: unknown versions/authority/effects, missing evidence or unrecoverable ledger state cannot become successful admission. SEC-05 resource boundedness: unauthenticated and authenticated traffic have separate bounded accounts, including error replies and ledger growth.

SEC-06 evidence scope: every claim identifies producer, artifact, method, environment, observation and trusted premises. Historical `pass`/`confidence` metadata is not transformed into actual observations. SEC-07 information flow: a denied input does not flow into permitted outputs or receipts outside an explicitly authorized declassification. Security source assertions such as no-leak=false are tests of a claim and not substitutes for an information-flow analysis or independent observations. SEC-08 foundation integrity: an adapter must not silently collapse the five-coordinate 8S model, change operators, or interpret `Count` fixtures as complete JA semantics.

## Requirements and falsifying attacks

| ID | Proposed requirement | Attack/negative test | Required evidence |
|---|---|---|---|
| SEC-09 | Complete parse with exact source version | Comment/string impersonates a grant; trailing code after end | Stable diagnostic; no authority-bearing IR |
| SEC-10 | Exact encoding/schema bounds before allocation | Oversized length, duplicate key, nonfinite scalar, deep nesting | Resource trace, rejection before unbounded allocation |
| SEC-11 | Verified identity/audience and protected policy fields | Copy signed message to another destination/profile | Receiver rejection; signature/transcript decision trace |
| SEC-12 | Current epoch and bounded freshness | Partition plus revoked lease, reboot with old epoch | Maximum stale window measured; reject outside it |
| SEC-13 | Parent cannot broaden child authority | Parent grants driver, child denies driver | Denied activation at child with no side effect |
| SEC-14 | Durable dedupe independent of attempt | Same effect ID, new attempt; then different payload | Existing result first, conflict second, one activation |
| SEC-15 | No stale handle or out-of-bounds driver buffers | Reused generation, wraparound offset, chained descriptors | ABI errors; guard/DMA observations |
| SEC-16 | No secrets in reproducible build artifacts | Search image/build manifest for provisioned test secret | Secret absence; provisioning record separate |
| SEC-17 | Protected update/policy continuity | Old executable with current revocation; old policy with new executable | Current policy enforced; rollback detected |
| SEC-18 | Receipt privacy and bounded disclosure | Denied field appears in error or evidence payload | Redaction tests across success/error/crash paths |
| SEC-19 | Recovery preserves uncertainty | Crash after external action before commit | Explicit uncertain state; no blind duplicate action |
| SEC-20 | Independent expected results | Mutant compiler returns a plausible but wrong result | Independent oracle rejects mutant |
| SEC-21 | Evidence chains detect fork/truncation under named anchor | Alter chain, omit suffix, present two heads | Verification records anchor and detected/undetected scope |
| SEC-22 | Bounded pre-authentication work and replies | Invalid-signature flood, huge chains, many nonexistent statuses | CPU/RAM/egress budgets and rate-limit counters |

Requirements reference scenarios in `07_SCENARIO_CATALOG.md` and gate definitions in Volume 06. Tests exercise both parser and runtime boundaries. Passing a static metadata validator cannot close runtime attack requirements.

## Keys, attestation and receipt trust

Private signing keys belong outside untrusted compiler inputs and preferably outside workload access when the platform permits it. Provisioning, rotation, destruction, compromise reporting and historical validation need named operational authority. A public-key signature proves the signer key authenticated bytes under verification assumptions; it does not prove those bytes describe a true execution. Receipt verifiers distinguish key validity, artifact binding, policy admissibility, numerical correctness and independent corroboration.

RATS separates an attester's evidence, verifier appraisal and relying-party decision. A proposed native receipt may bind a platform measurement and freshness challenge using that architecture, but workload correctness and output validity remain separate arguments. A remote assertion lacking genuine platform evidence must not be labeled hardware attestation. [RFC 9334](https://www.rfc-editor.org/info/rfc9334/).

A hash chain without an external trusted checkpoint cannot establish that a suffix was not withheld. A signing key compromised with a workload can forge its local narrative; external observations, a protected signer, replicated witness or independently held checkpoint may reduce this risk under specified assumptions. No witness/consensus mechanism is currently supplied. Receipts minimize personally identifying and secret data, bind content digests where feasible, and enforce current disclosure policy. Retention/deletion conflicts need actual legal/contractual authority; this proposal assigns none.

## Incident and residual-risk records

A proposed incident record includes suspected interval, affected image/profile/key/epoch identities, observable symptoms, preserved logs/digests, uncertain external effects, containment decision, evidence invalidation scope, recovery authorization and unresolved questions. A receipt is not deleted to hide uncertainty; access to retained evidence can be restricted. Deduplication state can retain an opaque identity after payload deletion where permitted, but its retention basis and replay horizon must be documented.

Required incident exercises are key compromise, image compromise, ledger rollback, membership authority compromise and evaluation contamination. Recovery requires a fresh trust decision, not just rerunning a successful script. Development and release practices draw on NIST SSDF's secure software development framework; this corpus proposes traceable practices and does not claim NIST certification or complete framework conformity. [NIST SP 800-218, February 2022](https://csrc.nist.gov/pubs/sp/800/218/final).

Open risks include side channels inside shared hardware, compromised supervisor/hypervisor, authenticated insiders lying about execution, subtle compiler miscompilation, unsafe external services, numerical instability of coupled models, unavailable global freshness during partitions, and data rights constraints on audit retention. Each target release must state which remain accepted, which are mitigated and who actually authorized that bounded decision.
