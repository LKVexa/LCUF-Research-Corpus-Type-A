# Architecture and versioned profile adapter contracts

Document ID: LCUF-R-01. Revision: 0.1.0. Status: architecture proposal, with explicitly identified frozen-baseline facts. Companion: `PROFILE_ADAPTER_REGISTRY.json`.

## System model and boundaries

Let a module be M=(V,E,S,G,L,P,B). V is its finite set of rows, E its dependency edges, S its sites, G site grants, L directed links, P exact profile identities, and B resource contracts. A writer map W assigns at most one row to each value identity. Site(v) owns v's output. In the frozen baseline, an input edge is legal when its writer is at the consumer's site, or the consumer is a `copy` row with an explicit remote edge, sender grant, receiver grant, and directed link. `after` edges constrain local order and do not supply values. E must be acyclic. A fixed lexical ready-row rule produces a deterministic local-model order; it is not a global ordering service.

ARC-01 requires immutable values at the base-language boundary. Future mutable state lives in an explicitly versioned state profile with declared ownership, transaction semantics and conflict policy. ARC-02 requires that ordinary dependency edges never transfer authority. ARC-03 requires that every lowering preserve profile, effect, capability, precision, resource and evidence declarations in semantic identity. ARC-04 forbids using site trust labels as authentication identities.

```mermaid
flowchart LR
  A[Versioned source and source authority] --> B[Profile parser and typed AST]
  B --> C[Effects, ownership, numeric obligations]
  C --> D[Canonical admitted IR]
  D --> E[Image dependency closure]
  E --> F[Proposed native image and drivers]
  F --> G[Proposed authenticated transport]
  G --> H[Independent receiver admission]
  H --> I[Observed receipts and verifier]
  D --> J[Frozen six-operation local simulator]
```

The image, transport and receiver admission branches need new code and evidence. An external GPU, scene renderer, learning engine or proof solver is a service boundary until an adapter has a validated local backend. A display surface cannot acquire kernel authority through a UI label. An agent's tool request is an effectful service action, not an inference-only operation. A profile must specify whether a service failure is data, a typed terminal error, or a retryable condition.

## Adapter identity and interface

A proposed `ProfileIdentity` is `(namespace, source_version, grammar_digest, semantics_digest, value_schema_digest, adapter_version, target_abi_version)`. The digest algorithm and normalization scheme are named. Human version strings alone are insufficient. Dependencies form a locked directed graph with compatible exact identities; implicit latest-version selection is forbidden. Historic packages can contain several competing versions, so source authority resolution precedes parsing. A reconstruction is identified as a reconstruction, not promoted to original authority.

ADP-01 defines `parse(source_bytes, source_authority) -> AST | Diagnostics`; every diagnostic contains phase, stable code, byte span, source digest and offending version. ADP-02 defines `infer(AST, environment) -> TypedAST, obligations`; the environment contains value schemas, effects, capabilities, dimensions, precision and foreign service schemas. ADP-03 defines `lower(TypedAST, target_contract) -> IR, SourceMap, EvidenceRequirements`. ADP-04 defines a separate `verify_translation` interface whose result states its checked subset and trusted premises. A compiler success is not its own proof of correctness.

| Adapter phase | Required precondition | Required postcondition | Rejection condition |
|---|---|---|---|
| Authority resolution | Archive/content digests and source provenance present | Exact source version and precedence chosen, conflicts recorded | Unresolved original/reconstruction conflict |
| Parse | Declared grammar and lexical rules available | Complete consumption, AST spans bound to bytes | Unknown syntax, missing terminator, unsupported extension |
| Infer | All referenced symbols and operations resolved | Type, shape/unit, ownership, effects and cap obligations derived from source | Unknown effect, incompatible units, incomplete capability derivation |
| Lower | Obligations discharged or explicit runtime checks inserted | No implicit authority, dimensions preserved, deterministic naming | Unsupported operator, unchecked narrowing, driver outside target |
| Package | Full closure and ABI target pinned | Manifest describes every imported service/runtime dependency | Dynamic import not in closure, unverifiable toolchain |
| Admit | Receiver policies and profile versions independently checked | Evidence ledger distinguishes source/model/run facts | Modeled labels supplied as actual observations |

For supported source s, target execution should refine its source trace: `Trace_T(Lower(s)) ∈ AllowedTrace_S(s)`, under documented premises A. Trace includes observable values, errors, effects, resource exhaustion and termination. Pure total scalar subsets can use exact equality; nondeterministic or numerical profiles need an explicit relation R with permitted error and failure behavior. Translation correctness is scoped to syntax actually handled, rather than to every feature named by an atlas.

Effect soundness requires `ObservedEffects(Lower(s)) ⊆ InferredEffects(s)`. Authority preservation requires `Granted_T ⊆ Authorized_S ∩ SitePolicy ∩ LinkPolicy`. Resource soundness requires either a proven bound or an enforceable runtime limit with specified exhaustion. Version migration must state whether it preserves, restricts or changes semantics and retain before/after source digests. A new grammar digest invalidates previous parse results unless explicit equivalence evidence is supplied.

## All 25 audited inputs

The corpus IDs below match the frozen contribution matrix. Proposed roles are architecture assignments, not implemented imports. `U`=typed unit, `D`=data, `A`=authority, `P`=plan, `T`=time/causality, `V`=view, `E`=evidence. Each row needs the common ADP contracts in addition to its specific gate.

| Audited input | Candidate profile and roles | Specific contract and release gate |
|---|---|---|
| COLUMNED_LCTL_CORPUS_1.0.0 | lctl.columned; U,A,E | Parse its authoritative eighteen-cell dialect; roundtrip retains all policy cells; reject lossy twelve-cell conversion |
| JA21-DeepML-Animation-VFX-Language-Suite-1.0.0-main | deepml.vfx; D,P,V | Particle/fluid/cloth/render service graph; bounded buffers, numerical method and device precision; native GPU evidence before device claims |
| JA21-DeepML-Core-Language-Suite-1.0.0-main | deepml.core; U,D,P | Shape/dtype/model graph, autodiff and schedules; actual shape inference and model-runtime measurements |
| JA21-DeepML-Kernel-Language-Suite-1.0.0-main | deepml.kernel; U,A,P | Memory spaces, index bounds, race/precision obligations; source-derived device metadata and target-authority execution |
| JA21-DeepML-Logic-Functional-Language-Suite-1.0.0-main | deepml.logic; U,E | Pure functions, predicates, inference and proof terms; termination or bounded inference contract; checked proof obligations |
| JA21-DeepML-Motion-Animation-Language-Suite-1.0.0-main | deepml.motion; D,T,V | Rigs, poses, interpolation, retargeting; coordinate conventions, valid joint limits, clock and display/service separation |
| JA21-DeepML-Specialized-Language-Suite-1.0.0-main | deepml.specialized; U,D,A | Domain units and constraints extend a checked base; conversion, uncertainty and precision explicit |
| JA21-JA-Agent-Language-Suite-1.0.0-main | ja.agent; A,P,E | Bounded plans/tool grants/approval/termination; reinfer source capabilities and prohibit delegated privilege growth |
| JA21-JA-Certifier-Grammar-Suite-1.0.0-main | ja.certifier; U,E | Grammar identities and conformance diagnostics; complete referenced productions, actual parser/type/proof checks |
| JA21-JA-Core-Application-Language-Suite-1.0.0-main | ja.core; U,A | Types, ownership, effects and arithmetic profiles; preserve coupled 8S meanings separately from scalar subset |
| JA21-JA-Data-Language-Suite-1.0.0-main | ja.data; D,A,E | Schemas, lineage, ordering, retention and rights; source join operator must exist before importing join labels |
| JA21-JA-Interface-Language-Suite-1.0.0-main | ja.interface; V,A | State projections, navigation and surface actions; infer real caps, test rendered interactions, keep client outside image authority |
| JA21-JA-Operations-Language-Suite-1.0.0-main | ja.operations; U,P,E | Build/lifecycle/rollback; locked closure, actual boot, monotonic policy and rollback receipts |
| JA21-JA-Portal-Scene-Language-Suite-1.0.0-main | ja.portal.scene; D,V | Spatial entities/transforms/cameras; units/frames/ownership; grammar reconstruction qualified and no implicit time semantics |
| JA21-JA-Programming-Language-Suite-1.0.0-main | sophia.ja.0.2; U,E | Historical technical documents and regeneration; complete readable text kept, document records distinct from executable cases |
| JA21-JA-Security-Policy-Language-Suite-1.0.0-main | ja.security; A,E | Default deny/redaction/revocation/no-leak; corrected polarity retained, independent denial tests through an actual policy engine |
| JA21-JA-Service-and-Protocol-Language-Suite-1.0.0-main | ja.service; D,A,P | Typed messages/protocol/deadline/retry/idempotency; preamble excluded as program, native failure behavior tested |
| JA21-JA-Test-Simulation-and-Proof-Language-Suite-1.0.0-main | ja.proof; T,E | Fixtures/property/simulation/proof; independent fixture oracle plus actual quantified invariant; native proof runtime separate |
| JA21-JA-Training-and-Evaluation-Language-Suite-1.0.0-main | ja.training; D,P,E | Dataset/model/seed/metrics/checkpoint/promotion; actual training records and measured holdout acceptance |
| JA21-JAXD-UI-UX-Experience-Design-Language-Suite-1.0.0-main | ja.experience.design; V,A,T | Intent/accessibility/motion projections; checked bootstrap subset declared, generated projections illustrative until rendered tests |
| JA21-MCRT-Portal-Timeline-Language-Suite-1.0.0-main | mcrt.portal.timeline; T,E | Causal events/virtual time/checkpoints/replay; executed event ledger distinct from timeline description |
| LCTL_1.6.0_RC1_HYPERFEDERATED_EXECUTION_FABRIC | lctl.fabric.1.6; U,A,P,E | Distributed descriptors/placement/recovery; structural checks retain scope, authenticated native transport/proofs required |
| LCTL_1.6.1_RC1_COLUMNED_HYPERFEDERATED_EXECUTION_LANGUAGE | lctl.columned.fabric.1.6.1; U,A,P,E | Column authoring plus fabric lowering; full-policy fingerprint and roundtrip; no native inference from descriptor success |
| LKVEXA_LANGUAGE_AUDIT_AND_USAGE_GUIDE | collection.guide; E | Navigation and maturity claims; document authority only, reconciled against current audit qualifiers |
| MSSL_WRITERS_CORPUS_1.0.0 | mssl; E | Sealed technical records/facts/provenance; validate without resealing or inferring runtime/physical certification |

## Cross-profile values and semantic joins

Only declared bridges can connect profiles. A tensor bridge specifies rank, dimensions, dtype, byte order, layout, ownership, finite/nonfinite policy and precision; it cannot send an untyped byte buffer while claiming a tensor contract. A scene bridge specifies units and handedness; a motion bridge adds interpolation and timebase. A training bridge carries dataset split identity and model digest. A policy bridge converts rights only through an explicit non-amplifying mapping. A proof bridge identifies the logic, assumptions, proof checker and exact proposition digest.

The 8S bridge is a separate profile contract. It carries coordinate index set {4,5,6,7,8}, lattice scale, metric definiteness and dimensional assumptions, fibre convention S³ in R⁴, pair/triad coefficients, support factor domains, numerical solver, score definition and admission thresholds. Undefined `Score` or external evidence becomes a declared input/obligation; it is not fabricated by the adapter. Singular matrices, zero denominators, boundary coordinates and nonfinite values need specified rejection/regularization behavior. A repaired `Count` fixture stays a typed example, not a bridge for the whole JA foundation.

ADP-05 rejects a bridge that drops uncertainty, reorders semantically ordered arrays, narrows numeric range without a checked condition, treats an external receipt as a local proof, or translates a modeled capability list instead of source-derived rights. ADP-06 requires positive, negative, boundary and metamorphic cases for every bridge operation, with independently authored expected values. Adapters are admitted by exact supported subset; unhandled syntax cannot degrade to generic opaque execution.

## Canonical identity and compatibility

The frozen compiler uses its own deterministic Python JSON encoding. It does not claim RFC 8785 conformance. A future wire profile must choose a named encoding with cross-language test vectors, maximum depth/length, duplicate-key rejection, integer width and Unicode policy. JCS defines a particular JSON canonicalization scheme; CBOR provides a separate binary representation and deterministic encoding considerations. Neither can be substituted without a semantic-identity version change. [RFC 8785](https://www.rfc-editor.org/info/rfc8785/), [RFC 8949](https://www.rfc-editor.org/info/rfc8949/).

A proposed semantic digest is domain-separated: `H("LCUF:admitted-module:v1" || canonical(module, policy, adapters, ABI, limits))`. Exact source-byte hashes remain alongside it. Two formatting variants may have the same semantic digest and different source hashes; two capability policies must not share a semantic digest. A migration produces a signed or otherwise authenticated review record only when a real review authority exists. A compatibility declaration lists tested producer/consumer versions and failure cases; a shared version prefix is insufficient.

## Initial architecture acceptance set

Gate ARC-A requires all 25 entries to be classified without an implicit native import, a source-authority conflict report, and an exact parser-supported subset. Gate ARC-B requires translation checks for scalar arithmetic and one non-scalar bridge, including a deliberately wrong bridge rejected by the oracle. Gate ARC-C requires independent receiver rejection of unsupported versions/effects and a capability intersection experiment. Gate ARC-D requires the FOUNDATION-01 migration review preserving historical data and image provenance. All four are proposed gates; this research volume alone closes none of the future implementation obligations.
