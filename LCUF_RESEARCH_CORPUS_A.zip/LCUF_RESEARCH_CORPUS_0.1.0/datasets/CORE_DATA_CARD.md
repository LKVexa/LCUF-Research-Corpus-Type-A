# LCUF Core Conformance Data Card

This dataset supplies executable synthetic conformance cases for the twelve-column LCUF/0.1 source language and the pinned 0.1.0 host reference. Each master record binds exact source bytes, an expectation specified by a construction or contract mutation, a fresh observed result, a formal requirement, and a reproducible partition. The publication unit is a record, rather than a claim that each parameterized example is an independent language design.

## Population and sampling frame

The master contains 10,144 records: 4,096 accepted constructions, 4,704 rejected mutations, and 1,344 pairs testing source or semantic identity. The pairs contain two sources, so one full validation evaluates 11,488 source slots. There are 144 construction families: 32 positive families with 128 variants each, 98 negative families with 48 variants each, and 14 metamorphic families with 96 variants each. The [family registry](CORE_FAMILY_REGISTRY.json) enumerates them. The [build receipt](../validation/CORE_BUILD.json) records exact counts and hashes.

The sampling frame is the implemented finite core: `const`, `add`, `mul`, `copy`, `assert_eq`, and `emit`; value types are signed 64-bit integers, Boolean values, and Unicode text. Unit is the result type of terminal operations. It has no admitted constant value. General expressions, loops, tensors, native devices, sockets, compiled JA source, and library OS images are outside this frame.

Variant indices deterministically select values, signs, payload contents, reservation amounts, graph depth, and fanout. Identity-bearing module names distinguish the corresponding source programs. Two Boolean outputs and several graph patterns repeat across variants. Source uniqueness therefore does not imply semantic-design uniqueness. The corpus records the number of families and construction mechanism explicitly, rather than presenting 10,144 records as 10,144 independently conceived programs.

## Record contract

The normative machine schema is [core_record.schema.json](../schemas/core_record.schema.json), using JSON Schema Draft 2020-12 and local references only. Records contain these fields:

| Field | Meaning and assurance boundary |
|---|---|
| `record_id` | Stable publication identity; not a source fingerprint |
| `family` and `variant` | Construction lineage and parameter index |
| `language` and `reference_version` | Source contract and exact reference version |
| `source.bytes_base64` | Authoritative source bytes, including BOM or CRLF where present |
| `source.utf8_text` | Exact UTF-8 projection, or null for deliberately invalid UTF-8 |
| `source.sha256` | SHA-256 of the authoritative bytes |
| `paired_source` | Second source, present only for metamorphic records |
| `requirement_ids` | Primary formal contracts exercised by this case |
| `expected` | Constructed scalar oracle, intended rejection predicate, or specified identity relation |
| `observed` | Result actually obtained from the pinned host reference |
| `verification` | Equality or rejection-predicate comparison result |
| `execution_authority` | Always `host_reference_only` |
| `native_execution_eligible` | Always false |

An observed admission contains the semantic fingerprint, source fingerprint, values, graph order, retained-payload and step totals, receipt count, and receipt-chain head. An observed rejection contains the emitted diagnostic. No historical modeled runtime trace is imported as an actual observation.

## Construction oracles

Positive expectations use formulas stated in [build_core.py](../tools/build_core.py) independently of the runtime output. For example, the diamond graph with input `x` expects `twice=2x`, `square=x²`, and `result=x²+2x`. The long chain expects `value_k=x+k+1`; the copy route expects equal payload values at its destination owners; explicit-order cases supply a separately stated row order. These construction oracles cover the selected sources and parameter ranges, rather than proving all possible programs.

Negative cases begin from admitted finite programs and mutate a specified constraint. They cover encoding, declaration ordering and uniqueness, identifiers, columns and lists, scalar JSON, type ownership and arity, unit/value shape, directed-copy authority, single writers, defined references, local control dependencies, cycles, resource integers and sums, overflow, assertion failure, and evidence authority. The expected diagnostic is a substring, because the reference emits textual first-error diagnostics rather than stable diagnostic codes. The formal taxonomy is a classification of those messages, not a claim that the runtime implements diagnostic-code output.

Metamorphic pairs distinguish eight normalization relations from six identity-sensitive changes. Comments, blank lines, cell spacing, CRLF, BOM, source row permutation, grant order, and link order preserve semantic identity in these constructions. Changing trust, memory limits, step limits, row budgets, evidence policy, or the module identity changes the fingerprint. Every pair changes raw source identity. Recompilation verifies the relation rather than assigning a label from the family name alone.

All admitted sources additionally undergo deterministic replay comparison, independent receipt-chain recomputation, retained-output byte counting, step summation, and confirmation that the target plan has null bootable images. Those universal checks support the corresponding requirements even when a record's primary requirement list focuses on another property.

## Partitions and leakage analysis

The partition function hashes the family label and assigns it to `reference`, `development`, or `challenge`. Counts are 5,872, 1,728, and 2,544 respectively. Every family and all its parameter variants belong to one partition. The partition files collectively reproduce the master exactly once; the master is not a fourth independent set of observations.

These are conformance partitions. They are not a validated training/test split for machine learning. Shared scalar graph patterns, operator names, policy vocabulary, generator code, and numeric construction formulas occur across family boundaries. Holding out a family tests a construction or fault mechanism; it does not establish isolation of all graph templates. Any learning experiment must report exact-byte overlap, normalization-based template overlap, family overlap, and whether generator sources were exposed during training. The [evaluation protocol](../research/05_EVALUATION_AND_DATA_GOVERNANCE.md) supplies the broader evaluation contract.

## Reproduction and verification

Run commands from the release root:

```text
python tools/build_core.py
python tools/validate_core.py
python tools/check_oracle_sensitivity.py
python -m unittest discover -s tools/tests -v
```

The builder writes deterministic gzip members with a fixed timestamp. Validation applies the strict schema, verifies decoded source hashes and text projections, checks the pinned upstream runtime, recompiles and simulates all sources, compares expected and observed results, and verifies master/partition equality and family isolation. `--metadata-only` checks stored evidence consistency without fresh execution and must not be reported as fresh execution evidence.

The sensitivity experiment injects ten named faults into an in-memory copy of the trusted reference. It changes addition, receiving authority, sending authority, step admission, payload admission, ready-row selection, effect/capability matching, assertion admission, receipt result hashing, and receipt coverage. The [receipt](../validation/ORACLE_SENSITIVITY.json) identifies the cases that detect each injected fault. This establishes sensitivity to those ten faults, rather than exhaustive mutation adequacy or independent native-runtime certification.

## Intended use and exclusions

Use the corpus for compiler admission regression, independently implemented frontend comparisons, source/IR policy preservation, example-based teaching, controlled fuzzing seeds, and research into evidence-qualified fabric compilation. A replacement compiler should consume the source bytes and independently produce a normalized output for comparison. It should not simply consume this reference's observed result as its own answer.

Do not use the admission label as a security certificate, native execution attestation, external proof, permission to access a device, or evidence that a remote site executed an operation. Reject cases are deliberate adversarial examples and remain in the published corpus. The scalar oracle defines conventional LCUF i64 behavior; it does not redefine the author-provided JA 8S arithmetic foundation.

## Maintenance and change control

A change to the runtime, grammar, profile ownership, serialization, reservation convention, or generator lineage requires versioned revalidation. Schema changes must state whether they alter source language semantics or only the record representation. Updating an expectation to match a newly observed failure requires a reviewed contract explanation and an independent oracle rationale; it cannot be treated as a harmless regeneration step. Release manifests record byte identity, while signed institutional approval and peer review remain separate processes.
