# MSSL WRITERS CORPUS 1 0 0 Updated Corpus Audit

This updated copy supplies sealed technical records, normalized facts and provenance. Its import boundary is: Preserve original authority/seals; record validation is not physical/runtime certification.

## Source and coverage

Original input: `MSSL_WRITERS_CORPUS_1.0.0.zip`. Source SHA 256: `4019023232fc43c659ddebf3ab69b92e25e91731ec7400e6d43033b435b3920b`. The source archive is preserved in the parent folder. All 1,840 original leaf files were read and hashed; 77,726 stored JSONL rows were structurally parsed, including historical/reconstructed copies. Nested ZIPs are materialized in `.expanded` directories. Dataset row counts include duplicate representations and metadata headers; they are not unique executable programs.

Original checks and locations are in [the source manifest](audit/source_manifest.json). Current payload bytes are in [the updated manifest](audit/updated_manifest.json), and changes are in [the ledger](audit/change_ledger.json). Embedded source layers have [separate coverage](audit/embedded_layer_coverage.json). Historical hashes and modeled labels retain their historical meaning. The updated manifest and qualification sidecars govern this release.

## Upgrades and open implementation work

### MSSL-001 High priority

Seal helper could not reliably compute or report failures

Status: **APPLIED**. Use one portable standard-library parser/helper and grouped CMD usage, parse top-level field boundaries even when marker text occurs inside quoted strings; preserve compatibility PowerShell sample APIs. No authority bytes changed.

Evidence: `tools/COMPUTE_KAPPA.cmd | tools/COMPUTE_KAPPA.sh | reference/KAPPA_SEALING_WORKFLOW.md`.

### MSSL-002 High priority

Integrity/count-only validation did not check semantic source projections

Status: **APPLIED**. Add portable observed-subset validator, strict integrity records, all positive and negative fixture validation, normalized statement/fact/source coverage, exact seals and split leakage checks. Tighten validation schema booleans. Runtime claims remain observations.

Evidence: `VERIFY_CORPUS.cmd | VERIFY_CORPUS.sh | schemas/mssl_normalized_document.schema.json`.

### BASE-25 Medium priority

Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries.

Status: **APPLIED**. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role.

Evidence: `audit/source_manifest.json | audit/updated_manifest.json | audit/dataset_qualification.json`.

Remaining gate: Preserve original authority/seals; record validation is not physical/runtime certification.

## Contribution to the new fabric language

Profile owner: `mssl`. Sealed technical records, normalized facts and provenance. Preserve original authority/seals; record validation is not physical/runtime certification.

The [adapter contract](audit/fabric_adapter_contract.json) is a proposed interface with executable_adapter_implemented=false. It preserves source authority rather than using a feature label as inferred semantics. See [the collection architecture](../../fabric_language/ARCHITECTURE.md) and the [8S foundation](../../fabric_language/profiles/coupling8s/PROFILE.md).

## Qualification and verification

Use [dataset qualifications](audit/dataset_qualification.json) before training, importing or treating a record as evidence. A modeled pass or a structural validator pass is not native execution, authenticated federation, race proof, or physical device evidence. Current JA and DeepML technical records carry additional qualifications; deliberate negative examples remain negative examples.

The release provides an offline integrity checker: run `python tools/verify_release.py --deep` from the collection root. Per-profile test reports and validators qualify the exact behavior they checked. Complete grammars, native adapters, authenticated transports and a bootable unikernel remain separately tracked implementation gates.
