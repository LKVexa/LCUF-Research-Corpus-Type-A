# JA21 JA Data Language Suite Catalog

## Release identity

- Version: 1.0.0
- Profile: `ja.data`
- Extension: `.jad`
- Source records: 10,000
- Curated programs: 1,000
- Features: 32
- Levels: 10
- Validation classes: 10
- Textbook chapters: 22

## Corpus composition

| Validation class | Records | Curated scripts |
| --- | --- | --- |
| positive | 4000 | 400 |
| negative | 1500 | 150 |
| boundary | 1000 | 100 |
| integration | 1000 | 100 |
| security | 750 | 75 |
| performance | 500 | 50 |
| determinism | 500 | 50 |
| interoperability | 250 | 25 |
| recovery | 250 | 25 |
| certification | 250 | 25 |

## Main directories

- `corpus/technical/` — normalized corpus, shards, schema, and index
- `scripts/` — 1,000 source programs
- `textbook/` — primary textbook
- `education/` — curriculum, workbook, and instructor guide
- `specification/` — language and implementation contracts
- `conformance/` — certification framework and cases
- `catalogs/` — feature, diagnostic, architecture, and script navigation
- `design/` — local publication assets
- `tools/` — offline inspection and validation
- `source/` — preserved upload and reconstructed originals
- `manifest/` — file inventory and SHA-256 evidence
