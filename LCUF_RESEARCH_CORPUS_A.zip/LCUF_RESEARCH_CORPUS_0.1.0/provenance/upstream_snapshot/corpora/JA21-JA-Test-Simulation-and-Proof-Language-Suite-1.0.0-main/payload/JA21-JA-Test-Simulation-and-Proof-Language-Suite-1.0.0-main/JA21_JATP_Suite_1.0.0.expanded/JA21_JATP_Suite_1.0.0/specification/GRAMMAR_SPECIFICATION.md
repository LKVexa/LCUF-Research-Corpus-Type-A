# Grammar Specification

The provisional grammar defines the publication surface required to study the corpus. A production grammar must additionally specify lexical normalization, Unicode identifiers, comments, literal forms, duration and resource units, qualified names, operator precedence, block recovery, proof-term syntax, temporal operators, source spans, diagnostic stability, and compatibility rules.

The parser must preserve stable identities for fixtures, generators, tests, simulations, theorems, obligations, proof terms, benchmarks, coverage declarations, and MCRT emissions.
