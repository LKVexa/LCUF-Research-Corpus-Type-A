# JA21 JA Programming Language Suite 1 0 0 main Updated Corpus Audit

This updated copy supplies historical ja foundations, technical suite and regeneration evidence. Its import boundary is: Reference text only until a versioned parser and runtime are implemented.

## Source and coverage

Original input: `JA21-JA-Programming-Language-Suite-1.0.0-main.zip`. Source SHA 256: `aa1c780e4b1cd3f7fe856cc80fdbbb210529904de3258eb06edd64faaf346efa`. The source archive is preserved in the parent folder. All 2 original leaf files were read and hashed; 2 stored JSONL rows were structurally parsed, including historical/reconstructed copies. Nested ZIPs are materialized in `.expanded` directories. Dataset row counts include duplicate representations and metadata headers; they are not unique executable programs.

Original checks and locations are in [the source manifest](audit/source_manifest.json). Current payload bytes are in [the updated manifest](audit/updated_manifest.json), and changes are in [the ledger](audit/change_ledger.json). Embedded source layers have [separate coverage](audit/embedded_layer_coverage.json). Historical hashes and modeled labels retain their historical meaning. The updated manifest and qualification sidecars govern this release.

## Upgrades and open implementation work

### JA-08 Medium priority

The archive is two rewritten document wrappers, not a ready suite tree. The reduced text merges declaration line breaks; its lossless-regeneration promise lacks a shipped generator or an original byte baseline. Embedded source hashes refer to older documents.

Status: **applied_source_or_tool_repair_and_qualified**. Programming readable views and logical record indexing

Evidence: `JA_Language_Coupling_Mechanics_Corpus.jsonl.gz`.

Remaining gate: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

### BASE-15 Medium priority

Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries.

Status: **APPLIED**. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role.

Evidence: `audit/source_manifest.json | audit/updated_manifest.json | audit/dataset_qualification.json`.

Remaining gate: Reference text only until a versioned parser and runtime are implemented.

## Contribution to the new fabric language

Profile owner: `sophia.ja.0.2`. Historical JA foundations, technical suite and regeneration evidence. Reference text only until a versioned parser and runtime are implemented.

The [adapter contract](audit/fabric_adapter_contract.json) is a proposed interface with executable_adapter_implemented=false. It preserves source authority rather than using a feature label as inferred semantics. See [the collection architecture](../../fabric_language/ARCHITECTURE.md) and the [8S foundation](../../fabric_language/profiles/coupling8s/PROFILE.md).

## Qualification and verification

Use [dataset qualifications](audit/dataset_qualification.json) before training, importing or treating a record as evidence. A modeled pass or a structural validator pass is not native execution, authenticated federation, race proof, or physical device evidence. Current JA and DeepML technical records carry additional qualifications; deliberate negative examples remain negative examples.

The release provides an offline integrity checker: run `python tools/verify_release.py --deep` from the collection root. Per-profile test reports and validators qualify the exact behavior they checked. Complete grammars, native adapters, authenticated transports and a bootable unikernel remain separately tracked implementation gates.
