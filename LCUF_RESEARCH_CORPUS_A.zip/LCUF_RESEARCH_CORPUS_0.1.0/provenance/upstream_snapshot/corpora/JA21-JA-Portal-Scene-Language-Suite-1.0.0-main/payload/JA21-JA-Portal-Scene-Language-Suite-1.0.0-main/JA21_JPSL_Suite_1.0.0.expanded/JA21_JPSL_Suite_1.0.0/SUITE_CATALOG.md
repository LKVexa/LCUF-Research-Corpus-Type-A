# JA21 JA Portal Scene Suite Catalog

## Core deliverables

| Product | Location | Scope |
|---|---|---|
| Technical corpus | `corpus/technical/JA21_JPSL_TECHNICAL_CORPUS_10000.jsonl.gz` | 10,000 normalized records |
| Corpus shards | `corpus/technical/shards/` | Twenty 500-record files |
| Script pack | `scripts/` | 1,000 source-faithful `.ja` programs |
| Script catalog | `catalogs/SCRIPT_CATALOG.csv` | Source and evidence linkage |
| Textbook | `textbook/JA21_JA_PORTAL_SCENE_LANGUAGE_TEXTBOOK.md` | 22 chapters, 17,812 words |
| Curriculum | `education/12_WEEK_CURRICULUM.md` | Twelve-week course |
| Language specification | `spec/language/JA_PORTAL_SCENE_LANGUAGE_SPECIFICATION.md` | Standalone profile |
| Conformance | `conformance/` | Coverage and certification |
| Offline tools | `tools/` | Inspector and validator |
| Preserved source | `source/` | Exact upload and reconstructed wrapper |

## Script composition

- 700 positive programs
- 175 negative and diagnostic programs
- All 125 certification holdouts
- All 49 topics
- All six tiers

## Learning tracks

- **Scene Foundations** — 9 topics
- **Assets and Environment** — 9 topics
- **Interaction and Animation** — 7 topics
- **Physics, Portals, and Integrated Worlds** — 8 topics
- **Persistence and Scene Graph Engineering** — 7 topics
- **Compiler and Evidence Lowering** — 1 topics
- **Diagnostics and Certification** — 8 topics

## Publication principles

Exact source fidelity, deterministic identity, explicit safety policy, closed resource graphs, stage-correct diagnostics, modeled/native evidence separation, air-gap-safe assets, and compact Windows paths.
