# Suite Catalog

| Product | Count / status |
|---|---:|
| Technical records | 10,000 |
| Corpus topics | 45 |
| Positive records | 7,875 |
| Negative records | 2,055 |
| Certification holdouts | 70 |
| Script pack | 1,000 `.mcrt` programs |
| Script composition | 788 positive / 142 negative / 70 certification |
| Textbook | 22 chapters |
| Research shards | 20 × 500 records |
| Native compiler/runtime | Not included |

## Principal paths

- `corpus/technical/JA21_MPTL_TECHNICAL_CORPUS_10000.jsonl.gz`
- `scripts/`
- `catalogs/SCRIPT_CATALOG.csv`
- `textbook/JA21_MCRT_PORTAL_TIMELINE_LANGUAGE_TEXTBOOK.md`
- `education/12_WEEK_CURRICULUM.md`
- `specifications/`
- `conformance/`
- `tools/validate_suite.py`
