
# JA21 DeepML Specialized Suite Catalog

## 1. Technical corpus

- `corpus/technical/deepml_specialized_technical_corpus_10000.jsonl.gz`
- `corpus/technical/specialized_01.jsonl.gz` … `specialized_20.jsonl.gz`
- `corpus/technical/technical_record.schema.json`
- `corpus/technical/corpus_index.csv`
- `corpus/technical/TECHNICAL_CORPUS_GUIDE.md`

## 2. One-thousand-script pack

- `script_pack_1000/`
- `catalogs/SCRIPT_CATALOG.csv`
- `catalogs/SCRIPT_CATALOG.jsonl`
- Composition: 750 positive, 150 diagnostic, 100 certification.

## 3. Textbook and education

- `textbook/JA21_DEEPML_SPECIALIZED_LANGUAGE_TEXTBOOK.md`
- `textbook/TABLE_OF_CONTENTS.md`
- `education/12_WEEK_CURRICULUM.md`
- `education/STUDENT_WORKBOOK.md`
- `education/INSTRUCTOR_GUIDE.md`
- `education/learning_modules.json`

## 4. Navigation and publication design

- `catalogs/TOPIC_ATLAS.md`
- `catalogs/READING_PATHS.md`
- `catalogs/DOMAIN_ARCHITECTURE.md`
- `design/PUBLICATION_SYSTEM.md`
- `design/JA21_SPECIALIZED_PUBLICATION_TOKENS.json`

## 5. Language and implementation specifications

- DeepML Specialized EBNF and grammar specification
- Language source specification and standalone language profile
- Compiler and runtime contracts in JSON and explanatory Markdown
- Semantic operator registry and reference
- R12/MCRT profile schema
- Conformance cases and certification guide

## 6. Testing, provenance, and integrity

- Topic matrix and diagnostic catalog
- Offline corpus inspector and full suite validator
- Starter project
- Reconstructed source tree under `reference_source/deepml_specialized_0.3/`
- Preserved uploaded wrapper
- Provenance statement, governance charter, release notes, validation report, manifest, and SHA-256 checksums
