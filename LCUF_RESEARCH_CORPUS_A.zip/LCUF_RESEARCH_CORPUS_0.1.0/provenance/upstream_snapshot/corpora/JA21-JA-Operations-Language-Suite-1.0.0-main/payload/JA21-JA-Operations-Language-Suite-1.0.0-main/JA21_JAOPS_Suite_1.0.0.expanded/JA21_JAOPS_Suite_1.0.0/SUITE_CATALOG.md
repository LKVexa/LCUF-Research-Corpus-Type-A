# JA21 JA Operations Language Suite Catalog

## Primary deliverables

| Product | Location | Scale |
|---|---|---:|
| Technical corpus | `corpus/technical/JA21_JAOPS_TECHNICAL_CORPUS_10000.jsonl.gz` | 10,000 records |
| Corpus shards | `corpus/technical/shards/` | 20 × 500 records |
| Script pack | `scripts/` | 1,000 programs |
| Script catalog | `catalogs/SCRIPT_CATALOG.csv` | 1,000 rows |
| Textbook | `textbook/JA21_JA_OPERATIONS_LANGUAGE_TEXTBOOK.md` | 22 chapters |

## Suite layers

- `catalogs/` — feature, diagnostic, architecture, reading, and script navigation
- `specification/` — grammar, language, semantic operators, and R12/MCRT profile
- `contracts/` — compiler and runtime obligations
- `conformance/` — cases, coverage, and certification
- `education/` — curriculum, workbook, instructor guide, and learning modules
- `starter/` — minimal offline project
- `tools/` — standard-library-only inspector and validator
- `design/` — cover and air-gap-safe publication system
- `source/` — uploaded wrapper and reconstructed source assets
- `integrity/` — manifest and SHA-256 checksums
