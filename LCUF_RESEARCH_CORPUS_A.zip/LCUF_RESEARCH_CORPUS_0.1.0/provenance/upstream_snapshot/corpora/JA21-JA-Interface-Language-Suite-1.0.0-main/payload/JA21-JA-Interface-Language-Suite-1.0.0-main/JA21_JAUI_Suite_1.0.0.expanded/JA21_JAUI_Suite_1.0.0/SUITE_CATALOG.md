# JA21 JA Interface Language Suite Catalog

## Release identity

| Field | Value |
|---|---|
| Suite | JA21 JA Interface Language Suite |
| Version | 1.0.0 |
| Profile | `ja.interface` |
| Source extension | `.jaui` |
| Corpus records | 10,000 |
| Curated programs | 1,000 |
| Textbook chapters | 22 |
| Native execution claim | None |

## Directory catalog

| Directory | Purpose |
|---|---|
| `corpus/technical/` | Normalized master corpus, shards, index, guide, coupling metadata |
| `corpus/schema/` | Normalized record schema |
| `scripts/` | 1,000 source-faithful `.jaui` programs |
| `catalogs/` | Script catalog, feature atlas, matrix, diagnostics, architecture, reading paths |
| `textbook/` | Complete technical textbook |
| `education/` | Curriculum, workbook, instructor guide, modules |
| `specification/` | Grammar, language specification, semantic registry, evidence schema |
| `contracts/` | Compiler and runtime contracts |
| `conformance/` | Cases, coverage expectations, certification guide |
| `design/` | Publication system and local cover |
| `starter_project/` | Minimal offline starter |
| `tools/` | Corpus inspector and suite validator |
| `source_preservation/` | Reconstructed source assets and uploaded wrapper |
| `integrity/` | Machine-readable manifest and SHA-256 checksums |

## Five learning tracks

| Track | Features |
|---|---|
| Foundations | component, property, typed slot, local/shared state, derived/reactive values |
| Interaction and binding | event, command, data/service binding, form, validation, permission control |
| Layout and accessibility | constraints, responsive behavior, accessibility, keyboard, focus, localization |
| Visual and motion | design tokens, themes, animation, motion, VFX, resource loading |
| Navigation and targets | navigation, portal scenes, desktop, mobile, web, headless |

## Core evidence chain

```text
source hash
  → semantic identity and judgment
  → stable typed AST node
  → compiler/R12 representation
  → runtime expectation
  → MCRT provenance identity
```

## Primary publication files

- `README.md`
- `RELEASE_NOTES.md`
- `GOVERNANCE_CHARTER.md`
- `PROVENANCE.md`
- `VALIDATION_REPORT.md`
- `integrity/MANIFEST.json`
- `integrity/SHA256SUMS.txt`
