"""LCUF 0.1: strict column parser, static admission, canonical IR and local simulation.

No network calls, arbitrary expressions, native code loading or unikernel backend.
"""
from __future__ import annotations
import argparse, hashlib, json, pathlib, re, sys

VERSION = '0.1.0'
COLUMNS = ['id','site','profile','op','inputs','output','type','effects','caps','after','budget','evidence']
IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_.-]*$')
OPS = {'const':('lcuf.scalar',0), 'add':('lcuf.scalar',2), 'mul':('lcuf.scalar',2),
       'copy':('lcuf.fabric',1), 'assert_eq':('lcuf.test',2), 'emit':('lcuf.evidence',1)}
I64_MIN, I64_MAX = -(2**63), 2**63-1

class Diagnostic(ValueError): pass

def fail(message, line=None):
    raise Diagnostic((f'line {line}: ' if line else '') + message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def hash_value(value): return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()

def identity(value, line):
    if not IDENT.fullmatch(value): fail('invalid identifier ' + value,line)
    return value

def positive_integer(value,line):
    if not re.fullmatch(r'[1-9][0-9]*',value) or len(value)>19:
        fail('resource integer must be ASCII and within signed 64 bit positive bounds',line)
    parsed=int(value)
    if parsed>I64_MAX: fail('resource integer exceeds signed 64 bit bounds',line)
    return parsed

def names(cell, line, allow_duplicates=False):
    if cell == '-': return []
    parts=cell.split(',')
    if not allow_duplicates and len(set(parts)) != len(parts): fail('duplicate list item',line)
    return [identity(x,line) for x in parts]

def parse(source):
    lines=[(n,s.strip()) for n,s in enumerate(source.split('\n'),1) if s.strip() and not s.strip().startswith('#')]
    if not lines or lines[0][1] != 'LCUF/0.1': fail('required header LCUF/0.1')
    module=None; sites={}; grants={}; links=[]; rows=[]; in_rows=False; ended=False
    for n,line in lines[1:]:
        if ended: fail('content after end',n)
        if line == 'end': ended=True; continue
        if module is None and not line.startswith('module '): fail('module must be the first declaration',n)
        if not in_rows:
            if line.startswith('module '):
                if module: fail('duplicate module',n)
                parts=line.split()
                if len(parts)!=2: fail('module requires one identifier',n)
                module=identity(parts[1],n)
            elif line.startswith('site '):
                m=re.fullmatch(r'site (\S+) trust=(\S+) memory=([0-9]+) steps=([0-9]+)',line)
                if not m: fail('site requires trust, memory and steps in that order',n)
                name,trust,memory,steps=m.groups(); identity(name,n); identity(trust,n)
                if name in sites: fail('duplicate site',n)
                sites[name]={'trust':trust,'memory':positive_integer(memory,n),'steps':positive_integer(steps,n)}
            elif line.startswith('grant '):
                m=re.fullmatch(r'grant (\S+) caps=(\S+)',line)
                if not m: fail('invalid grant',n)
                site,caps=m.groups(); identity(site,n)
                if site in grants: fail('duplicate grant',n)
                grants[site]=names(caps,n)
            elif line.startswith('link '):
                m=re.fullmatch(r'link (\S+) (\S+) transfer=(\S+)',line)
                if not m: fail('invalid link',n)
                a,b,kind=m.groups(); identity(a,n); identity(b,n)
                if a==b or kind!='copy': fail('links require distinct sites and transfer=copy',n)
                if any(x['from']==a and x['to']==b for x in links): fail('duplicate link',n)
                links.append({'from':a,'to':b,'transfer':kind})
            elif [c.strip() for c in line.split('|')]==COLUMNS: in_rows=True
            else: fail('unknown declaration or invalid column header',n)
        else:
            cells=[x.strip() for x in line.split('|')]
            if len(cells)!=len(COLUMNS): fail(f'expected 12 cells, got {len(cells)}',n)
            row=dict(zip(COLUMNS,cells)); row['line']=n
            for k in ('id','site','profile'): identity(row[k],n)
            if row['op'] not in OPS: fail('unsupported operation ' + row['op'],n)
            if row['type'] not in ('i64','bool','text','unit'): fail('unsupported type',n)
            if row['output']!='-': identity(row['output'],n)
            for k in ('effects','caps','after'): row[k]=names(row[k],n)
            row['budget']=positive_integer(row['budget'],n)
            if row['evidence'] not in ('none','receipt'): fail('evidence must be none or receipt',n)
            if row['op']=='const':
                if row['inputs'].startswith(('[','{')): fail('const requires a JSON scalar literal',n)
                try: row['literal']=json.loads(row['inputs'],parse_constant=lambda x:fail('nonfinite literal',n))
                except Diagnostic: raise
                except (ValueError,TypeError,RecursionError): fail('const requires a bounded JSON scalar literal',n)
                row['inputs']=[]
            else: row['inputs']=names(row['inputs'],n,allow_duplicates=True)
            rows.append(row)
    if not ended: fail('missing end')
    if not module or not sites or not in_rows or not rows: fail('module, sites, columns and rows are required')
    return {'language':'LCUF/0.1','module':module,'sites':sites,'grants':grants,'links':links,'rows':rows}

def check_value(value,typ,line):
    ok={'i64':lambda:isinstance(value,int) and not isinstance(value,bool) and I64_MIN<=value<=I64_MAX,
        'bool':lambda:isinstance(value,bool),'text':lambda:isinstance(value,str),'unit':lambda:value is None}[typ]()
    if not ok: fail('value violates type or i64 bounds',line)
    if typ=='text':
        try: value.encode('utf-8')
        except UnicodeError: fail('text contains an unpaired Unicode surrogate',line)

def compile_source(source):
    raw=source if isinstance(source,bytes) else source.encode('utf-8')
    if isinstance(source,bytes):
        try: source=source.decode('utf-8-sig')
        except UnicodeError: fail('source is not UTF 8')
    p=parse(source); sites=p['sites']; grants=p['grants']; rows=p['rows']
    if any(x not in sites for x in grants): fail('grant names an unknown site')
    if any(l['from'] not in sites or l['to'] not in sites for l in p['links']): fail('link names an unknown site')
    by_id={}; outputs={}; budgets={s:0 for s in sites}
    for r in rows:
        n=r['line']; rid=r['id']; site=r['site']
        if rid in by_id: fail('duplicate row id',n)
        by_id[rid]=r
        if site not in sites: fail('unknown site',n)
        if r['profile']!=OPS[r['op']][0]: fail('operation does not belong to profile',n)
        if r['op']!='const' and len(r['inputs'])!=OPS[r['op']][1]: fail('wrong operation arity',n)
        if r['output']!='-':
            if r['output'] in outputs: fail('multiple writers to one output',n)
            outputs[r['output']]=r
        if r['op'] in ('assert_eq','emit'):
            if r['type']!='unit' or r['output']!='-': fail('terminal operation requires unit and output -',n)
        elif r['type']=='unit' or r['output']=='-': fail('value operation requires typed output',n)
        if r['op'] in ('add','mul') and r['type']!='i64': fail('arithmetic requires i64',n)
        if r['op']=='const': check_value(r['literal'],r['type'],n)
        required_effects={'fabric.transfer'} if r['op']=='copy' else {'evidence.emit'} if r['op']=='emit' else set()
        required_caps={'fabric.receive'} if r['op']=='copy' else {'evidence.write'} if r['op']=='emit' else set()
        if set(r['effects'])!=required_effects or set(r['caps'])!=required_caps: fail('effects and capabilities must match the operation contract',n)
        if not required_caps.issubset(grants.get(site,[])): fail('capability denied by site grant',n)
        if r['op']=='emit' and r['evidence']!='receipt': fail('emit requires receipt',n)
        budgets[site]+=r['budget']
    deps={r['id']:set(r['after']) for r in rows}
    for r in rows:
        n=r['line']; producers=[]
        for inp in r['inputs']:
            if inp not in outputs: fail('undefined input ' + inp,n)
            a=outputs[inp]; producers.append(a); deps[r['id']].add(a['id'])
            if a['site']!=r['site']:
                if r['op']!='copy': fail('cross-site input requires explicit copy row',n)
                if not any(l['from']==a['site'] and l['to']==r['site'] for l in p['links']): fail('no directed federation link',n)
                if 'fabric.send' not in grants.get(a['site'],[]): fail('sender lacks fabric.send grant',n)
            elif r['op']=='copy': fail('copy requires a different source site',n)
        if r['op'] in ('add','mul','copy') and any(a['type']!=r['type'] for a in producers): fail('input type mismatch',n)
        if r['op']=='assert_eq' and producers[0]['type']!=producers[1]['type']: fail('assert operands have different types',n)
        if any(d not in by_id for d in deps[r['id']]): fail('undefined dependency',n)
        if any(by_id[d]['site']!=r['site'] for d in r['after']): fail('cross-site after requires a local copy dependency',n)
    remaining=set(by_id); order=[]
    while remaining:
        ready=sorted(r for r in remaining if deps[r].isdisjoint(remaining))
        if not ready: fail('dependency cycle')
        chosen=ready[0]; order.append(chosen); remaining.remove(chosen)
    for site,total in budgets.items():
        if total>sites[site]['steps']: fail('step admission exceeded at ' + site)
    # Memory is a conservative sum of all retained outputs, including transit copies.
    memory={s:0 for s in sites}; values={}
    for rid in order:
        r=by_id[rid]
        args=[values[x] for x in r['inputs']]
        if r['op']=='const': value=r['literal']
        elif r['op']=='add': value=args[0]+args[1]
        elif r['op']=='mul': value=args[0]*args[1]
        elif r['op']=='copy': value=args[0]
        elif r['op']=='assert_eq':
            if args[0]!=args[1]: fail('constant assertion fails',r['line'])
            continue
        else: continue
        check_value(value,r['type'],r['line']); values[r['output']]=value
        memory[r['site']]+=8 if r['type']=='i64' else 1 if r['type']=='bool' else len(value.encode('utf-8'))
    for site,total in memory.items():
        if total>sites[site]['memory']: fail('memory admission exceeded at ' + site)
    ir={k:p[k] for k in ('language','module','sites','grants','links')}
    ir['links']=sorted(ir['links'],key=lambda x:(x['from'],x['to']))
    ir['grants']={s:sorted(c) for s,c in ir['grants'].items()}
    ir['rows']=[{k:v for k,v in by_id[rid].items() if k!='line'} for rid in order]
    for r in ir['rows']:
        for k in ('effects','caps','after'): r[k]=sorted(r[k])
    ir['admission']={'reserved_steps':budgets,'retained_output_bytes':memory}
    ir['compiler_version']=VERSION
    return {'ir':ir,'semantic_sha256':hash_value(ir),'source_sha256':hashlib.sha256(raw).hexdigest()}

def simulate(compiled):
    if hash_value(compiled['ir'])!=compiled['semantic_sha256']: fail('IR hash mismatch')
    ir=compiled['ir']; values={}; receipts=[]; previous='0'*64
    for r in ir['rows']:
        args=[values[x] for x in r['inputs']]; op=r['op']
        if op=='const': value=r['literal']
        elif op=='add': value=args[0]+args[1]
        elif op=='mul': value=args[0]*args[1]
        elif op=='copy': value=args[0]
        elif op=='assert_eq':
            if args[0]!=args[1]: fail('assertion failed')
            value=None
        elif op=='emit': value=args[0]
        else: fail('unknown operation in IR')
        if r['output']!='-': check_value(value,r['type'],None); values[r['output']]=value
        if r['evidence']=='receipt':
            record={'kind':'LCUF_LOCAL_SIMULATION','execution_scope':'single_process_model','row':r['id'],'site':r['site'],'profile':r['profile'],'semantic_sha256':compiled['semantic_sha256'],'previous_sha256':previous,'result_sha256':hash_value(value)}
            previous=hash_value(record); receipts.append({**record,'sha256':previous})
    return {'status':'local_simulation_pass','native_unikernel_built':False,'physical_federation_executed':False,'values':values,'receipts':receipts,'receipt_chain_head':previous}

def target_plan(compiled):
    return {'status':'design_plan_only','semantic_sha256':compiled['semantic_sha256'],'compiler_version':VERSION,
            'sites':{s:{'trust_domain':v['trust'],'memory_limit':v['memory'],'step_reservation':compiled['ir']['admission']['reserved_steps'][s],'capabilities':compiled['ir']['grants'].get(s,[]),'candidate_backend':'Unikraft native C adapter','bootable_image':None} for s,v in compiled['ir']['sites'].items()},
            'required_gates':['native code generation','pinned library OS toolchain and dependency closure','ABI and driver allowlist','per-site boot and denial tests','authenticated federation transport','crash and replay conformance','attested build and receipt verification']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['check','compile','simulate','plan']); parser.add_argument('source',type=pathlib.Path); parser.add_argument('--out',type=pathlib.Path)
    args=parser.parse_args()
    try:
        c=compile_source(args.source.read_bytes())
        result={'status':'static_admission_pass','semantic_sha256':c['semantic_sha256']} if args.command=='check' else c if args.command=='compile' else simulate(c) if args.command=='simulate' else target_plan(c)
        rendered=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
        if args.out: args.out.parent.mkdir(parents=True,exist_ok=True); args.out.write_text(rendered,encoding='utf-8')
        else: print(rendered,end='')
        return 0
    except (Diagnostic,OSError,UnicodeError) as e:
        print(json.dumps({'status':'rejected','message':str(e)}),file=sys.stderr); return 2

if __name__=='__main__': sys.exit(main())
