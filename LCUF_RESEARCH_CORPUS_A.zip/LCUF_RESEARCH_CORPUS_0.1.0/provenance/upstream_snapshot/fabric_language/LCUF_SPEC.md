# LKVexa Columned Unikernel Fabric Language Draft 0.1

LCUF is a proposed columned language for composing governed computation across independently owned execution sites. The initial implementation parses a small deterministic subset, checks admission, produces canonical intermediate representation, and simulates a directed transfer between two sites in one process. Native unikernel generation, network transport, attestation, and the domain profile compilers remain implementation work.

## Implemented source format

Every source starts with `LCUF/0.1`, immediately declares one module, then declares one or more sites, explicit capability grants and directed links, declares the exact twelve column names, then ends with `end`. Empty lines and lines starting with `#` are ignored. Unknown declarations, duplicate identities, missing end markers, and trailing content are errors. Source strings use UTF 8.

```text
LCUF/0.1
module demo
site local trust=owner memory=64 steps=8
grant local caps=evidence.write
id | site | profile | op | inputs | output | type | effects | caps | after | budget | evidence
a | local | lcuf.scalar | const | 42 | answer | i64 | - | - | - | 1 | none
b | local | lcuf.evidence | emit | answer | - | unit | evidence.emit | evidence.write | - | 1 | receipt
end
```

| Column | Implemented meaning |
|---|---|
| id | Unique statement identity |
| site | Declared execution site |
| profile | Owner of the operation contract |
| op | Closed operation name |
| inputs | Ordered value identities, or a JSON scalar for const |
| output | Single writer value identity, or `-` for terminal operations |
| type | i64, bool, text, or unit |
| effects | Exact required operation effects |
| caps | Exact required operation capabilities |
| after | Additional statement dependencies |
| budget | Positive integer step reservation |
| evidence | none or receipt |

Identifiers match `[A-Za-z_][A-Za-z0-9_.-]*`. Comma lists have no internal whitespace. `-` is the empty list. Input operands may repeat; sets of capabilities, effects, and explicit dependencies may not. A raw pipe cannot occur in a cell; encode a pipe inside a JSON text literal as `\u007c`. Floating point, tensors, mutable references, general expressions, loops, function calls, file access, and sockets have no implementation in this subset.

## Operation contracts

| Operation | Profile | Inputs and output | Effects | Capabilities |
|---|---|---|---|---|
| const | lcuf.scalar | JSON scalar to i64, bool, or text | none | none |
| add | lcuf.scalar | Two i64 values to i64 | none | none |
| mul | lcuf.scalar | Two i64 values to i64 | none | none |
| copy | lcuf.fabric | One remote value to a same type local value | fabric.transfer | fabric.receive at destination; fabric.send granted at source |
| assert_eq | lcuf.test | Two same type values to unit | none | none |
| emit | lcuf.evidence | One value to unit and a local receipt | evidence.emit | evidence.write |

I64 values stay within signed 64 bit bounds; overflow rejects admission. Boolean literals are not integers. Every operation must carry exactly its effect and capability contract; a row cannot claim purity while copying across sites. Grants are explicit. Copy requires a directed source to destination link, and each input to another operation must already belong to the operation's site. A trust label identifies a domain; it does not authenticate an owner.

## Admission and scheduling

All rows are checked and included. A dependency exists for each consumed value and each `after` identity. Explicit `after` dependencies must belong to the same site. Use a checked copy and its local row identity to establish remote ordering. The graph must be acyclic. At each step the lexicographically first ready row executes, then readiness is recomputed. Output identities have one writer. Arithmetic and copy types must match. Assertions are evaluated against the constant computation in this subset and fail admission when false.

Resource integers use ASCII digits and must be between one and the signed 64 bit maximum. The sum of row reservations at each site cannot exceed its `steps`. Output memory is conservatively retained until the end: i64 reserves eight bytes, bool reserves one byte, and text reserves its UTF 8 length. Copy reserves output bytes at its destination. Text requires valid Unicode scalar values; unpaired surrogate escapes reject admission. This bound covers retained value payloads. It does not bound compiler memory, object overhead, receipts, driver buffers, or a future native heap. A native backend must enforce its own complete resource model before emitting an admitted image.

## Canonical representation and evidence

The semantic fingerprint includes module, sites, trust labels, resource limits, grants, directed links, every row and its policy fields, derived admission, and compiler version. Canonical JSON sorts object keys and set fields, normalizes link order, and emits graph ordered rows. Source positions and formatting are excluded from the semantic fingerprint. A separate SHA 256 records source bytes. Capability, trust, budget, and effect changes therefore change semantic identity.

Simulation receipts bind row identity, site, profile, semantic fingerprint, result hash, and previous receipt hash. Optional per row receipts are local host instrumentation; they do not grant site I/O authority. The explicit emit operation still requires evidence.write. Receipts declare `LCUF_LOCAL_SIMULATION` and `single_process_model`. A SHA 256 chain enables integrity comparison with a trusted head. It is not a signature, remote execution attestation, MSSL resealing, or proof that a device or network ran.

## Compiler interface

Use Python 3.10 or later; there are no third party dependencies.

```text
python lcuf.py check examples/federated_sum.lcuf
python lcuf.py compile examples/federated_sum.lcuf --out generated/federated_sum.ir.json
python lcuf.py simulate examples/federated_sum.lcuf --out generated/federated_sum.simulation.json
python lcuf.py plan examples/federated_sum.lcuf --out generated/federated_sum.target_plan.json
python -m unittest discover -s tests -v
```

The CLI compiles source before simulation and does not load externally supplied IR. Rejection returns exit code 2. The `plan` command returns `design_plan_only` and null bootable images. The regression suite covers denial, implicit remote access, duplicate writers, unknown syntax, missing end markers, dependency cycles, type mismatch, overflow, failed assertions, admission limits, receipt chains, and policy preserving fingerprints.

## Mathematical foundation

JA's intended foundation is the user-supplied 8S Penteract S3 Master Coupled Mechanics Law. The [coupling8s profile](profiles/coupling8s/PROFILE.md) preserves its equations, coordinate convention and independence/efficacy admission. Its separate reference evaluator is scoped mathematical computation. The closed `lcuf.scalar` operations in this initial column parser are explicitly defined conventional i64 reference operations, not a completed JA arithmetic frontend. Profile integration must bind actual JA operator semantics and versioned coupling metadata before accepting JA sources.

## Compatibility boundary

LCUF 0.1 is a new experimental format. Existing JA, DeepML, LCTL, LCTL C, MSSL and MCRT programs retain their own versions and semantic authorities. The prototype does not compile those profiles or claim binary compatibility with their IR. Future adapters must preserve source hashes and policy fields, lower through the owner's grammar and semantics, and pass positive and negative conformance cases. Catalog feature labels and modeled runtime outcomes cannot substitute for those passes.
