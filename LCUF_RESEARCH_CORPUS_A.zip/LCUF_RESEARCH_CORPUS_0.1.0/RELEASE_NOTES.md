# LCUF Research Corpus 0.1.0 release notes

Prepared 9 October 2026 as a separate research corpus derived from the frozen LKVexa audit and LCUF host reference. The source archives, prior audit release and arithmetic reference are preserved.

## Added research artifacts

1. Eight formal volumes specify lexical forms, static types, effects, capabilities, dependency graphs, execution, resource reservations, canonical identity, local receipts, diagnostics and extension boundaries. Forty-eight requirement IDs, twelve scoped proof sketches and thirty focused observations supply traceability.
2. Nine institutional systems volumes develop architecture, all 25 source-corpus roles, native image and ABI contracts, drivers, nested federation, delegated authority, crash recovery, security, evaluation, data governance and release assurance. Sixty-six proposed requirements, seventy-two scenario contracts and twenty-two primary references are machine indexed.
3. The mathematical collection preserves JA's 8S Penteract–S³ foundation, five coordinates indexed 4–8 and the author's coupled gate. It supplies analytical derivations, explicit unknown semantics, a separately versioned numerical admission policy and a draft typed adapter.
4. The core conformance corpus contains 10,144 master records with exact source bytes, independently constructed expectations, actual host observations, requirement labels and deterministic partitions. The mathematical corpus contains 1,619 unique operation/input cases and a separate 500-case NumPy differential layer.
5. Portable validation, exact source extraction, strict record schemas, fault sensitivity probes, environment/dependency identities and integrity manifests make the evidence reviewable after extraction. Selected upstream audit/specification evidence is included byte-exact.

## Compatibility and assurance boundaries

The six-operation reference compiler is byte-identical to the frozen predecessor. No new opcode, imported profile frontend, native code generator, network transport or authenticated external-IR admission path is claimed. The mathematical research wrapper is distinct from the frozen arithmetic profile; its tolerance ceiling is explicit policy rather than a change to the author's law.

The core validator independently binds receipt bodies to scheduled rows and actual results as well as verifying the chain. Typed JSON equality distinguishes Boolean values from integers. Population checks prevent an empty or truncated dataset from passing. Regression checks verify those boundaries. These are assurance additions around the preserved runtime, rather than a semantic version change of its language.

Completed observations are host compiler, validator, arithmetic, numerical and artifact consistency checks. Proposed systems scenarios remain unperformed. Proof sketches are human arguments with named assumptions. Reviewer identity, operational authority, external approval and certification require real participants and are not fabricated metadata.

## Preserved source and rights information

The selected upstream snapshot contains the audited documents and exact source files referenced by the new registries. Its manifest states the selection and retained byte identities. Original source links inside those copied documents can refer to payloads outside that selection. The original full audit release remains the larger archival source.

The copied figure, corpus materials and bundled dependencies retain their existing ownership and licensing. SHA-256 identity establishes integrity relative to a trusted manifest, not authorship or an umbrella license. The final ZIP receipt records package identity separately from the manifest inside the extraction.
