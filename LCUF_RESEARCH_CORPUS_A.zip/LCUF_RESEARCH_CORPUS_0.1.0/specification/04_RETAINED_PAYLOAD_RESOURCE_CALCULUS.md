# Volume 04 — Retained-payload resource calculus

## 4.1 Resource model and its domain

The reference functions are [`positive_integer`](../runtime/lcuf.py) (29) and the reservation/evaluation portions of `compile_source` (138, 162–180). The calculus has two per-site coordinates: a declared reservation sum in abstract steps and retained output payload in bytes. It is a static model for the admitted finite program. It is not a whole-process memory bound or a measured execution-time model.

For every site `s`, let `K(s)=S(s).steps` and `M(s)=S(s).memory`; for every row `r`, let `b(r)` be its declared budget. The implementation accepts no unspecified, negative, zero, fractional, symbolic or infinite capacities. All rows participate, including terminal and unused rows. Declared sites with no rows have a derived reservation and payload of zero, although their declared limits remain positive.

<a id="LCUF-RES-001"></a>
## 4.2 Positive resource integer predicate

**LCUF-RES-001.** Define the resource domain `Resource={1,...,2^63−1}`. Its accepted text form is a canonical ASCII decimal string matching `[1-9][0-9]*`, at most nineteen digits, with numeric value not exceeding `9223372036854775807`.

```text
ascii_decimal(t) ∧ first_digit(t)≠0 ∧ length(t)≤19
1≤decimal_value(t)≤2^63−1
──────────────────────────────────────────────────── RESOURCE
resource(t) ⇓ decimal_value(t)
```

The decimal length check is performed before integer conversion. It prevents excessively long resource numerals from being converted by this helper. It does not cap all text cells or identifier lengths. Signs, leading zeros, scientific notation and non-ASCII digits reject. `memory=0`, `steps=08`, and row budget `+1` are invalid even though an application might interpret them as nonnegative numbers.

Site declaration recognition initially matches `[0-9]+`; it then invokes the positive-resource predicate. Thus `memory=0` reaches the resource diagnostic, while an Arabic-Indic digit in the declaration fails the site's syntax regex first. Row budgets invoke the predicate directly. A nineteen-digit value above i64 maximum receives the more specific bounds diagnostic. These distinctions are represented in the diagnostic taxonomy.

<a id="LCUF-RES-002"></a><a id="LCUF-RES-004"></a>
## 4.3 Step reservation algebra

**LCUF-RES-002.** The total site reservation is:

```text
B(s) = Σ{ b(r) | r∈R ∧ site(r)=s }
admit_steps(R,S) ⇔ ∀s∈dom(S), B(s)≤K(s)
```

The sum uses exact host integers; it is not truncated to i64. Each row budget is bounded individually, and any excessive total fails against the bounded declared site limit. No value-producing/terminal distinction exempts a row. A pure constant still reserves steps. The compiler computes these totals during the structural pass, checks graph validity first, and rejects excessive totals before its value/payload evaluation.

**LCUF-RES-004.** `budget` is a reservation supplied by the source, not a decrementing execution fuel meter. The reference does not measure Python instruction count, CPU cycles, text decoding work, network time or device effort. There is no rule assigning a mandatory different cost to add, multiply, copy or emit. A valid budget of one for each operation is accepted when the site's reservation sum fits. Therefore `B(s)≤K(s)` establishes the declared reservation contract, not a wall-clock bound.

Because all budgets are positive, `B(s)≥|{r:site(r)=s}|`. The number of site rows cannot exceed its declared step capacity, but a larger row budget can reduce the admitted row count. This useful cardinality implication must not be inverted into an exact complexity statement.

<a id="LCUF-RES-003"></a>
## 4.4 Value payload measure

**LCUF-RES-003.** For an admitted value `v:τ`, define:

```text
μ(i64,v)  = 8
μ(bool,v) = 1
μ(text,v) = |UTF8(v)|
```

No named unit output exists, so no payload rule for a unit binding is required. `assert_eq` and `emit` contribute zero retained output bytes. Their row budgets and optional receipt work still exist outside that zero-output measure. An empty string contributes zero bytes; the site capacity remains a positive resource integer.

For writer row `W(x)`, assign the payload to that row's declared site. After evaluation:

```text
P(s) = Σ{ μ(type(W(x)), V(x)) | x∈dom(V) ∧ site(W(x))=s }
admit_memory(V,R,S) ⇔ ∀s, P(s)≤M(s)
```

Text values are encoded after type validity has been established. `"é😀"` occupies six UTF 8 payload bytes: two for `é` and four for the supplementary character. A text newline occupies one payload byte, even though canonical JSON represents it with an escape and quotation marks. The measure concerns decoded value payload, not serialized JSON size.

## 4.5 Retention, copies and conservative charging

The reference retains every named output until completion. It has no liveness analysis, release operation, overwrite, garbage-collection policy or ownership transfer. Let `V_i` be the store after the first `i` rows and `P_i(s)` its measured payload. Single writers and absence of deletion imply:

```text
dom(V_i) ⊆ dom(V_i+1)
P_i(s) ≤ P_i+1(s) ≤ P_n(s)
```

Terminal steps do not change the store. A copy adds a destination binding while preserving the original binding. If an edge-site text of `m` bytes is copied to cloud, the model charges `m` to edge and another `m` to cloud. Repeated reads of a binding do not add output payload; each additional writer producing an equal value does. In a Python host, equal or copied immutable objects may share storage. Counting both output payloads is conservative relative to binding payload ownership, not a statement about object identity.

The final sum therefore bounds every prefix's retained payload in this model. It need not be the tightest bound a future lifetime-aware compiler could derive. Introducing value release or move semantics would require a new calculus and explicit source/runtime contracts; those are not current forms.

## 4.6 Worked resource derivation

The common example has the following increments:

| Row | Site | Budget | Retained increment | Reason |
|---|---|---:|---:|---|
| `a` | edge | 1 | 8 | i64 `left` |
| `b` | edge | 1 | 8 | i64 `right` |
| `c` | edge | 1 | 8 | i64 `total` |
| `d` | cloud | 1 | 8 | destination i64 `received` |
| `e` | cloud | 1 | 8 | i64 `expected` |
| `f` | cloud | 1 | 0 | terminal assertion |
| `g` | cloud | 1 | 0 | terminal emit |

Consequently `B(edge)=3≤8`, `B(cloud)=4≤8`, `P(edge)=24≤64`, and `P(cloud)=16≤64`. After `c`, edge is at its final payload. After `e`, cloud is at its final payload. Four receipts do not add to `P`; they belong to a separate excluded storage category.

Lowering edge memory to 23 rejects this program, while 24 is the exact accepted retained-payload boundary. Lowering edge steps to 2 rejects before payload evaluation; three is sufficient for its row reservations. Increasing either limit cannot change the computed scalar values, but changes semantic identity because limits are included in the IR. Removing row `e` is not a legal optimization of this example: its output is consumed by `f`. Adding an unused constant still increases the reservation and payload totals.

<a id="LCUF-RES-005"></a>
## 4.7 Exclusions and admissibility of conclusions

**LCUF-RES-005.** The resource calculus excludes source bytes, lexer/parser objects, compiler environments, graph sets, Python dictionaries and object headers, temporary arithmetic objects, canonical JSON encoding, hash working storage, receipt records, CLI rendering, filesystem buffers, future drivers, native stacks, native allocator metadata and network queues. The compiler computes values before completing memory admission; a large text literal can therefore allocate host memory even when its retained-payload sum later rejects.

The statement “admitted within 64 bytes at this site” means `P(s)≤64` under this measure. It cannot be used as a physical RAM-size claim. A bootable native backend would need at least a separate image/static-data measure, heap and stack discipline, driver-buffer closure, receipt/transport bounds, and enforcement at each execution boundary. Volume 08 treats those as future extension contracts.

## 4.8 Monotonicity and compositional reasoning limits

For a fixed already well-typed computation, raising `M(s)` or `K(s)` preserves the corresponding inequality. This is a simple capacity monotonicity property. It is not semantic-identity invariance: the changed limit is hashed. Adding an extra grant also may preserve capability admission while changing identity, unless the added grant violates duplicate-name parsing.

Independent subgraphs at the same site compose by adding `B` and `P`, provided their row/output identities are disjoint and no other static contracts are changed. At different sites, the totals compose componentwise. A new copy edge adds a destination output and row reservation; it cannot be modeled as a free routing annotation. Assertions and emits compose with zero retained outputs but positive steps and their respective evidence obligations. This additive reasoning is valid only for the finite current subset and does not generalize automatically to mutable references, recursion, dynamic allocation or asynchronous transport.
