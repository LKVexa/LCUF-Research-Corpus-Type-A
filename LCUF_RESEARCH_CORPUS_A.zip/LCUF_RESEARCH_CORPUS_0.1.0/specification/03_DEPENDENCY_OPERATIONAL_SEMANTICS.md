# Volume 03 — Dependencies and operational semantics

## 3.1 Two evaluations and one admission boundary

The relevant implementation is [`compile_source`](../runtime/lcuf.py) (108–185), with graph construction at 140–155, scheduling at 156–161, and constant evaluation at 166–180; [`simulate`](../runtime/lcuf.py) begins at 187. Compilation evaluates the entire finite computation to validate types, arithmetic bounds, assertions and retained memory. Simulation subsequently repeats the admitted computation and constructs optional receipts. These are two host evaluations, not speculative admission followed by native execution.

Let `R` be the finite row map, `W(x)` the unique row producing value `x`, and `site(r)` its declared site. Let `explicit(r)` be the parsed `after` set. Define predecessor sets:

```text
pred(r) = explicit(r) ∪ { W(x) | x occurs in operands(r) }
```

The representation uses sets; operand evaluation uses lists. A repeated operand therefore creates one predecessor but appears twice in the argument vector. `const` has no input references. A terminal row has no output writer but participates fully in the graph through its identity and incoming edges.

<a id="LCUF-GRAPH-001"></a><a id="LCUF-GRAPH-002"></a>
## 3.2 Identity and reference admission

**LCUF-GRAPH-001.** Row IDs must be unique. Every non-`-` output has one writer globally, including across sites. The global value namespace does not allow two different sites to define the same output name. Terminal rows may all use `output=-`, because this sentinel is never installed in `W`.

**LCUF-GRAPH-002.** Every operand must resolve through `W`, and every explicit dependency must resolve through `R`. Resolution occurs after all writers are indexed, so source row order does not impose a declaration-before-use restriction. A reference to a terminal row can be valid in `after`; it cannot be a value input because that row has no named output. Referencing one's own output or identity may resolve but produces a cycle, which is rejected separately.

The compiler does not discard unreachable or unused rows. All rows enter `R`, all effects/capabilities are checked, all reservations are charged, and every row is scheduled. There is no entry-point or dead-code elimination rule in this version.

<a id="LCUF-GRAPH-003"></a>
## 3.3 Control-order locality

**LCUF-GRAPH-003.** For every explicitly named `d∈after(r)`, require `site(d)=site(r)`. Input-derived predecessors may be remote only through the copy contract. A cloud row cannot directly say `after=a` when `a` belongs to edge; it must depend on a checked local copy row or its output.

This is a local ordering restriction, not a distributed happens-before protocol. The host scheduler sees all sites in one global graph. No network latency, acknowledgment ordering, timestamp or independent clock exists. Explicit `after` is retained in canonical IR even when it is redundant with an input edge. Therefore redundant control metadata can change semantic identity without changing the execution sequence.

<a id="LCUF-GRAPH-004"></a><a id="LCUF-GRAPH-005"></a>
## 3.4 Acyclicity and deterministic schedule

**LCUF-GRAPH-004 / LCUF-GRAPH-005.** The runtime repeatedly selects exactly one lexicographically least ready row. For remaining row set `U`, a row is ready precisely when none of its predecessors remain in `U`:

```text
ready(U) = { r∈U | pred(r)∩U=∅ }
choose(U) = min_lex ready(U)
schedule(R): U0=dom(R); O0=[]
Ui+1=Ui\{choose(Ui)}; Oi+1=Oi·[choose(Ui)]
```

If `U` is nonempty and `ready(U)` is empty, admission rejects with `dependency cycle`. The source identifiers are ASCII, so Python's ordinary string order supplies a stable ordinal order for admitted identifiers. The minimum is recomputed after each chosen row, rather than selecting an entire ready batch and then executing that batch. Newly released rows can precede older ready rows when their IDs sort earlier.

For a concrete contrast, suppose `a` and `z` are initially ready and `b` depends only on `a`. The reference order is `a,b,z`, not `a,z,b`. This is a one-at-a-time scheduler. It produces a linear extension of the predecessor relation; it does not produce parallel partitions or claim fair resource scheduling among independent sites.

At every successful iteration, `|U|` decreases by one. Thus graph scheduling terminates after exactly `|R|` selections for a finite admitted source. It remains possible for earlier parsing or host allocation to exhaust process resources; this termination statement assumes those finite structures have been constructed successfully.

<a id="LCUF-SEM-001"></a><a id="LCUF-SEM-002"></a>
## 3.5 Store and value transitions

Define an immutable binding store `V : Output ⇀ Value` and schedule `O=[r0,...,rn−1]`. At step `i`, all input values are looked up in the ordered operand list. An evaluation configuration is `⟨i,V⟩`. Successful value transitions are:

```text
const(v):     ⟨i,V⟩ → ⟨i+1, V[x↦v]⟩
add(a,b):     ⟨i,V⟩ → ⟨i+1, V[x↦V(a)+V(b)]⟩
mul(a,b):     ⟨i,V⟩ → ⟨i+1, V[x↦V(a)×V(b)]⟩
copy(a):      ⟨i,V⟩ → ⟨i+1, V[x↦V(a)]⟩
```

Each stored result is checked against its declared value type, including i64 bounds and text UTF 8 validity. The single-writer invariant means `x` is not already bound. The source binding survives copy; only a new destination binding is added. The reference may share immutable Python string or integer objects internally. The language observation is value equality and two independently accounted output payloads, not a promise of separate host object allocation.

**LCUF-SEM-001** identifies the scalar result equations. **LCUF-SEM-002** identifies copy's value-preserving, explicit remote transfer model. These equations assume all static premises of volume 02. They cannot be used to authorize an operation outside its admitted site or capability contract.

<a id="LCUF-SEM-003"></a><a id="LCUF-SEM-004"></a>
## 3.6 Terminal transitions

For a successful assertion, `V(a)=V(b)` and the value store is unchanged:

```text
assert_eq(a,b), V(a)=V(b):  ⟨i,V⟩ → ⟨i+1,V⟩
assert_eq(a,b), V(a)≠V(b):  reject
emit(a):                   ⟨i,V⟩ → ⟨i+1,V⟩
```

**LCUF-SEM-003.** The two assertion operands have already passed equal-type and same-site checks. Equality is the host equality operation over the admitted scalar domains. A false assertion is rejected during compile-time evaluation (`constant assertion fails`) and would reject again during simulation (`assertion failed`) if a compiler-produced invariant were somehow broken.

**LCUF-SEM-004.** Emit has no named output and leaves `V` unchanged. Compilation does not construct receipts; it simply validates emit's static contract and skips it in the retained-output evaluation. Simulation takes its input value as the row's evidence result and appends the required receipt. No file path, socket, external destination or native syscall is an emit operand in this version.

<a id="LCUF-SEM-007"></a>
## 3.7 Compiler evaluation versus simulator result

**LCUF-SEM-007.** Compile-time evaluation is total over the six admitted operations, subject to declared value assertions. It cannot be bypassed by requesting `check` rather than `simulate`: the CLI calls `compile_source` for every command. A `check` success therefore includes the finite value/bounds/assertion and retained-memory derivation, not only syntax and graph checks.

For evidence semantics, define `result(r,V)` separately from named output:

```text
result(const/add/mul/copy) = the produced value
result(assert_eq)         = None after equality succeeds
result(emit)              = its input value
```

The simulator uses this result for optional receipt hashes. It never stores terminal results under `-`. An assert receipt therefore hashes unit/null while an emit receipt hashes the emitted input despite both source rows having `type=unit`. This is a deliberate separation between output typing and instrumentation result.

<a id="LCUF-SEM-008"></a>
## 3.8 Trusted direct-IR API precondition

**LCUF-SEM-008.** The public Python function `simulate(compiled)` checks that `hash_value(compiled.ir)` matches the supplied semantic digest. It does not re-run source admission, check all external-IR field schemas, verify grants/links again, or establish a signature. The operational propositions assume `compiled` came from successful `compile_source` and was not modified.

A modified object with its hash recomputed can violate that precondition yet still simulate. For example, replacing the sender grant with an empty list and recomputing the IR digest does not make `simulate` reject the already ordered rows. This is recorded as `REF-025`, a trust-boundary observation, not a claim that the CLI loads unsafe external IR. The CLI has no external-IR input command. A future loader requires its own validator contract before this precondition can be removed.

## 3.9 Worked graph and execution derivation

For the seven-row program:

| Row | Predecessors | Operation result | Store extension |
|---|---|---|---|
| `a` | `∅` | `20` | `left↦20` |
| `b` | `∅` | `22` | `right↦22` |
| `c` | `{a,b}` | `42` | `total↦42` |
| `d` | `{c}` | `42` | `received↦42` |
| `e` | `∅` | `42` | `expected↦42` |
| `f` | `{d,e}` | `None` | None |
| `g` | `{d,f}` | `42` | None |

Initially `{a,b,e}` is ready. Choosing `a` leaves `{b,e}`; choosing `b` releases `c`, which sorts before `e`; choosing `c` releases `d`, also before `e`. Thus `a,b,c,d,e,f,g` is the exact sequence. Receipt selection filters this sequence to `c,d,f,g`. The final store has exactly five outputs. There is no host-global I/O or physical network transition in this derivation.
