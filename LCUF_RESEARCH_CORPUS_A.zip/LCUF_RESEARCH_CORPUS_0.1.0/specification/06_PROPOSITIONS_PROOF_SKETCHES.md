# Volume 06 — Scoped propositions and proof sketches

## 6.1 Proof status and assumptions

These arguments are human-readable proof sketches for the finite model reconstructed in volumes 01–05. They have not been checked by a theorem prover. Executed observations are separately identified in [`REFERENCE_CHECKS.json`](REFERENCE_CHECKS.json); they corroborate selected behaviors and do not turn the sketches into exhaustive certification.

The common assumptions are:

| Assumption | Meaning |
|---|---|
| A1 — Pinned reference | `runtime/lcuf.py` has the reviewed byte identity and runs with ordinary Python string, integer, JSON and UTF 8 behavior |
| A2 — Successful admission | `c=compile_source(source)` returns successfully; every static/value/resource check ran |
| A3 — Immutable admitted object | `c.ir` and related digest fields are not altered between compilation and the considered simulation |
| A4 — Finite successful host work | Source and constructed data are finite, with sufficient host memory/time; no asynchronous mutation or process interruption invalidates the model |
| A5 — Cryptographic comparison | Where explicitly invoked, SHA256 collision/second-preimage resistance is assumed; no digest injectivity is asserted |
| A6 — Trusted evidence anchor | Where explicitly invoked, an expected chain head and required receipt-row sequence are obtained independently from a trusted record/IR |

A1–A4 are needed for execution propositions. A5–A6 are additional evidence assumptions, not language admission facts. A grant or trust label does not establish them. Sources that reject are counterexamples to admission, not subjects of the successful-execution propositions.

## 6.2 LCUF-PROP-001 — Unique bindings

**Rules:** LCUF-GRAPH-001, LCUF-TYPE-004. **Assumptions:** A1–A2.

**Statement.** Every named output in admitted IR has exactly one writer row. Terminal rows create no named output. During ordered evaluation, no store update overwrites an earlier binding.

**Sketch.** The first compiler pass inserts each non-`-` output into the global `outputs` map and rejects if that key is already present. Terminal-shape checks force terminal rows to use `-`; value-shape checks force value rows to use a name. Each value row appears once in the schedule, because each iteration removes one unique row ID. Its update can therefore occur once only, and no other row has the same output key. This establishes an immutable binding model, not linear ownership of all payloads: copy intentionally creates a second binding for an equal value.

**Limit.** A manually constructed IR with duplicate outputs can violate this proposition even if its digest is recomputed. A2–A3 cannot be dropped.

## 6.3 LCUF-PROP-002 — Topological scheduling and cycle rejection

**Rules:** LCUF-GRAPH-002/004/005. **Assumptions:** A1–A2/A4.

**Statement.** The admitted schedule lists every row exactly once after all its predecessors. For a finite fully resolved graph, the scheduler succeeds exactly when the predecessor graph is acyclic.

**Sketch.** Chosen rows are ready, so no predecessor remains when they are appended. One row is removed from `U` per step, proving uniqueness and finite descent. If a finite acyclic nonempty residual graph had no ready node, every node would have a remaining predecessor. Following predecessors indefinitely would repeat a finite node, constructing a cycle, a contradiction. Conversely, a residual directed cycle cannot lose its first member through a readiness step because that member still has another cycle member as predecessor. Once non-cycle ready work is exhausted, no complete order exists and `dependency cycle` is raised.

**Limit.** The proof concerns graph construction after defined-reference checks. It does not assign a cycle diagnostic to an undefined dependency, which rejects earlier.

## 6.4 LCUF-PROP-003 — Deterministic schedule

**Rules:** LCUF-GRAPH-005, LCUF-ID-001. **Assumptions:** A1–A2/A4.

**Statement.** A fixed resolved graph and distinct admitted row IDs determine exactly one runtime schedule.

**Sketch.** The ready set is a function of `U` and fixed predecessor sets. Its lexicographically least identifier is unique. The next `U` is therefore unique. Induction from the initial row set yields one sequence. Input source order does not enter this transition. Recomputing the minimum after each step is essential; a batched-ready scheduler can produce a different sequence such as `a,z,b` instead of `a,b,z`.

**Limit.** This is determinism of a serial host ordering, not fairness, real-time scheduling, parallel confluence, or a distributed consensus result.

## 6.5 LCUF-PROP-004 — Operand availability and progress

**Rules:** LCUF-GRAPH-001/002/004, LCUF-TYPE-003/004. **Assumptions:** A1–A4.

**Statement.** At each scheduled row, every named input is present in the value store, and the operation has the required argument count. Evaluation can advance unless a host interruption violates A4.

**Sketch.** Each operand resolves to a writer in the full output map. The writer is a predecessor, so it is scheduled earlier. By output-shape admission it is a value operation and installs its output. Store bindings are never removed or overwritten. The operand list therefore resolves at the consumer. Arity was checked during structural admission. All operations belong to the closed six-operation table. Value/overflow/assertion failures were already excluded by successful compile-time evaluation; determinism and A3 preserve those results during simulation.

**Limit.** This progress statement excludes externally modified or malformed IR and excludes arbitrary future operations with I/O or divergence.

## 6.6 LCUF-PROP-005 — Value type preservation

**Rules:** LCUF-TYPE-001/004/005/006, LCUF-SEM-001/002. **Assumptions:** A1–A4.

**Statement.** After every evaluation prefix, each named store binding belongs to the declared type of its unique producer.

**Sketch.** Initially the store is empty. A constant is checked against its declared value domain. Add/multiply consume checked i64 operands and their computed results pass i64 bounds. Copy consumes the same declared producer type and preserves the value. Every named result is checked before insertion. Terminals add no bindings. Induction over the schedule establishes preservation. For text, strict UTF 8 encoding excludes unpaired surrogates; for bool, the explicit integer exclusion prevents accidental identification of booleans with i64.

**Limit.** Preservation does not imply overflow cannot occur in arbitrary source. It says an overflowing source rejects before an admitted IR is returned. There is no proof of an unimplemented native representation.

## 6.7 LCUF-PROP-006 — Explicit cross-site value locality

**Rules:** LCUF-CAP-001/002/003/004, LCUF-GRAPH-003. **Assumptions:** A1–A2.

**Statement.** Every admitted non-copy value input is produced at the row's own site. Every admitted copy input is remote, has a declared directed source-to-destination link, and has checked sender/receiver grants. Every explicit `after` is local.

**Sketch.** The operand pass compares producer and consumer sites. A differing site requires copy, a directed link and sender grant. A same-site copy rejects. Required receiver capabilities were checked in the earlier exact-contract pass. The explicit dependency pass rejects any `after` whose row site differs. These exhaustive branches establish the stated declarative locality.

**Limit.** This is not information-flow noninterference, authenticated peer authorization, confidential transport, capability revocation, or an ownership proof. Trust labels currently do not impose an additional policy relation, and copied values remain available at the sender.

## 6.8 LCUF-PROP-007 — Compiler/simulator store agreement

**Rules:** LCUF-SEM-001/002/003/004/007/008. **Assumptions:** A1–A4.

**Statement.** The simulator's final named-value store equals the compiler's internal constant-evaluation store for the same admitted IR. Assertions succeed in both evaluations.

**Sketch.** Both evaluations traverse the same graph order and use the same constant, integer add, integer multiply and value-preserving copy equations. Inductively, their operand vectors and value outputs coincide. Compiler terminals skip store insertion; simulator terminals likewise have output `-`. An assertion's operand equality is identical under store agreement. Emit produces an instrumentation result in simulation but adds no store binding, so it does not invalidate store equality.

**Limit.** The compiler does not return its internal store or receipts; this is a derived comparison of its code paths. Receipt equality is a separate proposition. A future nondeterministic operation would require a new agreement condition.

## 6.9 LCUF-PROP-008 — Retained-payload bound

**Rules:** LCUF-RES-003/005, LCUF-GRAPH-001. **Assumptions:** A1–A4.

**Statement.** At every evaluation prefix and site `s`, the model's retained named-output payload is at most the admitted final `P(s)`, which is at most declared memory `M(s)`.

**Sketch.** Each value-row transition adds a fresh output with nonnegative payload measure; terminals leave the store unchanged. There is no deletion or rebinding. The per-site payload sequence is monotone and ends at `P(s)`. Successful admission checks `P(s)≤M(s)`. This proves the inequality for every prefix. Empty text can contribute zero, so monotonicity is non-strict.

**Limit.** Compiler memory, object headers, receipts, transport and future native heap are excluded. This proposition cannot certify a physical heap size or prevent pre-admission process exhaustion.

## 6.10 LCUF-PROP-009 — Reservation and capacity monotonicity

**Rules:** LCUF-RES-001/002/004, LCUF-ID-004. **Assumptions:** A1–A2.

**Statement.** For each site, the number of rows is bounded by its accepted reservation sum and step capacity. Raising a capacity preserves the corresponding resource inequality for an otherwise fixed computation.

**Sketch.** Every row budget is at least one, so row count ≤ sum of budgets ≤ site steps. If `B≤K`, then `B≤K′` for any `K′≥K`; likewise `P≤M′` for `M′≥M`. Types, values and graph need not change. Capacity fields remain in IR, however, so the normalized program identity can change.

**Limit.** These inequalities are declared reservation properties, not CPU or wall-clock estimates. Lowering a capacity below an exact sum rejects, but raising a capacity does not prove enough physical RAM or time exists.

## 6.11 LCUF-PROP-010 — Canonical presentation invariance

**Rules:** LCUF-LEX-010, LCUF-ID-001/002/003/005. **Assumptions:** A1–A2/A4; A5 only for digest interpretation.

**Statement.** Two successfully admitted sources that differ only by permitted presentation changes and normalize to identical declaration/row data produce identical IR. Their raw source hashes may differ.

**Sketch.** Preprocessing removes the allowed comments/blank records and edge whitespace. JSON decoding removes equivalent literal escape presentation. Declarations become maps, set fields are sorted, directed links are sorted, and graph order is deterministically reconstructed. Physical line numbers are removed. With the same normalized data, derived reservation/payload values coincide. Canonical serialization of equal IR is equal by definition. Raw source hashing precedes these transformations.

**Limit.** Redundant `after`, swapped arithmetic operands, absent versus empty grants, unused declarations and Unicode normalization are not automatically in this equivalence class. Equal final values alone do not imply identical IR.

## 6.12 LCUF-PROP-011 — Deterministic receipt construction

**Rules:** LCUF-SEM-005, LCUF-ID-001. **Assumptions:** A1–A4.

**Statement.** Repeated simulation of the same unmodified admitted object produces identical values, selected receipt rows, bodies, digest sequence and head.

**Sketch.** Schedule and row results are deterministic. Evidence selection is fixed in each IR row. The initial previous hash is fixed; each next body is a deterministic function of fixed fields, row result and previous digest. Induction establishes identical chains. No timestamp, nonce or run ID perturbs the construction.

**Limit.** This establishes reference replay consistency. It provides no freshness, uniqueness per execution, replay prevention or physical attestation.

## 6.13 LCUF-PROP-012 — Conditional chain alteration detection

**Rules:** LCUF-SEM-005, LCUF-ID-007. **Assumptions:** A1, A5–A6, and an independently obtained expected IR/receipt selection.

**Statement.** Comparing an expected chain and trusted head using the defined body recurrence makes an altered body, reordered selected row, or truncation detectable, except under a hash collision/second-preimage event.

**Sketch.** At the first altered body, either its digest differs or the attacker has supplied a body producing an equal expected digest. A different digest changes subsequent `previous_sha256` fields and the computed final head. Reordering similarly changes body fields and recurrence. Truncation yields a prefix head rather than the trusted final head. A verifier must also require the expected selected-row sequence to prevent interpreting a self-consistent short chain as complete.

**Limit.** Without a trusted head and expected sequence, an attacker can create a complete self-consistent replacement. The construction contains no key or signature. The pinned runtime constructs receipts but does not implement this full external verification service.

## 6.14 Non-propositions and research obligations

No proposition here establishes that native images boot, a network transferred data, a device ran, JA arithmetic was integrated, a trust label was authenticated, or a receipt was externally signed. No complexity theorem bounds total compiler memory. No proof says recomputing a modified IR hash recreates source admission. These are intentionally excluded conclusions, with future extension contracts in [volume 08](08_GLOSSARY_EXTENSION_CONTRACTS.md). The practical research obligation is to preserve these assumptions in datasets and tool interfaces rather than silently broadening “pass.”
