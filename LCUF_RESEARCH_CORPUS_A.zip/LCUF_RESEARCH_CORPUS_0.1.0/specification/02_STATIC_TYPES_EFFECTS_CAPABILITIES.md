# Volume 02 — Static types, effects and capabilities

## 2.1 Judgment domains and static environments

The implementation authorities are [`OPS`](../runtime/lcuf.py) (lines 11–12), `check_value` (100), and the structural/operand passes of `compile_source` (108–155). The formal judgments here restate those checks. They are not a dependent type system or an implemented proof language.

Let `S` be the finite map of site declarations; `G(s)` the declared capability set at site `s`, or the empty set when no grant exists; `L ⊆ Site × Site` the directed `copy` links; `R` the row-ID map; and `Γ(x)=(producer,site,type)` the output-writer environment. `Γ` is built over all rows before inputs are resolved, so forward references are possible when the resulting graph is acyclic. One writer is required for each named output. `-` is not a named output and is never entered into `Γ`.

The row judgment is written:

```text
S;G;L;Γ;R ⊢ r : (site, output-shape, type, effects, capabilities)
```

The colon summarizes checked metadata; it does not imply that `effects` are executable hooks. In this reference, effects and capabilities are static authority requirements. Their names are parsed as identifiers and compared against closed operation contracts. Only explicit `emit` has the reference operation's evidence-writing contract, and even that operation emits a local data record rather than performing an external I/O authorization exchange.

<a id="LCUF-TYPE-001"></a>
## 2.2 Scalar value domains

**LCUF-TYPE-001.** Define the mutually interpreted value domains:

```text
Val(i64)  = { n ∈ integers | −2^63 ≤ n ≤ 2^63−1 }, excluding booleans
Val(bool) = { true, false }
Val(text) = strings that encode under strict UTF-8
Val(unit) = { None } in the host metalanguage
```

The implementation explicitly excludes booleans from `i64`, because Python's `bool` is a subclass of `int`. The mathematical domains must therefore follow `check_value`, not Python's broad `isinstance(value,int)` alone. Text is measured by encoded bytes, not code points or graphemes. Unpaired surrogate values are excluded. The source label `unit` is used for terminal rows, but no admitted value row produces a named unit output.

For a decoded literal `v` and value type `τ∈{i64,bool,text}`, the constant rule is:

```text
v ∈ Val(τ)      output(r)=x ≠ "-"      site(r)∈dom(S)
────────────────────────────────────────────────────────── CONST
Γ ⊢ const(v) at site(r) ⇒ x:τ
```

The actual row also needs the profile and exact effect/capability constraints below. `null` may parse as `None`, but fails value-output admission; it cannot be used to bootstrap a unit operand. A JSON float such as `1.0` does not become an integer through coercion.

<a id="LCUF-TYPE-002"></a><a id="LCUF-TYPE-003"></a>
## 2.3 Closed profile ownership and arity

**LCUF-TYPE-002 / LCUF-TYPE-003.** Operation identity determines one exact profile and arity. Declaring a different profile is a rejection even if the remaining cells would be well typed.

| Operation | Required profile | Operand count | Named result |
|---|---|---:|---|
| `const` | `lcuf.scalar` | Zero value references; one scalar literal cell | `i64`, `bool` or `text` |
| `add` | `lcuf.scalar` | 2 | `i64` |
| `mul` | `lcuf.scalar` | 2 | `i64` |
| `copy` | `lcuf.fabric` | 1 | Same value type as remote producer |
| `assert_eq` | `lcuf.test` | 2 | No output; source type `unit` |
| `emit` | `lcuf.evidence` | 1 | No output; source type `unit` |

These strings do not activate external profile compilers. In particular, JA, DeepML, LCTL, MSSL, MCRT and the separate coupling8s mathematical evaluator are not accepted operations in this parser. A registry entry or prose description does not enlarge `OPS`.

<a id="LCUF-TYPE-004"></a>
## 2.4 Output-shape rules

**LCUF-TYPE-004.** Value operations are `const`, `add`, `mul`, and `copy`. They require a named output and a type other than `unit`. Terminal operations are `assert_eq` and `emit`. They require exactly `output=-` and `type=unit`.

```text
op∈{const,add,mul,copy}    τ≠unit    output=x≠"-"
────────────────────────────────────────────────── VALUE-SHAPE
valid_output_shape(op,x,τ)

op∈{assert_eq,emit}       τ=unit    output="-"
────────────────────────────────────────────────── TERMINAL-SHAPE
valid_output_shape(op,"-",unit)
```

A terminal row's `unit` label denotes absence of a named value result. It does not say that every receipt hashes JSON `null`: an assertion receipt does, while an emit receipt hashes the emitted operand. This distinction is formalized in volume 05. There are no mutable assignments, rebinding, multiple outputs, unit-producing variables, polymorphic functions or implicit casts.

<a id="LCUF-TYPE-005"></a><a id="LCUF-TYPE-006"></a>
## 2.5 Operand typing and finite arithmetic

**LCUF-TYPE-005.** For `add`, `mul`, and `copy`, each producer type must equal the row's declared result type. Since arithmetic already requires `i64`, both arithmetic operands are i64 values. For `assert_eq`, the two producer types must equal each other; the row's own type remains `unit`. `emit` accepts any value available from an admitted producer and does not require that operand to have type `unit`.

```text
Γ(x)=(a,s,i64)   Γ(y)=(b,s,i64)   n=x+y ∈ Val(i64)
────────────────────────────────────────────────────── ADD
add(x,y) at s ⇒ result:i64

Γ(x)=(a,s,i64)   Γ(y)=(b,s,i64)   n=x×y ∈ Val(i64)
────────────────────────────────────────────────────── MUL
mul(x,y) at s ⇒ result:i64

Γ(x)=(a,s,τ)     Γ(y)=(b,s,τ)
────────────────────────────────────────────────────── ASSERT-TYPE
assert_eq(x,y) at s ⇒ no named result, source type unit
```

**LCUF-TYPE-006.** Arithmetic is evaluated using host integers and then checked against i64 bounds. Overflow rejects compile-time admission, rather than wrapping, saturating or silently widening the result. No division, float rounding, tensor arithmetic or JA-specific operator semantics is implied. A valid program therefore contains only arithmetic results within the declared range. A false constant assertion also rejects admission, but that is an execution-value rule rather than a type mismatch.

Repeated operands preserve arity: `add left,left` has two arguments and one producer dependency. In the worked program, changing that input cell and `expected` to `40` admits a deterministic result of `40` without introducing a second writer.

<a id="LCUF-CAP-001"></a>
## 2.6 Exact effect and row-capability contracts

**LCUF-CAP-001.** Let `Eop` and `Cop` be the required sets:

| Operation group | `Eop` | `Cop` at row site |
|---|---|---|
| `const`, `add`, `mul`, `assert_eq` | `∅` | `∅` |
| `copy` | `{fabric.transfer}` | `{fabric.receive}` |
| `emit` | `{evidence.emit}` | `{evidence.write}` |

Admission requires `set(row.effects)=Eop` and `set(row.caps)=Cop`, not merely that the required items are included. An extra capability in a pure row is invalid even if its site grants that capability. A copy cannot claim empty effects. Because duplicate items already reject during parsing, the set equality loses no permitted multiplicity.

There is no automatic effect inference visible in source: the author must supply the exact required sets, and the compiler checks them. The compiler does not execute arbitrary effect handlers. This is a deliberately closed effect system over six operations, not an open algebra of effects.

<a id="LCUF-CAP-002"></a><a id="LCUF-CAP-003"></a><a id="LCUF-CAP-004"></a>
## 2.7 Grant and transfer judgments

**LCUF-CAP-002.** Required row capabilities must be a subset of `G(site(r))`. Destination copy requires `fabric.receive`; emit requires `evidence.write`. Grants may contain other well-formed names, including currently unused names; those do not create new executable operations.

**LCUF-CAP-003 / LCUF-CAP-004.** A copy additionally requires its producer to reside at a different declared site, a directed link from producer site to row site, and `fabric.send` in the producer site's grant. The sender grant is checked against the producer site; it is not added to the copy row's exact capability cell.

```text
Γ(x)=(a,s,τ)    t≠s    (s,t)∈L
fabric.send∈G(s)       fabric.receive∈G(t)
effects(r)={fabric.transfer}    caps(r)={fabric.receive}
output(r)=y≠"-"         type(r)=τ
───────────────────────────────────────────────────────── COPY
S;G;L;Γ ⊢ copy(x) at t ⇒ y:τ
```

Every cross-site value read must satisfy this copy judgment. A non-copy row consuming a remote output rejects; a copy consuming a same-site output also rejects. Thus a local scalar or terminal operation never gains remote access merely by naming a value. Cross-site `after` dependencies have a separate prohibition; a local copy row provides the appropriate local ordering anchor.

This judgment checks a declarative route and named grants. It does not allocate a network queue, authenticate a sender, negotiate a protocol, consume a linear capability, or verify an external authority. Copy preserves the source binding and produces another retained output binding at the destination; it is not a move or borrow.

<a id="LCUF-CAP-005"></a><a id="LCUF-CAP-006"></a>
## 2.8 Trust labels and receipt instrumentation

**LCUF-CAP-005.** A trust label is an identifier in `S(s).trust`, retained in IR and semantic identity. Neither equality nor difference of two trust labels imposes an additional current admission restriction. Trust labels are not credentials and capability grants are not signatures.

**LCUF-CAP-006.** Any admitted row may request `evidence=receipt`. This optional simulator instrumentation does not require `evidence.write` for a pure row or for copy beyond its own transfer contract. The explicit `emit` operation does require `evidence.write` and must request a receipt. This distinction is intentional in the baseline specification: a per-row local observation is not an external evidence-I/O authority. Source `evidence=none` is valid for all operations except `emit`.

## 2.9 Worked static derivation

For row `d`, `Γ(total)=(c,edge,i64)`, `site(d)=cloud`, `L` contains `(edge,cloud)`, `fabric.send∈G(edge)`, and `fabric.receive∈G(cloud)`. Its profile is exactly `lcuf.fabric`, arity is one, effects/caps are exactly the required singleton sets, output is `received`, and declared type is `i64`. The copy judgment derives `Γ(received)=(d,cloud,i64)`.

For row `f`, both `received` and `expected` have type i64 and reside at cloud. It has profile `lcuf.test`, two arguments, source type `unit`, output `-`, and empty effects/caps. Static typing succeeds. Compile-time evaluation then establishes the stronger value obligation `42=42`. For row `g`, `received` is a local input, `evidence.write∈G(cloud)`, and the exact emit contract plus `evidence=receipt` succeeds. No rule derives a physical or authenticated execution claim from these premises.
