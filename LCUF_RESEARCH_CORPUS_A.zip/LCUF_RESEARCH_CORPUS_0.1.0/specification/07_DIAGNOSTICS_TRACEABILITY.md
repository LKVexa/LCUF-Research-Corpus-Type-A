# Volume 07 — Diagnostics and traceability

## 7.1 Diagnostic authority and code status

The reference [`fail`](../runtime/lcuf.py) raises `Diagnostic`, a `ValueError` subclass, with an optional `line N: ` prefix. The runtime emits human-readable messages, not the research taxonomy IDs below. `LCUF-DIAG-*` IDs identify pinned source call sites for corpus labeling and traceability; they must not be presented as implemented wire error codes. [`DIAGNOSTICS.json`](DIAGNOSTICS.json) preserves each message expression, display template, function, exact source line and requirement mapping.

For parser/row checks, physical LF line numbers survive logical-record preprocessing. Global header/completeness, declaration-reference, cycle and final resource checks generally omit a line. Repeated checks can share a message template but remain distinct call sites. Templates containing angle-bracket placeholders stand for dynamic values, not literal text emitted by the runtime.

## 7.2 Rejection phases and precedence

Compilation proceeds through byte decoding, logical record parsing, global declaration-reference checks, source-order row contract/index construction, source-order operand/dependency resolution, one-at-a-time graph scheduling, site reservation checks, graph-order constant evaluation and final retained-payload checks. A failing earlier phase prevents later diagnostics from occurring. Within source-order phases, the first invalid row/field is observed; within per-site checks, dictionary insertion order can select the first exceeded site. Canonical IR is returned only after all these phases succeed.

Consequently a source with both a denied capability and a cycle ordinarily reports the capability failure. A source exceeding step reservation and containing a false assertion reports the step failure before value evaluation. A malformed site resource digit can fail the declaration regex before the positive-number helper. These are phase distinctions, not conflicting rules. Dataset records should store an exact observed message alongside the intended violated requirement and avoid assuming a universal diagnostic priority independent of source shape.

The CLI catches `Diagnostic`, `OSError` and `UnicodeError`, writes a JSON object with `status=rejected` and its message to stderr, and returns exit code 2. Filesystem and encoding error strings can be host-specific and do not have fixed entries in the explicit-fail table. Unexpected exceptions from malformed externally supplied Python IR are outside the trusted direct-IR contract. The CLI does not load such IR; all of its commands compile source first.

## 7.3 Exact explicit-fail taxonomy

Each row below cites one explicit `fail` call site. Shared helpers may be invoked from more than one phase; the table gives their own defining function. Machine-readable function ranges and source digest are in `RULES.json`.

| Taxonomy ID | Function:line | Message template | Requirements |
|---|---|---|---|
| LCUF-DIAG-001 | `identity:26` | `invalid identifier <value>` | LCUF-LEX-004 |
| LCUF-DIAG-002 | `positive_integer:31` | `resource integer must be ASCII and within signed 64 bit positive bounds` | LCUF-RES-001 |
| LCUF-DIAG-003 | `positive_integer:33` | `resource integer exceeds signed 64 bit bounds` | LCUF-RES-001 |
| LCUF-DIAG-004 | `names:39` | `duplicate list item` | LCUF-LEX-006 |
| LCUF-DIAG-005 | `parse:44` | `required header LCUF/0.1` | LCUF-LEX-001 |
| LCUF-DIAG-006 | `parse:47` | `content after end` | LCUF-LEX-009 |
| LCUF-DIAG-007 | `parse:49` | `module must be the first declaration` | LCUF-LEX-002 |
| LCUF-DIAG-008 | `parse:52` | `duplicate module` | LCUF-LEX-002 |
| LCUF-DIAG-009 | `parse:54` | `module requires one identifier` | LCUF-LEX-002 |
| LCUF-DIAG-010 | `parse:58` | `site requires trust, memory and steps in that order` | LCUF-LEX-003 |
| LCUF-DIAG-011 | `parse:60` | `duplicate site` | LCUF-LEX-003 |
| LCUF-DIAG-012 | `parse:64` | `invalid grant` | LCUF-LEX-003 |
| LCUF-DIAG-013 | `parse:66` | `duplicate grant` | LCUF-LEX-003 |
| LCUF-DIAG-014 | `parse:70` | `invalid link` | LCUF-LEX-003 |
| LCUF-DIAG-015 | `parse:72` | `links require distinct sites and transfer=copy` | LCUF-LEX-003, LCUF-CAP-004 |
| LCUF-DIAG-016 | `parse:73` | `duplicate link` | LCUF-LEX-003 |
| LCUF-DIAG-017 | `parse:76` | `unknown declaration or invalid column header` | LCUF-LEX-003, LCUF-LEX-005 |
| LCUF-DIAG-018 | `parse:79` | `expected 12 cells, got <len(cells)>` | LCUF-LEX-005 |
| LCUF-DIAG-019 | `parse:82` | `unsupported operation <row['op']>` | LCUF-TYPE-002 |
| LCUF-DIAG-020 | `parse:83` | `unsupported type` | LCUF-TYPE-001 |
| LCUF-DIAG-021 | `parse:87` | `evidence must be none or receipt` | LCUF-LEX-005, LCUF-SEM-005 |
| LCUF-DIAG-022 | `parse:89` | `const requires a JSON scalar literal` | LCUF-LEX-007 |
| LCUF-DIAG-023 | `parse:90` | `nonfinite literal` | LCUF-LEX-007 |
| LCUF-DIAG-024 | `parse:92` | `const requires a bounded JSON scalar literal` | LCUF-LEX-007 |
| LCUF-DIAG-025 | `parse:96` | `missing end` | LCUF-LEX-009 |
| LCUF-DIAG-026 | `parse:97` | `module, sites, columns and rows are required` | LCUF-LEX-002, LCUF-LEX-003, LCUF-LEX-005, LCUF-LEX-009 |
| LCUF-DIAG-027 | `check_value:103` | `value violates type or i64 bounds` | LCUF-TYPE-001, LCUF-TYPE-006 |
| LCUF-DIAG-028 | `check_value:106` | `text contains an unpaired Unicode surrogate` | LCUF-LEX-008, LCUF-TYPE-001 |
| LCUF-DIAG-029 | `compile_source:112` | `source is not UTF 8` | LCUF-LEX-008 |
| LCUF-DIAG-030 | `compile_source:114` | `grant names an unknown site` | LCUF-LEX-003, LCUF-CAP-002 |
| LCUF-DIAG-031 | `compile_source:115` | `link names an unknown site` | LCUF-LEX-003, LCUF-CAP-004 |
| LCUF-DIAG-032 | `compile_source:119` | `duplicate row id` | LCUF-GRAPH-001 |
| LCUF-DIAG-033 | `compile_source:121` | `unknown site` | LCUF-LEX-003 |
| LCUF-DIAG-034 | `compile_source:122` | `operation does not belong to profile` | LCUF-TYPE-002 |
| LCUF-DIAG-035 | `compile_source:123` | `wrong operation arity` | LCUF-TYPE-003 |
| LCUF-DIAG-036 | `compile_source:125` | `multiple writers to one output` | LCUF-GRAPH-001 |
| LCUF-DIAG-037 | `compile_source:128` | `terminal operation requires unit and output -` | LCUF-TYPE-004 |
| LCUF-DIAG-038 | `compile_source:129` | `value operation requires typed output` | LCUF-TYPE-004 |
| LCUF-DIAG-039 | `compile_source:130` | `arithmetic requires i64` | LCUF-TYPE-005 |
| LCUF-DIAG-040 | `compile_source:134` | `effects and capabilities must match the operation contract` | LCUF-CAP-001 |
| LCUF-DIAG-041 | `compile_source:135` | `capability denied by site grant` | LCUF-CAP-002 |
| LCUF-DIAG-042 | `compile_source:136` | `emit requires receipt` | LCUF-SEM-004, LCUF-CAP-002 |
| LCUF-DIAG-043 | `compile_source:142` | `undefined input <inp>` | LCUF-GRAPH-002 |
| LCUF-DIAG-044 | `compile_source:145` | `cross-site input requires explicit copy row` | LCUF-CAP-004, LCUF-SEM-002 |
| LCUF-DIAG-045 | `compile_source:146` | `no directed federation link` | LCUF-CAP-004 |
| LCUF-DIAG-046 | `compile_source:147` | `sender lacks fabric.send grant` | LCUF-CAP-003 |
| LCUF-DIAG-047 | `compile_source:148` | `copy requires a different source site` | LCUF-CAP-004, LCUF-SEM-002 |
| LCUF-DIAG-048 | `compile_source:149` | `input type mismatch` | LCUF-TYPE-005 |
| LCUF-DIAG-049 | `compile_source:150` | `assert operands have different types` | LCUF-TYPE-005 |
| LCUF-DIAG-050 | `compile_source:151` | `undefined dependency` | LCUF-GRAPH-002 |
| LCUF-DIAG-051 | `compile_source:152` | `cross-site after requires a local copy dependency` | LCUF-GRAPH-003 |
| LCUF-DIAG-052 | `compile_source:156` | `dependency cycle` | LCUF-GRAPH-004 |
| LCUF-DIAG-053 | `compile_source:159` | `step admission exceeded at <site>` | LCUF-RES-002 |
| LCUF-DIAG-054 | `compile_source:170` | `constant assertion fails` | LCUF-SEM-003 |
| LCUF-DIAG-055 | `compile_source:176` | `memory admission exceeded at <site>` | LCUF-RES-003 |
| LCUF-DIAG-056 | `simulate:188` | `IR hash mismatch` | LCUF-ID-007, LCUF-SEM-008 |
| LCUF-DIAG-057 | `simulate:197` | `assertion failed` | LCUF-SEM-003 |
| LCUF-DIAG-058 | `simulate:200` | `unknown operation in IR` | LCUF-SEM-008, LCUF-TYPE-002 |

## 7.4 Requirement-to-implementation matrix

The first 37 requirement IDs preserve the collection-wide conformance dataset mapping. Eleven additional rules document preprocessing, trust/instrumentation, resource exclusions, version/normalization and the direct-IR precondition. An empty focused-check entry means this formal work did not execute a dedicated probe for that requirement; it does not imply the requirement was omitted from source inspection or the separate collection-wide suite.

| Requirement | Specification | Implementation functions | Focused observations |
|---|---|---|---|
| LCUF-LEX-001 | [Required header](01_LEXICAL_GRAMMAR.md#LCUF-LEX-001) | `parse` | No dedicated formal probe |
| LCUF-LEX-002 | [Module first](01_LEXICAL_GRAMMAR.md#LCUF-LEX-002) | `parse`, `identity` | No dedicated formal probe |
| LCUF-LEX-003 | [Declarations and uniqueness](01_LEXICAL_GRAMMAR.md#LCUF-LEX-003) | `parse`, `compile_source` | REF-028 |
| LCUF-LEX-004 | [ASCII identifiers](01_LEXICAL_GRAMMAR.md#LCUF-LEX-004) | `identity`, `parse` | No dedicated formal probe |
| LCUF-LEX-005 | [Twelve columns](01_LEXICAL_GRAMMAR.md#LCUF-LEX-005) | `parse` | No dedicated formal probe |
| LCUF-LEX-006 | [Comma lists](01_LEXICAL_GRAMMAR.md#LCUF-LEX-006) | `names`, `parse` | REF-030 |
| LCUF-LEX-007 | [Scalar JSON](01_LEXICAL_GRAMMAR.md#LCUF-LEX-007) | `parse`, `check_value` | REF-014, REF-017, REF-019 |
| LCUF-LEX-008 | [UTF8 and Unicode](01_LEXICAL_GRAMMAR.md#LCUF-LEX-008) | `compile_source`, `check_value` | REF-008, REF-018 |
| LCUF-LEX-009 | [End state](01_LEXICAL_GRAMMAR.md#LCUF-LEX-009) | `parse` | No dedicated formal probe |
| LCUF-LEX-010 | [Logical-record preprocessing](01_LEXICAL_GRAMMAR.md#LCUF-LEX-010) | `parse` | REF-027 |
| LCUF-LEX-011 | [Byte/string BOM distinction](01_LEXICAL_GRAMMAR.md#LCUF-LEX-011) | `compile_source`, `parse` | REF-026 |
| LCUF-TYPE-001 | [Scalar domains](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-TYPE-001) | `check_value`, `compile_source` | REF-015 |
| LCUF-TYPE-002 | [Profile ownership](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-TYPE-002) | `parse`, `compile_source` | No dedicated formal probe |
| LCUF-TYPE-003 | [Arity](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-TYPE-003) | `compile_source` | No dedicated formal probe |
| LCUF-TYPE-004 | [Output shape](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-TYPE-004) | `compile_source` | REF-014 |
| LCUF-TYPE-005 | [Operand type matching](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-TYPE-005) | `compile_source` | REF-030 |
| LCUF-TYPE-006 | [I64 overflow](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-TYPE-006) | `check_value`, `compile_source`, `simulate` | REF-016 |
| LCUF-CAP-001 | [Exact operation contracts](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-CAP-001) | `compile_source` | REF-022 |
| LCUF-CAP-002 | [Receiver and emit grants](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-CAP-002) | `compile_source` | No dedicated formal probe |
| LCUF-CAP-003 | [Sender grant](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-CAP-003) | `compile_source` | REF-023 |
| LCUF-CAP-004 | [Directed copy link](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-CAP-004) | `compile_source` | No dedicated formal probe |
| LCUF-CAP-005 | [Trust labels are declarations](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-CAP-005) | `parse`, `compile_source`, `target_plan` | No dedicated formal probe |
| LCUF-CAP-006 | [Optional instrumentation](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md#LCUF-CAP-006) | `compile_source`, `simulate` | REF-022 |
| LCUF-GRAPH-001 | [Unique row IDs and writers](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-GRAPH-001) | `compile_source` | No dedicated formal probe |
| LCUF-GRAPH-002 | [Defined references](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-GRAPH-002) | `compile_source` | No dedicated formal probe |
| LCUF-GRAPH-003 | [Same-site after](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-GRAPH-003) | `compile_source` | REF-024 |
| LCUF-GRAPH-004 | [Acyclicity](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-GRAPH-004) | `compile_source` | No dedicated formal probe |
| LCUF-GRAPH-005 | [One-at-a-time lex scheduling](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-GRAPH-005) | `compile_source` | REF-001, REF-010 |
| LCUF-RES-001 | [Positive ASCII i64 resources](04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md#LCUF-RES-001) | `positive_integer`, `parse` | No dedicated formal probe |
| LCUF-RES-002 | [Step sum](04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md#LCUF-RES-002) | `compile_source` | REF-002 |
| LCUF-RES-003 | [Retained output payload](04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md#LCUF-RES-003) | `compile_source` | REF-002, REF-020, REF-021 |
| LCUF-RES-004 | [Reservation is not fuel](04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md#LCUF-RES-004) | `compile_source` | No dedicated formal probe |
| LCUF-RES-005 | [Resource scope exclusions](04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md#LCUF-RES-005) | `compile_source` | No dedicated formal probe |
| LCUF-ID-001 | [Canonical complete content](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-001) | `canonical`, `hash_value`, `compile_source` | REF-010 |
| LCUF-ID-002 | [Raw source bytes](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-002) | `compile_source` | REF-008, REF-009 |
| LCUF-ID-003 | [Formatting invariance](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-003) | `parse`, `compile_source` | REF-007 |
| LCUF-ID-004 | [Policy sensitivity](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-004) | `compile_source`, `hash_value` | REF-011 |
| LCUF-ID-005 | [Normalization limits](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-005) | `compile_source` | REF-012, REF-013 |
| LCUF-ID-006 | [Version binding](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-006) | `compile_source` | No dedicated formal probe |
| LCUF-ID-007 | [Hash is not authenticity](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-ID-007) | `simulate`, `hash_value` | REF-025 |
| LCUF-SEM-001 | [Scalar results](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-SEM-001) | `compile_source`, `simulate` | REF-003 |
| LCUF-SEM-002 | [Explicit copy](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-SEM-002) | `compile_source`, `simulate` | REF-003 |
| LCUF-SEM-003 | [Assert equality](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-SEM-003) | `compile_source`, `simulate` | REF-005 |
| LCUF-SEM-004 | [Emit](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-SEM-004) | `compile_source`, `simulate` | REF-005 |
| LCUF-SEM-005 | [Receipt chain](05_CANONICAL_IDENTITY_RECEIPTS.md#LCUF-SEM-005) | `simulate`, `canonical`, `hash_value` | REF-004, REF-006 |
| LCUF-SEM-006 | [Nonbooting plan](08_GLOSSARY_EXTENSION_CONTRACTS.md#LCUF-SEM-006) | `target_plan`, `simulate` | REF-029 |
| LCUF-SEM-007 | [Compile-time evaluation](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-SEM-007) | `compile_source`, `main` | No dedicated formal probe |
| LCUF-SEM-008 | [Trusted direct-IR precondition](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md#LCUF-SEM-008) | `simulate`, `main` | REF-025 |

## 7.5 Evidence sufficiency and open coverage

`REFERENCE_CHECKS.json` records thirty executed observations, including the full worked-example store/schedule/reservations/payload, four-receipt recurrence, formatting/source-byte distinctions, policy sensitivity, Unicode bytes, null rejection, exact transfer denial, repeated operands, plan scope and a recomputed-direct-IR counterexample. These observations are deliberately finite. They do not cover every parser mutation, every numeral or text length, every graph, every hash attack, or future backend failure.

The twelve propositions in volume 06 are proof sketches under stated assumptions. Their evidence should be cited as a derivation plus the relevant finite observations, never as a theorem-prover certificate. The larger research corpus can add conformance records keyed by these stable rule IDs without changing this claim boundary. A new runtime byte identity requires re-extracting call sites, rerunning focused observations and reviewing the formal assumptions.

## 7.6 Diagnostic labeling examples

`const null` with `type=unit` parses its JSON literal but rejects `value operation requires typed output`, so the principal observed rule is LCUF-TYPE-004 rather than malformed JSON. A raw pipe inside a text literal rejects the twelve-cell count, not Unicode validity. `copy` with a missing sender grant reaches LCUF-CAP-003 only after exact receiver/effect contracts and known links have passed. `assert_eq` between an i64 and bool producer rejects LCUF-TYPE-005 before equality is evaluated. A caller modifying IR and leaving its digest unchanged observes LCUF-ID-007; recomputing that digest removes the consistency mismatch but does not establish the LCUF-SEM-008 precondition.

These examples distinguish syntax, type, authority, graph, value and integrity classes. Research datasets should retain that distinction rather than using a single undifferentiated rejected label.
