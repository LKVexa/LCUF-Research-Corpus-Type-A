# JA 8S Penteract–S³ Coupled Mechanics Profile 0.1

The user's supplied **8S Penteract–S³ Master Coupled Mechanics Law** is the declared arithmetic foundation for JA. This profile preserves that foundation and begins an executable reference implementation. It evaluates specified equations on the host; it does not build a native unikernel, communicate between sites, fit the models, establish a physical theorem, or confer execution authority.

Profile owner: `ja.coupling8s`. Reference schema: `coupling8s.reference.0.1`. Coordinate convention `center-indices-4-to-8/v1` maps the five array components to coordinate labels **4, 5, 6, 7, 8**, in that order. In particular, the figure's boundary product runs from **a=4 to a=8**; it has five factors.

## Transcription of the supplied law

The supplied figure states:

\[
C_5=[C_4\mid e],\qquad
\eta_{\rm ind}=\frac{\|(I-C_4C_4^+)e\|_2^2}{\|e\|_2^2+\varepsilon}\ge\varepsilon_{\rm ind}.
\]

\[
c_i=\ell n_i,\quad n_i\in\mathbb Z^5,\quad
\|n_i\|_1\le M,\quad c_i\in[-1,1]^5,\qquad
q(\tau)=\sin^2\left(\frac{\pi\tau}{T}\right).
\]

\[
W_{ij}=A_{ij}\exp\left[-\frac{(c_i-c_j)^TG_5(c_i-c_j)}{2\sigma_c^2}
-\frac{d_J(i,j)^2}{2\sigma_J^2}\right].
\]

\[
\dot\theta_i=\omega_i+K_2\sum_jW_{ij}\sin(\theta_j-\theta_i)
+K_3\sum_{j,k}H_{ijk}\sin(\theta_j+\theta_k-2\theta_i).
\]

\[
\begin{aligned}
h_i={}&\beta\left(Mq+\tfrac12-d_i\right)+a_EE_i+a_uu_i-a_\chi\chi_i-a_\zeta\zeta_i\\
&+J_2\sum_jW_{ij}(2p_j-1)
+J_3\sum_{j,k}H_{ijk}(2p_j-1)(2p_k-1),\\
p_i={}&\sigma(h_i)=\frac{1}{1+e^{-h_i}},\\
B_5(c_i)={}&\prod_{a=4}^{8}b(c_{i,a}),\\
s_i={}&p_i\kappa_i(1-\chi_i)(1-\zeta_i)v(\omega_i),\\
r_i={}&r_{\max}B_5(c_i)^\alpha s_i^{1/3}.
\end{aligned}
\]

\[
F_i=S^3_{r_i}=\{y\in\mathbb R^4:\|y\|_2=r_i\},\qquad
X_8(\tau)=\{(c,y)\in[-1,1]^5\times\mathbb R^4:\|y\|_2=R(c,\tau)\}.
\]

\[
z_i(u)=\begin{bmatrix}c_i\\r_iu\end{bmatrix},\quad u\in S^3,\qquad
x_i^{(3)}=[\Pi_5(\tau)\ \Psi_4(\tau)]z_i(u).
\]

\[
\begin{aligned}
g_{ij}^{(5)}&=\sqrt{(c_i-c_j)^TG_5(c_i-c_j)}-(\lambda_i+\lambda_j),\\
\delta_{ij}^{(8)}&=\sqrt{(c_i-c_j)^TG_5(c_i-c_j)+(r_i-r_j)^2},\\
g_{ij}^{(3)}&=\|\Pi_5c_i-\Pi_5c_j\|_2-(\widehat r_i+\widehat r_j),\\
g_{ij}^{(J)}&=d_J(\mathfrak J_i,\mathfrak J_j)-\theta_J.
\end{aligned}
\]

\[
\mathcal R_{ij}^{8S}=\operatorname{Classify}
\left(g_{ij}^{(5)},\delta_{ij}^{(8)},g_{ij}^{(3)},g_{ij}^{(J)},\mathcal K_{ij},\Sigma_{ij}\right),
\qquad \Delta_{8S}=\operatorname{Score}(\mathcal M_8)-\operatorname{Score}(\mathcal M_7).
\]

\[
\boxed{\operatorname{Admit}(8S)\iff
\eta_{\rm ind}\ge\varepsilon_{\rm ind}\ \land\ \Delta_{8S}>\varepsilon_{\rm gain}.}
\]

The first admission comparison is inclusive; the efficacy comparison is strictly greater. The displayed `q` has no additional phase offset. Phase coupling is specified separately through the equation for `theta_dot`.

## Definitions and evidence still required

The equation supplies structure rather than concrete datasets and parameter values. An evaluation must identify its inputs and provenance:

| Object | Required definition or evidence |
|---|---|
| C4, e and C4⁺ | Compatible data coordinates, the Moore–Penrose convention, and evidence that the supplied orthogonal projector is C4 C4⁺ |
| Fifth coordinate | Its declared interpretation and a shared dataset for comparing M8 against M7 |
| ell, n, M | Lattice spacing, five integer coordinates, L1 bound and cube admission |
| tau, T, theta, omega | Consistent time units, T>0, radians for phases and frequency units |
| G5 | Finite symmetric positive semidefinite geometry matrix; a singular G5 defines a pseudometric rather than a strict metric |
| A, W, H | Explicit sparse ordered interactions, weights, support, direction and provenance; no implicit triads or symmetrization |
| K2, K3, J2, J3 and activation inputs | Explicit coefficients and meanings of d, E, activation u, chi and zeta; activation u is separate from the unit fiber direction u |
| b(c), B5 and v(omega) | Explicit boundary/velocity functions or supplied evaluated values; this reference does not invent either function |
| kappa, rmax, alpha | Declared support factors and radius parameters; reference domain requires kappa and velocity nonnegative, chi/zeta in [0,1], and alpha>0 |
| R(c,tau) | A continuous-field/interpolation definition if the total space X8 is to be constructed from sampled radii |
| Pi5, Psi4 and apparent radii | 3×5 and 3×4 projection matrices, coordinate frame/version, and a separately defined apparent-radius rule |
| lambda and dJ | Latent exclusion radii and a versioned judgment metric; lambda, physical fiber radius and apparent radius are distinct inputs |
| Classify, Kij and Sigmaij | A separately versioned classification policy, threshold/uncertainty meaning and decision order |
| Score and efficacy | Common data, fitting/evaluation procedure, held-out scores, cost/energy treatment and uncertainty |

The source corpora contain editorial classification examples, including `PROJECTION_ONLY`, and older four-dimensional annotations. They remain provenance-bearing source material. They do not by themselves define the displayed six-argument `Classify` function or its tolerance precedence. `geometry_gaps` therefore returns all four measurements independently and leaves classification null.

## Implemented host arithmetic

[reference.py](reference.py) implements stable sigmoid; periodic q; lattice admission; independence from an explicit checked orthogonal projector; symmetric-PSD weighted geometry; W; deterministic sparse pair/ordered-triad phase and activation sums; effective support; the five-factor supplied boundary product; radius; the R9 fiber embedding; 3D projection; the four gap descriptors; and the two-part admission gate. [reference_input.schema.json](reference_input.schema.json) maps typed input records to the profile. [tests/test_reference.py](tests/test_reference.py) checks numerical examples, bounds, malformed inputs, projector/metric matrices, admission equality and noncollapsed dimension.

All scalars must be finite real numbers; booleans are rejected as numeric inputs. The schema describes JSON shape, while the evaluator independently rejects nonfinite values and incompatible dimensions. The default host numerical comparison tolerance is 1e-9 and can be supplied explicitly. It is separate from the model's denominator epsilon, admission epsilon_ind, epsilon_gain and any future relation-class tolerances. Sparse terms are sorted by their declared indices and duplicate ordered terms are rejected; no undeclared graph structure is filled in.

The independence evaluator checks symmetry and idempotence of the supplied projector. If a typed admission record supplies C4, it also checks the projector against a two-pass modified Gram–Schmidt column-space construction using the declared absolute tolerance, and rejects inconsistent projectors. This is a numerical rank/projection check, not a symbolic Moore–Penrose or conditioning proof. If C4 is omitted, its relationship to the supplied projector remains required caller evidence and the result says so. A numerical `admitted_model_dimension=true` means only that the two displayed numerical inequalities pass for the supplied scores/projector. It does not establish model fitting, held-out independence, production execution, or the empirical correctness of the supplied values.

## Mathematical and execution claim limits

For positive radius, each individual fiber is a 3-sphere embedded in R4. A regular local product chart with five base coordinates and a noncollapsed 3-sphere fiber has dimension 5+3=8. The displayed embedding has nine ambient coordinates. These statements do not prove that X8 is globally the standard sphere S8. At radius zero, the fiber collapses; this reference returns no total-space dimension claim at that point. Cube boundaries, collapse loci and the regularity of R require their own analysis.

The displayed delta8 depends on center and radius differences, and omits fiber directions; the evaluator preserves that descriptor without claiming it is a full geodesic or distance between arbitrary oriented fiber points. Apparent projection overlap and latent/judgment relations remain separate.

This host evaluator is a working arithmetic reference for the user's JA foundation. Native code generation, numerical backend certification, real model evaluation, physical interpretation, profile compiler integration, authenticated transport and independent execution evidence remain separate gates. Conventional JA Count examples retain ordinary discrete-count semantics; they are distinct from an 8S model evaluation.
