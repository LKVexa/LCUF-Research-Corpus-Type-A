# Proposed typed LCUF ↔ JA coupling8s adapter contract

Contract draft `lcuf.ja.coupling8s.adapter-draft.0.1`. **The LCUF adapter is not implemented.** The delivered callable implementation is the separate Python host wrapper `lcuf.math.research-policy.0.1` around the byte-exact frozen arithmetic reference. Neither the wrapper nor this document adds an operation to frozen LCUF0.1. A row using `profile=ja.coupling8s` or an invented `op=coupling_admit` is not supported by that core.

## Ownership and version binding

JA owns the declared 8S arithmetic foundation and its intended operators. LCUF owns site, effect, capability, dependency, resource and receipt contracts. A future adapter must bind both owners instead of treating a mathematical gate result as an execution grant.

The import artifact should identify arithmetic profile/version, adapter version, coordinate convention, arithmetic-image digest, input-schema digest, reference or solver digest, numerical policy and target backend. Profile ownership must be a checked identity rather than a free-form runtime string. Unsupported versions, missing definitions, mismatched array coordinate labels and unrecognized fields reject import before computation.

The existing frozen admission JSON schema is a useful narrow input boundary. Its root invokes admission only; its geometry/phase/radius `$defs` do not silently run those operations. A future compiler must use explicit typed operation contracts for each computation. Importing an admission record cannot trigger an ODE solver, lattice expansion, classifier or device operation.

## Proposed value types

These are draft types requiring a future typed frontend and lowering. They are not scalar types already accepted by LCUF0.1.

| Draft type | Shape and checked meaning | Required metadata |
|---|---|---|
| `FiniteReal(policy)` | finite real scalar with declared representation | f64/decimal/interval identity, overflow and underflow policy |
| `Probability` | finite value in[0,1] | distinction between exact model value and rounded host endpoint |
| `Center5(frame,4..8)` | five coordinates inside normalized cube | stable coordinate order, frame, units and normalization version |
| `Lattice5` | five nonboolean integers | common nonnegative integer M, ell and cube/L1 admission |
| `VectorN(N)` | finite N-vector | row identities, data digest, units and layout |
| `C4(N)` | finite N×4 matrix | four feature definitions, data/normalization digest |
| `ProjectorN(N,C4-id)` | finite N×N orthogonal projector within declared tolerance | construction/cutoff, relationship to the identified C4, conditioning qualification |
| `PSD5(frame)` | finite symmetric PSD matrix under declared numerical policy | strict metric vs pseudometric status, scale and nullspace qualification |
| `SparsePairs(N,i)` | explicit ordered `(j,W)` records with bounded integer index | no duplicates; direction and support authority |
| `SparseTriads(N,i)` | explicit ordered `(j,k,H)` records | no duplicate ordered pairs; no implicit symmetrization |
| `BoundaryValues5(4..8)` | exactly five evaluated nonnegative values | b definition/version or measurement provenance |
| `FiberDirection4` | finite unit four-vector within declared tolerance | chart/frame and normalization evidence |
| `Projection3x9` | declared Pi5 and Psi4 blocks | coordinate frame, time and calibration |
| `GapDescriptors` | g5/delta8/g3/gJ as separate finite fields | all radius/metric definitions; no implicit classification |
| `NumericAdmission` | supplied eta/Delta and exact inclusive/strict flags | projector authority, score provenance, no execution grant |

The typed compiler should resolve symbolic dimensions before lowering, carry checked units, reject bool-as-number coercion and distinguish external evaluated factors from built-in functions. It must not coerce old four-dimensional fields into the five-coordinate convention or infer physical units from a profile name.

## Proposed pure operation contracts

The following mapping is suitable for adapter design and conformance work. The Python names already exist in the host reference/wrapper; the LCUF operations remain unregistered.

| Draft operation | Host reference API | Result and semantic boundary |
|---|---|---|
| lattice center | `lattice_center` | five-coordinate center; L1 and cube admission both required |
| periodic drive | `q` | dimensionless sinusoid; no added phase offset |
| column-space projector | `projector_from_c4` | numerical projector/rank with explicit absolute cutoff |
| independence | `independence_score` | eta; association with C4 must be separately evidenced |
| latent quadratic | `quadratic_geometry` | nonnegative scalar or declared roundoff clamp; strict-metric claim separate |
| pair weight | `pair_weight` | supplied adjacency times distance attenuation |
| phase derivative | `phase_derivative` | instantaneous right-hand side; no integrated trajectory |
| activation field | `activation_field` | one field evaluation from supplied probabilities; no fixed-point solve |
| sigmoid | `sigmoid` | host numeric probability, including documented rounded endpoints |
| boundary/support/radius | the three corresponding APIs | explicit evaluated factors; no invented b/v function |
| fiber embedding | `fiber_point` | nine ambient coordinates; no atlas/topology claim |
| linear projection | `projected_point` | three-coordinate output with explicit matrices |
| gap descriptors | `geometry_gaps` | four independent descriptors; classifier remains null |
| admission | `admit` or `evaluate_admission_record` | numerical two-inequality gate only |

An immutable numerical evaluation can be modeled as pure with respect to the supplied values. Loading an artifact, allocating a solver workspace, publishing evidence or invoking a device are separate actions with their own effects and authority. The future effect system must not erase those actions merely because the underlying equation is pure.

## Proposed admission stages

1. **Identity and provenance:** bind supported JA/LCUF/adapter versions, source bytes, the supplied arithmetic image, schema, coordinate labels and backend digests.
2. **Typed domain checks:** validate ranks/shapes, bounded indices, explicit sparse support, finite scalars, units, lattice bounds and required external definitions.
3. **Numerical policy:** bind representation, meaningful tolerance, scaling/rank cutoff, overflow/underflow behavior and any condition-number or uncertainty policy.
4. **Arithmetic evaluation:** compute only explicitly declared operations. Do not introduce Classify, Score fitting, trajectory integration or interpolation as implicit side effects.
5. **Result checks:** require finite outputs, valid eta/geometry/radius domains, consistent gate flags and an exact host/native scope label.
6. **LCUF execution admission:** check site ownership, grants, exact effects, explicit transfer, dependencies and actual target resource enforcement separately.
7. **Evidence publication:** bind input/source/output digests, issuer/toolchain/environment and claim scope. Promote evidence only when the target execution was actually observed.

The delivered host wrapper implements only parts of stages2/3/4/5 for its18 callable functions. It enforces a research tolerance ceiling1e−6, checks signature and finite input/output trees, relies on the frozen function's domains, and validates final domains/shapes/gate flags. It does not prove input meaning or units, estimate conditioning, enforce a resource budget, issue a site capability or implement stages6/7 as LCUF semantics.

## Resource and determinism contract still required

Dimension N is an unbounded caller input in the frozen Python APIs. A dense projector requires N² stored entries and the current symmetry/idempotence verification uses cubic work. Python object overhead, parsing, copies, temporary lists and receipts add storage beyond raw numeric payloads. A future adapter must declare maximum dimensions, sparse term counts, allocator accounting, peak workspaces and solver cost before translating them into site memory/step reservations.

The existing scalar LCUF memory model cannot account for arbitrary matrix/vector values. A native adapter must implement a new resource model, not charge every matrix as a single eight-byte scalar. Dependency closure must bind the exact numerical library and target ABI. A metadata plan containing those names is not an admitted native image.

Ordered sparse reductions and deterministic source grids make local host evaluation reproducible within the recorded implementation and tolerances. They do not establish bitwise identity across CPU/GPU/NPU libraries, transcendental implementations, SIMD reductions or federated schedules. Native conformance needs precision-specific reference cases, denial behavior, target observations and declared reconciliation for non-bitwise numerical agreement.

## Score and classification contracts remain separate

`Score` should be imported as an evaluated observation with a versioned estimator and experimental protocol, or produced by an explicitly owned evaluator. A future empirical record should bind common cohort/splits, data leakage controls, fitting budget, model versions, metrics, uncertainty and any cost/energy treatment. The supplied image states a Score difference; this proposed evidence contract does not retroactively label existing illustrative scores as held-out measurements.

`Classify` requires the meaning of Kij/Sigmaij, comparison tolerances, branch order, tie handling, unknown/uncertain outcomes and positive/negative examples. No default precedence is supplied by this draft. Until that contract exists, a typed gap output preserves separate measurements and null classification. Numeric gate success cannot authorize fabricated relation labels.

## Evidence tiers and compatibility

The research dataset distinguishes an independent analytical expectation, a frozen host observation, a stricter research-wrapper observation and a premise qualification. `accepted_conditional_host_policy` is a numerical research status. It is not `NativelyExecuted`, `RemotelyAttested`, an empirical model acceptance or a physical theorem.

A future adapter must add its own independently versioned conformance suite while preserving this frozen reference and its observed limitations. Changes to the tolerance ceiling, rank algorithm, PSD roundoff policy, units, sparse symmetry, Score protocol or classifier alter the adapter's contract. They require new version identity, migration evidence and regenerated observations; they must not be hidden by retaining a former digest or reusing a historical success label.

No complete adapter is asserted by this document. The delivered concrete work is a reproducible research math corpus and host policy wrapper, suitable for building that adapter under explicit owner and execution boundaries.
