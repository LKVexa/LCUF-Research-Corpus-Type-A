# Preserved limits and separately applied research policy

No frozen file was patched. The exact reference source digest is `fb567f35dc54971e9b03525640a9269e08e47b5ec0be643caee143c6e1be9fbb`.

| ID | Reproducible observation | Research treatment | Remaining work |
|---|---|---|---|
| MATH-LIMIT-001 | `independence_score([1],[[4]],1,tolerance=20)` returns4.5 because the tolerance is unbounded | Separate wrapper denies tolerance above1e−6; final eta must be in[0,1] | Scale/conditioning policy and certified projector association |
| MATH-LIMIT-002 | G5=diag(−1e−10,1,1,1,1), center difference e1 and tolerance1e−9 yield0 after numerical allowance/clamp | Preserved as `declared_roundoff_allowance`; meaningful bounded tolerance required | Interval/eigenvalue bounds if exact PSD/strict metric authority is needed |
| MATH-LIMIT-003 | Absolute Gram–Schmidt rank cutoff changes the interpretation of very small coordinate columns | Rank-boundary cases retained, algorithm/cutoff disclosed | Relative scaling, condition estimates and solver conformance |
| MATH-LIMIT-004 | Scalar sigmoid observations at h=±1000 round/underflow to1/0 | Endpoint observations qualified as host numeric values | Downstream underflow/collapse policy |
| MATH-LIMIT-005 | Positive B/support can make r exceed a value named rmax | Domain preserved; no false maximum-radius invariant | Explicit normalization/cap contract if required by a model |
| MATH-LIMIT-006 | Standalone independence checks do not bind P to C4; typed record checks that association only when C4 is supplied | Projector authority retained in output | Checked data/feature provenance and stronger solver evidence |
| MATH-LIMIT-007 | Activation evaluates from supplied p; phase evaluates only a derivative | No fixed-point solver or time integrator claimed | Solver/integrator, initial state, convergence/error contracts |
| MATH-LIMIT-008 | Classify, b, v, R interpolation and Score fitting are unspecified | Explicit evaluated inputs; null classifier; supplied scores only | Independently versioned definitions and empirical evidence |
| MATH-LIMIT-009 | Nine-coordinate embedding and positive-radius local dimension8 do not imply global S8 topology | Conditional dimension and collapse-null contract | Global atlas, boundary/collapse and regularity analysis |
| MATH-LIMIT-010 | Host wrapper has no memory/time/dimension resource enforcement | Research scope explicit; no LCUF execution admission claimed | Typed vector/matrix backend and actual resource enforcement |

The tolerance ceiling is **research engineering policy**, not a constant transcribed from the author's law. Passing it is insufficient for an exact matrix, physical, empirical, native or federation claim.
