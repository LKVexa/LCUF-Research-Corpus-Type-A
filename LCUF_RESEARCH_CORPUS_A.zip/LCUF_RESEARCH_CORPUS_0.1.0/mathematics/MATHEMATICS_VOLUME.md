# Mathematics volume: JA 8S foundation and LCUF research boundary

Version `lcuf.math.volume.0.1`; arithmetic owner `ja.coupling8s`; coordinate convention `center-indices-4-to-8/v1`. This volume treats the author's supplied **8S Penteract–S³ Master Coupled Mechanics Law** as JA's declared arithmetic foundation. It preserves the supplied equations and distinguishes their structure, explicit reference domains, conditional mathematical deductions, host numerical policy and proposed language integration.

The authoritative visual for transcription is [the supplied PNG](frozen/coupling8s/ARITHMETIC_REFERENCE.png); [the supplied AVIF](frozen/coupling8s/ARITHMETIC_REFERENCE.avif) and the entire previously delivered profile are copied byte for byte. [PROVENANCE.json](PROVENANCE.json) binds all nine copied files. The frozen Python reference remains `coupling8s.reference.0.1`. The separate [research wrapper](tools/research_wrapper.py), version `lcuf.math.research-policy.0.1`, adds host admission policy; it changes neither the frozen implementation nor LCUF's scalar operation set.

## 1. Reading the law without silently completing it

The figure fixes five base coordinates and a three-dimensional sphere fiber. The boundary product explicitly uses coordinate labels **4, 5, 6, 7, 8**, five factors in total. Dense arrays in this corpus list those five labels in that order; their array offsets remain 0 through 4. This mapping is versioned because treating an index label as an array length would replace a five-dimensional base with an eight-dimensional one.

Several objects in the figure are functions, operators or measured scores with no concrete definition in the image. In particular, `b`, `v`, the judgment metric `dJ`, the continuous radius field `R`, the classifier and the fitting/evaluation procedure for `Score` are not completed by the reference. They require explicit definitions or supplied evaluated values. A successful numeric call cannot supply those missing meanings.

The law is not a statement that every stored corpus field has already been generated from these equations. Historical `d4`, `g4` and `TRUE_4D` annotations are provenance-bearing records requiring a versioned migration. This volume does not rename those fields, claim their equivalence to `g5`/`delta8`, or treat their modeled classifications as measured results. Conventional scalar Count fixtures and this coupled mathematical profile have separate operation contracts.

## 2. Exact transcription

### Independence and lattice coordinates

\[
C_5=[C_4\mid e],\qquad
\eta_{\mathrm{ind}}=
\frac{\|(I-C_4C_4^+)e\|_2^2}{\|e\|_2^2+\varepsilon}
\ge\varepsilon_{\mathrm{ind}}.
\]

\[
c_i=\ell n_i,\quad n_i\in\mathbb Z^5,\quad
\|n_i\|_1\le M,\quad c_i\in[-1,1]^5,\qquad
q(\tau)=\sin^2\left(\frac{\pi\tau}{T}\right).
\]

### Pair weights and phase dynamics

\[
W_{ij}=A_{ij}\exp\left[
-\frac{(c_i-c_j)^TG_5(c_i-c_j)}{2\sigma_c^2}
-\frac{d_J(i,j)^2}{2\sigma_J^2}
\right].
\]

\[
\dot\theta_i=\omega_i
+K_2\sum_jW_{ij}\sin(\theta_j-\theta_i)
+K_3\sum_{j,k}H_{ijk}\sin(\theta_j+\theta_k-2\theta_i).
\]

### Activation, boundary, support and radius

\[
\begin{aligned}
h_i={}&\beta\left(Mq+\tfrac12-d_i\right)
+a_EE_i+a_uu_i-a_\chi\chi_i-a_\zeta\zeta_i\\
&+J_2\sum_jW_{ij}(2p_j-1)
+J_3\sum_{j,k}H_{ijk}(2p_j-1)(2p_k-1),\\
p_i={}&\sigma(h_i)=\frac{1}{1+e^{-h_i}},\\
B_5(c_i)={}&\prod_{a=4}^{8}b(c_{i,a}),\\
s_i={}&p_i\kappa_i(1-\chi_i)(1-\zeta_i)v(\omega_i),\\
r_i={}&r_{\max}B_5(c_i)^\alpha s_i^{1/3}.
\end{aligned}
\]

### Fiber, total space and projection

\[
F_i=S^3_{r_i}=\{y\in\mathbb R^4:\|y\|_2=r_i\},\qquad
X_8(\tau)=\{(c,y)\in[-1,1]^5\times\mathbb R^4:
\|y\|_2=R(c,\tau)\}.
\]

\[
z_i(u)=\begin{bmatrix}c_i\\r_iu\end{bmatrix},\quad u\in S^3,\qquad
x_i^{(3)}=[\Pi_5(\tau)\ \Psi_4(\tau)]z_i(u).
\]

### Gap descriptors, classification and efficacy

\[
\begin{aligned}
g_{ij}^{(5)}&=\sqrt{(c_i-c_j)^TG_5(c_i-c_j)}-(\lambda_i+\lambda_j),\\
\delta_{ij}^{(8)}&=\sqrt{(c_i-c_j)^TG_5(c_i-c_j)+(r_i-r_j)^2},\\
g_{ij}^{(3)}&=\|\Pi_5c_i-\Pi_5c_j\|_2-(\widehat r_i+\widehat r_j),\\
g_{ij}^{(J)}&=d_J(\mathfrak J_i,\mathfrak J_j)-\theta_J.
\end{aligned}
\]

\[
\mathcal R_{ij}^{8S}=\operatorname{Classify}
\left(g_{ij}^{(5)},\delta_{ij}^{(8)},g_{ij}^{(3)},g_{ij}^{(J)},
\mathcal K_{ij},\Sigma_{ij}\right),\qquad
\Delta_{8S}=\operatorname{Score}(\mathcal M_8)-\operatorname{Score}(\mathcal M_7).
\]

\[
\boxed{\operatorname{Admit}(8S)\iff
\eta_{\mathrm{ind}}\ge\varepsilon_{\mathrm{ind}}
\quad\land\quad \Delta_{8S}>\varepsilon_{\mathrm{gain}}.}
\]

The independence comparison includes equality. The gain comparison excludes equality. The displayed periodic function has no additional phase offset; phase coupling appears in its own equation. The image supplies neither a choice of integration scheme nor a six-argument classifier implementation.

## 3. Symbol domains and units

This table records the explicit reference contract. Some restrictions are engineering/model choices used to make a real-valued reference executable, rather than additional equations in the image.

| Symbol or object | Shape/domain used here | Definition or evidence still needed |
|---|---|---|
| `C4` | finite real n×4 matrix, n≥1 | data rows, feature meanings, normalization, rank policy |
| `e` | finite real n-vector | fifth feature definition, units and common observations |
| `C5` | n×5 concatenation | the reference does not fit an M8/M7 model from C5 |
| `C4+` | Moore–Penrose inverse in the mathematical interpretation | a versioned numerical solver/cutoff and conditioning evidence |
| `P=C4 C4+` | n×n orthogonal projector in exact mathematics | association with the declared C4; symmetry alone is insufficient |
| denominator epsilon | strictly positive finite real | same squared units as the norm denominator; distinct from all tolerances |
| epsilon_ind | [0,1] | application-selected independence threshold |
| `n_i`, `M` | five integers; nonnegative integer L1 bound | actual lattice/ordering authority |
| ell | positive finite real | conversion into normalized cube coordinates |
| `c_i` | five coordinates in [-1,1], labels4..8 | frame, normalization and feature meaning |
| tau, T | finite tau, positive finite T | common time units; tau/T is dimensionless |
| theta, omega | finite phase vector and natural frequency | radians and inverse-time units |
| G5 | finite symmetric PSD5×5, numerically checked | geometry frame, units, scale and positive-definiteness if a strict metric is claimed |
| A, W | finite nonnegative pair factors | topology, direction, meaning and source of adjacency |
| sigma_c, sigma_J | strictly positive finite scales | normalized latent and judgment-distance units |
| dJ | finite nonnegative supplied scalar | versioned distance/metric definition and its axioms |
| H | finite signed ordered triad weights | explicit support, order and physical/statistical interpretation |
| K2, K3, J2, J3 | finite real coefficients | units and bounds for a chosen model |
| beta, d_i, a_E E_i, a_u u_i | finite scalar terms | consistent dimensionless activation contributions |
| activation u_i | finite feature scalar | distinct from the four-component unit fiber direction u |
| chi, zeta, p | [0,1] | meanings of inhibition/support factors; p inputs may be supplied independently |
| kappa, v(omega) | finite nonnegative supplied values | no velocity function is invented |
| boundary factors | exactly five nonnegative finite values | no boundary function is invented and no automatic upper bound1 is imposed |
| alpha, rmax | positive alpha; nonnegative finite rmax | intended radius scaling and whether rmax is meant as an enforced maximum |
| R(c,tau) | not constructed by the reference | field/interpolation rule and required regularity |
| u∈S3 | finite four-vector with squared norm1 within tolerance | chart/orientation choice and its numerical policy |
| Pi5, Psi4 | finite3×5 and3×4 matrices | projection frame/time and calibration |
| lambda, r, apparent r | separate nonnegative supplied radii | separate latent exclusion, fiber and projected-support meanings |
| thetaJ | finite nonnegative threshold | judgment-domain threshold definition |
| Kij, Sigmaij, Classify | not implemented | uncertainty, admissibility and class precedence |
| Score(M8), Score(M7) | finite supplied real scores | common data, fitting, evaluation and uncertainty |
| epsilon_gain | nonnegative finite real | application-selected efficacy threshold |

The frozen activation helper accepts real nonnegative `M`, while its lattice helper requires integer `M`. A future adapter that shares the lattice bound with activation must require the common nonnegative integer interpretation. This difference is exposed rather than erased by changing frozen source.

A normalized cube and a radius in physical length cannot be summed in a squared distance without a declared unit conversion. G5 can supply that conversion for the center term; the profile must specify units that make it commensurate with `(ri-rj)^2`. Likewise, `lambda` and the center norm must use the same units in g5, and apparent radii must match Pi5's projected coordinate units. Matrix shape validation does not establish those unit identities.

## 4. Independence, projection and rank

For a real matrix C4, the Moore–Penrose inverse is the inverse defined by its four standard algebraic identities. The product P=C4 C4+ is the orthogonal projector onto C4's column space. Penrose's original paper establishes the generalized inverse through those identities. [Penrose, 1955](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/S0305004100030401).

For the exact projector, write e=Pe+(I−P)e. The two components are orthogonal because P is symmetric and idempotent. Consequently,

\[
0\le\|(I-P)e\|^2\le\|e\|^2,
\qquad 0\le\eta_{\mathrm{ind}}<1\quad(\varepsilon>0).
\]

The upper inequality is strict for a finite nonzero e and strictly positive denominator epsilon. The implementation admits the closed numeric interval[0,1], allowing host rounding to1 at extreme scale. That engineering range must not be substituted for a symbolic proof that an exact finite input attains1.

The residual vanishes precisely when e lies in the declared column space, assuming an exact projector. A positive residual implies the augmented matrix has a larger rank. Passing a positive independence threshold therefore entails nonzero residual in exact arithmetic. A zero threshold permits eta=0; it does not establish a rank increase. The dataset includes this literal admission edge so that a numerical pass cannot be mistaken for an extra proved dimension.

Symmetry and idempotence establish that a matrix projects onto *some* subspace. They do not establish that it projects onto C4's column space. The standalone `independence_score` helper checks those two properties and leaves the relationship to C4 as caller evidence. The typed admission record optionally supplies C4; when supplied, the reference compares the projector with its own numerical column-space construction. When omitted, the output explicitly retains caller-declared projector authority.

The frozen construction uses two-pass modified Gram–Schmidt and an absolute residual-norm threshold. It appends a basis vector only when its norm exceeds the declared tolerance. Coordinate-column corpus cases have exact known projectors and ranks, including dependent columns, zero matrices and rank-threshold examples. General comparisons against NumPy use an SVD pseudoinverse with `rcond=1e-12`; NumPy's documented cutoff is relative to the largest singular value. These policies are different and can disagree near rank boundaries or under rescaling. [NumPy2.3 pseudoinverse documentation](https://numpy.org/doc/2.3/reference/generated/numpy.linalg.pinv.html).

The quantity eta is also not scale invariant when denominator epsilon is fixed. For e replaced by te,

\[
\eta(t)=\frac{t^2\|(I-P)e\|^2}{t^2\|e\|^2+\varepsilon}.
\]

It tends toward zero as t tends toward zero and toward the residual-energy fraction at large t. Feature normalization and epsilon selection therefore affect admission. A normalized eta is not an empirical proof that a feature is causally independent, statistically independent or useful on held-out data.

## 5. Lattice, periodic input and weighted geometry

The lattice call validates both constraints: integer L1 mass at most M and every resulting coordinate inside the cube. Satisfying the L1 bound does not automatically satisfy the cube bound for an arbitrary ell. For example, `[3,0,0,0,0]`, ell=.5 and M=3 satisfies the L1 bound but produces a coordinate1.5 and is rejected. Coordinate order4..8 remains stable through lattice, metric, boundary and projection operations.

For T>0, q has period T, lies in[0,1], and obeys q(0)=0, q(T/2)=1 and q(T)=0. Its mathematical zeros and maxima provide independent quarter-period oracles. Host sine at a finite approximation of pi can produce a tiny positive residual at a mathematical zero, so those comparisons use declared numerical tolerances. Large tau/T can lose phase precision even when finite; overflow of the intermediate phase argument is a controlled host rejection. The reference does not perform arbitrary-precision range reduction.

For a fixed symmetric PSD G5, the quadratic form D=dᵀG5d is nonnegative. If G5 is positive definite, sqrt(D) separates distinct center coordinates. If G5 has a nullspace, distinct centers can have D=0 and the function is a pseudometric. For example, diag(1,0,0,0,0) cannot distinguish centers differing only in the second coordinate. The dataset tests both full-rank diagonal metrics and rank-one outer products, using rational quadratic forms independent of the frozen elimination algorithm.

A single fixed PSD matrix defines a seminorm and a corresponding triangle inequality. Pair-specific, time-specific or inconsistently calibrated matrices require a separate geometric contract; per-call PSD acceptance alone does not prove a global distance function across the model. The same caution applies to dJ: this API receives a nonnegative scalar and does not check symmetry, identity of indiscernibles or triangle inequalities over an entire judgment dataset.

The pair exponential has a nonpositive exponent under the stated reference domains. Thus 0≤Wij≤Aij, with equality at coincident latent/judgment coordinates or when Aij=0. Both scale denominators must be positive. Decimal exponential oracles use80-digit precision and exact rational source coordinates; they provide an independent numerical route for the authored cases. They do not certify adjacency provenance, a physical force law or a probabilistic interpretation of W.

## 6. Coupled phase and activation dynamics

The phase helper evaluates a right-hand side at a supplied state. Its input includes the selected node index, the complete phase vector, natural frequency, coefficients and explicit sparse ordered pair/triad terms. Pair entries contain `(j,Wij)`; triad entries contain `(j,k,Hijk)`. Node indices are bounded integers; booleans are rejected. Duplicate pair indices and duplicate ordered triads are rejected. `(j,k)` and `(k,j)` remain separately declared terms; the implementation does not symmetrize them or add omitted interactions.

Finite authored quarter-turn cases have sine values0,1,0,−1, independent of the host trigonometric implementation. Rational interaction weights make their expected derivatives analytic sums. The frozen helper sorts sparse terms by declared indices before summation. Reordering a valid input list therefore does not change its local numerical reduction order. This property concerns one pure host evaluation; it does not establish a deterministic distributed scheduler or heterogeneous device reduction.

The derivative equation does not supply an initial condition, integration step, integrator, stopping rule, boundary event policy or stochastic forcing process. No trajectory integration, convergence theorem, phase-locking guarantee or Lyapunov certificate is implemented. A numerical ODE adapter would need to bind all those choices, its local/global error estimates and the time-varying status of W/H/omega.

The activation helper likewise evaluates h from *supplied* probabilities. It does not solve the simultaneous equations p_i=sigmoid(h_i(p)). Reading the equation as a coupled fixed point creates an additional solver problem. Convergence, uniqueness and consistent update order cannot be inferred from the presence of a sigmoid.

An illustrative sufficient condition can be derived for a finite, explicitly supported fixed-point model with constant external terms. Since sigmoid's derivative is at most1/4, a row's sup-norm sensitivity is bounded by

\[
L_i\le\tfrac12|J_2|\sum_j|W_{ij}|+|J_3|\sum_{j,k}|H_{ijk}|.
\]

The pair derivative contributes a factor2; each ordered triad can contribute twice, once through each probability factor. This bound also counts the twice-occurring derivative when j=k. If the maximum row bound is strictly below1, it supplies a contraction criterion for that explicitly defined finite model. This is a conditional derivation for a future solver contract, not an additional equation from the image, a property tested for arbitrary corpus records, or an implemented solver. The current code neither checks this bound nor iterates the coupled fixed point.

Stable sigmoid evaluation chooses the exponent branch according to h's sign to avoid overflow for large negative inputs. Its real-valued mathematical output lies strictly between0 and1 for finite h. Floating-point evaluation can round or underflow to an endpoint: the authored h=1000 and h=−1000 cases observe1 and0 respectively. The research wrapper accepts those host endpoints in its declared closed interval. A zero produced by underflow must not be presented as mathematical evidence that the real activation or fiber support vanishes.

## 7. Boundary factors, effective support and radius

The boundary function b is intentionally unspecified. `boundary_product` receives exactly five evaluated factors, associated with labels4..8. It validates finiteness and nonnegativity, then computes their product. A formula such as `1−c²`, a hard cube indicator or a smooth bump would be a new model choice; none is silently adopted.

The velocity multiplier is equally explicit. `effective_support` receives the evaluated v(omega), with nonnegative kappa and velocity factor and p/chi/zeta in[0,1]. These domains guarantee s≥0. A factor p=0, chi=1, zeta=1, kappa=0 or velocity=0 collapses support. The reference does not assign a velocity curve, infer the meaning of chi/zeta or derive support from a physical sensor.

For alpha>0 and nonnegative B,s,rmax, the radius formula is real and nonnegative. Cases whose supplied support is an exact rational cube have independent exact cube-root expectations. B=0 or s=0 gives radius0. The API implements a nonnegative real cube root through a floating exponent; a negative support is rejected, rather than extending the model with a signed cube root.

The name rmax does not itself prove a maximum-radius invariant. The current domains allow B>1 and s>1. With five boundary factors2, alpha1, support1 and rmax1, B=32 and r=32. To prove r≤rmax, an additional model contract must ensure B^alpha s^(1/3)≤1, for example through appropriate upper bounds on both B and s. This corpus permits the supplied reference domains and documents that limit instead of inventing normalization constraints.

Finite inputs can overflow in intermediate products or powers. The frozen numeric wrapper converts range/domain arithmetic errors into controlled `ModelError` denials. Algebraic simplification might avoid some overflows—for example a zero rmax multiplied by an enormous power—but the frozen implementation does not promise symbolic simplification. Host-domain rejection is not a declaration that the exact expression is mathematically undefined.

## 8. Fiber and total-space dimension

At radius r>0, the fiber `{y∈R4:||y||=r}` is a3-sphere, intrinsically three-dimensional and embedded in four ambient dimensions. A unit u selects a point on that fiber. Concatenating a five-component center with ru yields **nine ambient coordinates**. The reference's `fiber_point` emits all nine and checks the direction's squared norm against the declared tolerance.

For a fixed tau, suppose R is continuously differentiable near an interior base point and positive there. The total space can be written as a level set in R9:

\[
F(c,y)=\|y\|^2-R(c,\tau)^2=0.
\]

Its derivative with respect to y is2y, nonzero because ||y||=R>0. Locally it therefore has one regular constraint in nine ambient dimensions, giving intrinsic dimension8. Equivalently, the local map `(c,u)↦(c,R(c,tau)u)` has five base and three fiber degrees of freedom under those assumptions. `local_noncollapsed_dimension` returns8 only as that conditional regular-chart statement.

At R=0, the fiber becomes a point and the regular-level-set argument above fails. The total-space behavior depends on the radius field and its neighborhood. A zero sample alone cannot determine a singularity type, surrounding strata, topology or a uniform total-space dimension. The reference returns null at radius0 and does not announce a different global dimension.

Cube boundaries also need their own analysis. An interior local dimension statement does not prove a boundaryless global manifold. If R is a positive constant throughout the closed cube, the defined set is the product of the cube and S3 and inherits boundary/corner structure from its base. This conditional example is enough to show why the displayed set definition does not, by itself, establish global equivalence to the standard sphere S8. Neither the word8S nor an eight-dimensional local chart supplies that proof.

The reference constructs sampled fibers only. It does not interpolate the sampled radii into R(c,tau), verify continuity/differentiability, generate an atlas, analyze collapse loci or certify topology. Those are explicit research and adapter gates.

## 9. Projection and four distinct gap descriptors

Pi5 and Psi4 have shapes3×5 and3×4. Their concatenation maps the nine-coordinate embedding to a three-coordinate output. The projection helper performs that linear map on a checked fiber point. Its matrix-shape checks do not prove orthogonality, rank, perspective calibration or preservation of distances.

g5 combines the weighted latent center separation with *latent exclusion radii* lambda_i/lambda_j. delta8 combines the same center quadratic form with the *difference in fiber radii*. g3 uses Pi5's projection of centers and *apparent projected radii*. gJ compares a supplied judgment distance against a judgment threshold. These are separate objects. The code does not replace lambda with r, replace an apparent radius with a fiber radius, or use judgment overlap as a geometric proof.

delta8 omits the actual unit fiber orientations. With identical centers and equal positive radii, it gives0 even when two fiber points have opposite unit directions. For c=0, r=1, u_i=(1,0,0,0) and u_j=(−1,0,0,0), their embedded fiber-point Euclidean distance is2 while delta8=0. Thus delta8 is preserved as the supplied center/radius descriptor, not advertised as a complete geodesic or oriented point distance on X8.

The apparent-radius rule is not supplied. A projection of a sphere under Psi4 can produce an ellipsoid or a lower-rank shape; a scalar apparent radius requires a declared approximation or bounding rule. One possible future bound uses an operator norm, but that is a model choice requiring its own typed metadata and tests. It is not implemented here. g3's center-only separation should likewise not be mistaken for the distance between the complete projected fiber points x_i3.

Negative, zero and positive gap values are numerical descriptors. Attaching relational class names requires a versioned `Classify` contract, threshold comparisons, tie/uncertainty handling and the meanings of Kij/Sigmaij. The frozen gap function returns the four measurements, `classification:null` and an explicit missing-policy status. This remains the research wrapper's required output. Legacy classes or editorial examples cannot supply an undeclared precedence table.

## 10. Admission and empirical Score

The implemented gate performs exactly the two supplied comparisons. It does not soften either inequality using the numerical tolerance. Numerical comparison tolerance is used by matrix/unit checks and corpus verification; epsilon_ind and epsilon_gain are model thresholds. Replacing `>` with `>=`, or admitting a result within a generic absolute tolerance of a threshold, would alter the displayed rule.

The analytical admission family tests values immediately below, equal to and immediately above binary-exact thresholds with `nextafter`, plus the closed interval endpoints0/1 and zero-gain edges. Direct inputs use binary-exact score differences so that a rational oracle and host subtraction agree on the intended comparison. Arbitrary floating scores near cancellation require a future uncertainty/precision policy; this corpus does not pretend that a rounded Delta is an exact real inequality certificate.

Scores are supplied, not fitted or measured by the reference. The image does not identify a training cohort, held-out partition, statistical estimator, model architecture, cost/energy penalty or confidence interval. A future empirical admission procedure should bind those definitions and use comparable M8/M7 evaluations, but those requirements are proposed research evidence. An illustrative supplied Score difference is not already held-out evidence.

The names M8/M7 alone do not determine an ablation protocol or the relationship between a fifth feature, matrix rank and a model's geometric dimension. A proper experiment must declare which component is added or removed, which fitting budget is held fixed, what data is shared, what leakage is prevented and how uncertainty affects the decision. Repeated tests from a parameterized analytical family are not empirical independent observations.

The typed output's `admitted_model_dimension` means **the supplied numerical gate passed**, with its exact reported projector authority. It does not certify feature meaning, held-out generalization, physical reality, a global sphere theorem, native execution eligibility or federation authority.

## 11. Numerical policy, conditioning and known frozen limits

The research policy requires finite inputs and outputs and **0 < numerical tolerance ≤1e−6**. Its default is1e−9. The upper ceiling is an engineering limit chosen for this research release; it is not an equation or author-provided constant in the image. The wrapper separately checks eta in[0,1], nonnegative geometry/support/radii, output shapes, conditional dimension, gap classification absence and gate consistency.

Two frozen limitations are explicitly preserved:

1. `_metric` accepts tiny negative directions within its declared tolerance and `quadratic_geometry` clamps a resulting tiny negative squared value to0. With diag(−1e−10,1,1,1,1), a unit first-coordinate difference and tolerance1e−9, the host result is0. This is marked `declared_roundoff_allowance`, not exact positive-semidefiniteness or a strict metric proof.
2. The frozen tolerance is unbounded. For e=[1], P=[[4]], denominator epsilon1 and tolerance20, symmetry/idempotence tests permit the invalid matrix and eta=4.5 is returned. The research wrapper rejects this before evaluation under its ceiling. The dataset records the frozen4.5 observation and research denial separately as an invalid-projector counterexample. Typed frozen admission subsequently rejects eta outside[0,1]; these observations do not establish a native admission bypass.

Bounding tolerance does not solve every conditioning problem. Absolute residual thresholds depend on scale. Near-singular matrices, poorly normalized features, very large/small values, cancellation and subnormal arithmetic can require SVD/QR, relative tolerances, explicit uncertainty or interval methods. The wrapper does not estimate condition numbers, compute certified eigenvalue bounds, prove a global forward/backward error estimate or validate an application-specific normalization policy.

The reference's metric checker uses pivoted Schur elimination; its projector uses two-pass Gram–Schmidt. The independent analytical families cover certifiable diagonal/rank-one metrics and coordinate-column projectors, while optional NumPy comparisons cover ordinary well-scaled random cases. Agreement on those cases does not authorize all ill-conditioned inputs or prove equivalence of the two rank policies.

The host environment is recorded rather than assumed universal. CPython floats and its mathematical library determine observed rounding. The80-digit Decimal oracles use separate decimal algorithms and exact rational reductions; Python documents the correctly rounded Decimal exponential operation. This remains high-precision numerical evidence, not an interval proof of every transcendental result. [Python3.12 Decimal documentation](https://docs.python.org/3.12/library/decimal.html).

## 12. Corpus design and research use

[cases.jsonl](dataset/cases.jsonl) contains1,619 unique operation/input combinations,19 mathematical families and66 family/template combinations. These are18 pure host operations, not1,619 different programs or theories. Exact duplicates were eliminated before IDs were assigned. Input hashes omit IDs, family names, provenance labels and observations, so changing only a case label cannot inflate the uniqueness count.

Each case separates independently reconstructed expectations from frozen observations and research-wrapper observations. It binds the canonical input and exact frozen source with SHA256. Domain denials have explicit certificates; nonfinite probes use tagged JSON input values rather than illegal JSON NaN/Infinity tokens. Accepted tiny-negative metric cases carry a roundoff-premise qualification. Invalid wide-tolerance cases remain recorded but are denied by research policy.

There are1,446 frozen value observations and173 frozen denials. Research policy accepts1,442 value cases and denies177, including the four wide-tolerance invalid-projector cases. A separate500-case NumPy differential dataset is counted separately:200 PSD geometries,200 C4 projectors and100 linear projections. It uses seed82108, NumPy2.3.5 and declared solver/comparison tolerances. NumPy's Generator does not guarantee identical streams across versions, so pinning the dependency and preserving actual input bytes matter. [NumPy2.3 random Generator documentation](https://numpy.org/doc/2.3/reference/random/generator.html).

The dataset is appropriate for arithmetic regression, denial behavior, numerical-policy review and development of a future typed adapter. It contains no fitted Score experiments, trajectories, physical measurements, native image execution or federation runs. [The adapter draft](ADAPTER_CONTRACT_DRAFT.md) identifies those missing boundaries without registering new operations in the frozen LCUF core.
